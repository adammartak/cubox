?package(libvmeta):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="libvmeta" command="/usr/bin/libvmeta"
