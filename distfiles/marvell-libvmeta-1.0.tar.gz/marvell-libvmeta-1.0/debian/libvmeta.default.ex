# Defaults for libvmeta initscript
# sourced by /etc/init.d/libvmeta
# installed at /etc/default/libvmeta by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
