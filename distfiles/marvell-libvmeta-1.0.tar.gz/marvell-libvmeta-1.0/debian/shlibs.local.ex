liblibvmeta 1.0 libvmeta (>> 1.0-0), libvmeta (<< 1.0-99)
