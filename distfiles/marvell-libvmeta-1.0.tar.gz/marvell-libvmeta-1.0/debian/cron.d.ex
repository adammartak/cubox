#
# Regular cron jobs for the libvmeta package
#
0 4	* * *	root	[ -x /usr/bin/libvmeta_maintenance ] && /usr/bin/libvmeta_maintenance
