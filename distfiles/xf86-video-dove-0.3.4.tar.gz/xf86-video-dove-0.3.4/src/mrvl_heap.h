/******************************************************************************
//(C) Copyright 2009 Marvell International Ltd.
//All Rights Reserved
******************************************************************************/

#ifndef VIVANTE_HEAP_H
#define VIVANTE_HEAP_H

#include "list.h"
#include "datatypes.h"

#define MEM_INVALID_ADDRESS 0xFFFFFFFF

#define HEAP_MEM_PAGE_ALIGN_DOWN(a, size)            ((a) - (a) % (size))
#define HEAP_MEM_PAGE_ALIGN_UP(a, size)              ( ((a) + ((size) - 1)) - ((a) + ((size) - 1)) % (size) )

typedef struct __MEMORY_ALLOCATION
{
    MRVL_U32                AllocationSize;
    MRVL_U32                PhysicalAddress;
    MRVL_U32                LinearAddress;
    
    struct {
        MRVL_U32            isUpper     : 1;
    }flags;

    struct list_head        list_entry;

}
MEMORY_ALLOCATION, *PMEMORY_ALLOCATION;

typedef struct __OsMemHeap
{
    MRVL_U32            mHeapSize;
    MRVL_ULONG          mLinearAddress;
    MRVL_ULONG          mPhysicalAddress;

    struct list_head    mAllocatedAllocationList;
    struct list_head    mAvailableAllocationList;

    struct list_head    mAllocationDescriptorList;

}
OsMemHeap, *POsMemHeap;


MRVL_VOID           OsMemHeapInitialize(POsMemHeap pOsMemHeap, MRVL_ULONG linearAddress, MRVL_ULONG physicalAddress, MRVL_U32 size);    
MRVL_VOID           OsMemHeapDestroy(POsMemHeap pOsMemHeap);
              
MRVL_VOIDP          CreateAllocationByOffset(POsMemHeap pOsMemHeap, MRVL_U32 offset, MRVL_U32 size, MRVL_BOOL isCpuClear);
MRVL_VOID           DeleteAllAllocationByOffset(POsMemHeap pOsMemHeap);

MRVL_VOIDP          GetHeapBaseLinearAddress(POsMemHeap pOsMemHeap);
MRVL_ULONG          GetHeapBasePhysicalAddress(POsMemHeap pOsMemHeap);

MRVL_VOIDP          CreateAllocation(POsMemHeap pOsMemHeap, MRVL_U32 Size, MRVL_U32 Alignment);
MRVL_VOIDP          CreateUpperAllocation(POsMemHeap pOsMemHeap, MRVL_U32 Size, MRVL_U32 Alignment);
MRVL_VOID           DeleteAllocation(POsMemHeap pOsMemHeap, MRVL_VOIDP Address);
MRVL_ULONG          GetPhysicalAddress(POsMemHeap pOsMemHeap, MRVL_VOIDP LinearAddr);
MRVL_VOIDP          GetLinearAddress(POsMemHeap pOsMemHeap, MRVL_ULONG PhyAddr);
MRVL_VOIDP          RecreateAllocation(POsMemHeap pOsMemHeap, MRVL_U32 oldSize, MRVL_VOIDP oldMem, MRVL_U32 newSize, MRVL_U32 newAlignment);
    

MRVL_ULONG          InternalCreateAllocation(POsMemHeap pOsMemHeap, MRVL_U32 Size, MRVL_U32 Alignment, MRVL_U32 isUpper);
PMEMORY_ALLOCATION  CreateAllocationDescriptor();
MRVL_VOID           ReleaseAllocationDescriptor(PMEMORY_ALLOCATION pAllocation);
MRVL_VOID           InsertAllocationToFreeList(POsMemHeap pOsMemHeap, PMEMORY_ALLOCATION pAllocation);
MRVL_VOID           FillAllocationDescriptor(PMEMORY_ALLOCATION pAllocation, MRVL_U32 linearAddr, MRVL_U32 phyAddr,MRVL_U32 size,MRVL_U32 isUpper);
PMEMORY_ALLOCATION  FindAllocationDescriptorFromLinearAddr(POsMemHeap pOsMemHeap, MRVL_VOIDP LinearAddress);
PMEMORY_ALLOCATION  FindAllocationDescriptorFromPhyAddr(POsMemHeap pOsMemHeap, MRVL_ULONG PhyAddress);
MRVL_VOID           ReleaseAllocationList(struct list_head *head);
MRVL_U32            CaculateFreeSpace(POsMemHeap pOsMemHeap);
MRVL_VOID           PrintFreeSpace(POsMemHeap pOsMemHeap);
#endif

