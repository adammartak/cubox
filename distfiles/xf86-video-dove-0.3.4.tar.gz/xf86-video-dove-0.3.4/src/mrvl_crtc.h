#ifndef MRVL_CRTC_H
#define MRVL_CRTC_H

#include "mrvl_edid.h"

#define MRVL_MAX_CRTC_COUNT     2
#define MRVL_MAX_EDID_EXT_NUM   4

typedef struct __MRVLCrtcPrivateRec 
{
    int         crtc_id;
    void        *crtc_rotate_mem;
    int         crtc_roate_phy_off;
    int         crtc_num;
    int         configVirtualX;
    int         configVirtualY;
    int         output_connected;
    
} 
MRVLCrtcPrivateRec, *MRVLCrtcPrivatePtr;

typedef struct __MRVLOutputPrivateRec {
    unsigned int    cur_mode;
    int             dummy;
    unsigned char   edid_raw_data[EDID_LENGTH * (MRVL_MAX_EDID_EXT_NUM + 1)];
    int             edid_valid;
    int             edid_is_hdmi;
    int             edid_dummy;
} 
MRVLOutputPrivateRec, *MRVLOutputPrivatePtr;

Bool    mrvlCrtcInit(ScrnInfoPtr pScrn);
Bool    mrvlOutputInit(ScrnInfoPtr pScrn);

#endif
