#ifndef MRVL_CURSOR_H
#define MRVL_CURSOR_H

#define MRVL_CURSOR_ALPHA   0x1F000000

#if MRVL_SUPPORT_RANDR
void DovefbHideCursor(ScrnInfoPtr pScrn, int crtc_id);
void DovefbShowCursor(ScrnInfoPtr pScrn, int crtc_id);
Bool DovefbUseHWCursorSetting(Rotation rotation, int crtc_id);
void DovefbSetCursorPosition(ScrnInfoPtr pScrn, int x, int y, int crtc_id);
void DovefbSetCursorColors(ScrnInfoPtr pScrn, int bg, int fg, int crtc_id);
void DovefbLoadCursorARGB (ScrnInfoPtr pScrn, CARD32 *image, int crtc_id);
#else
void DovefbHideCursor(ScrnInfoPtr pScrn);
void DovefbShowCursor(ScrnInfoPtr pScrn);
Bool DovefbUseHWCursorSetting(Rotation rotation);
void DovefbSetCursorPosition(ScrnInfoPtr pScrn, int x, int y);
void DovefbSetCursorColors(ScrnInfoPtr pScrn, int bg, int fg);
void DovefbLoadCursorARGB (ScrnInfoPtr pScrn, CARD32 *image);
#endif

#endif
