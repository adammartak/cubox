#include "dovefb_driver.h"

static int vivGlobalCurrentDebugMode    = VIV_PRIORITY_OUTPUT;
static int vivGlobalCurrentDebugOption  = VIV_FATAL_ERROR;

BOOL VIVDebug(VIV_DEBUG_OPTION option, char *fmt, ...)
{
    fprintf(stderr, "***** VIVDebug()");
#if VIV_COMPILE_OUTPUT_FUNC    
    char        buffer[1024];
    va_list     arglist;
    BOOL        retValue = FALSE;
    
    fprintf(stderr, "VIVDebug()");
    switch (vivGlobalCurrentDebugMode)
    {
        case VIV_DISABLE_ALL_OUTPUT:
        case VIV_UNKNOWN_OUTPUT:  
            return retValue; 
    }
    
    va_start(arglist, fmt);
    vsprintf(buffer, fmt, arglist);
    va_end(arglist);
    
    switch (vivGlobalCurrentDebugMode)
    {
        case VIV_SINGLE_OPTION_OUTPUT:
            if (vivGlobalCurrentDebugOption == option)
                ErrorF(buffer);
                
            retValue = TRUE;
            break;
        
        case VIV_PRIORITY_OUTPUT:
            if (vivGlobalCurrentDebugOption >= option)
                ErrorF(buffer);
            
            retValue = TRUE;    
            break;
        
        case VIV_ENABLE_ALL_OUTPUT:
            fprintf(stderr, "[all output] ");
            fprintf(stderr, "%s", buffer);
            ErrorF(buffer);
            
            retValue = TRUE;
            break;
        
        default:
            break;
    }   
    
    return retValue;
#else
    return TRUE;
#endif    
}

void VIVSetDebugMode(VIV_DEBUG_MODE mode)
{
    vivGlobalCurrentDebugMode = mode;    
}        

void VIVSetDebugOption(VIV_DEBUG_OPTION option)
{
    vivGlobalCurrentDebugOption = option;    
}


#if DUMP_RAW_VIDEO
void VIVDumpImage(char *dumpFileName, unsigned int *dumpIndex, char *dumpAddress, unsigned int width, unsigned int height, unsigned int bpp)
{

    FILE   *dumpFp = NULL;

    if (!width || !height || !dumpAddress)
    {
        fprintf(stderr, "VIVDumpImage: Invalid dump parameters\n");
        return;
    }

    dumpFp = fopen(dumpFileName, "a"); 

    if(!dumpFp)
    {
        fprintf(stderr, "Failed to open the dump file : %s \n", dumpFileName);
        return;
    }   
    else
    {
        fprintf(stderr, "Open raw dump file successfully : %s \n", dumpFileName);                
    }
    
    fwrite(dumpIndex, 4, 1, dumpFp);
    fwrite(&width, 4, 1, dumpFp);
    fwrite(&height, 4, 1, dumpFp);
    fwrite(&bpp, 4, 1, dumpFp);
    fwrite(dumpAddress, 1, width * height * bpp / 8, dumpFp); 
        
    (*dumpIndex)++;

    fclose(dumpFp);

}
#endif
