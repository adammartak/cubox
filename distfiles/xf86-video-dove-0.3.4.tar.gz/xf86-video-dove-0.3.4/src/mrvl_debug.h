#ifndef VIVANTE_DEBUG_H
#define VIVANTE_DEBUG_H

//#define DUMP_RAW_VIDEO           1
//#define DEBUG 1

#if DEBUG
#define VIV_COMPILE_OUTPUT_FUNC  1 
#else
#define VIV_COMPILE_OUTPUT_FUNC  0 
#endif
          
typedef enum  
{
    VIV_DISABLE_ALL_OUTPUT      = 1,
    VIV_ENABLE_ALL_OUTPUT       = 2,
    VIV_PRIORITY_OUTPUT         = 3,   
    VIV_SINGLE_OPTION_OUTPUT    = 4, 
    VIV_UNKNOWN_OUTPUT          = 5,
}
VIV_DEBUG_MODE;

typedef enum 
{
    VIV_FATAL_ERROR     = 0,
    VIV_IMPORTANT_INFO  = 1,
    VIV_TRACE           = 2,
    VIV_DEBUG           = 3,
    VIV_CHECK_POINT     = 4,
    VIV_TRACE_HEAP      = 5,
}
VIV_DEBUG_OPTION;

BOOL VIVDebug(VIV_DEBUG_OPTION option, char *fmt, ...);
void VIVSetDebugMode(VIV_DEBUG_MODE mode);
void VIVSetDebugOption(VIV_DEBUG_OPTION option);

#if DUMP_RAW_VIDEO
void VIVDumpImage(char *dumpFileName, unsigned int *dumpIndex, char *dumpAddress, unsigned int width, unsigned int height, unsigned int bpp);
#endif

#if VIV_COMPILE_OUTPUT_FUNC

#define VIV_OUTPUT(option, fmt...) \
do \
{ \
    BOOL isFlash = FALSE;\
    VIVDebug(option, "[MARVELL]: [FUNC]: %s [LINE]:%d\n",__FUNCTION__,__LINE__);\
    switch (option)\
    {\
        case VIV_FATAL_ERROR:\
            VIVDebug(option, "---[FATAL ERROR] >>>");\
            break;\
        case VIV_IMPORTANT_INFO:\
            VIVDebug(option, "------[IMPORTANT INFO] >>>");\
            break;\
        case VIV_TRACE:\
            VIVDebug(option, "---------[TRACE STACK] >>>");\
            break;\
        case VIV_DEBUG: \
            VIVDebug(option, "------------[DEBUG INFO] >>>");\
            break;\
        case VIV_CHECK_POINT:\
            VIVDebug(option, "---------------[CHECK POINT] >>>");\
            break;\
        default:\
            break;\
    }\
    isFlash = VIVDebug(option, fmt);\
    if (isFlash)\
    {\
        fflush(stdout);\
        fflush(stderr);\
    }\
}\
while(0)\

#else

#define VIV_OUTPUT(option, fmt...)

#endif

static inline void
MRVL_LOG(char *format, ...)
{
    char buffer[1024];
    va_list arglist;
    FILE *fp;

    va_start(arglist, format);
    vsprintf(buffer, format, arglist);
    va_end(arglist);

    fp = fopen("/step.log", "at");

    fwrite(buffer, 1, strlen(buffer),fp);

    fflush(fp);
    fclose(fp);

}

#endif

