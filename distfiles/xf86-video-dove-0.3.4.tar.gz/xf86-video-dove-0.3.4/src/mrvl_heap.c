/******************************************************************************
//(C) Copyright 2009 Marvell International Ltd.
//All Rights Reserved
******************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <memory.h>

#include "mrvl_heap.h"
#include "dovefb_driver.h"

//#define FUNC_TRACE fprintf(stderr, "TRACE-> func: %s, line %d \n", __FUNCTION__, __LINE__);

MRVL_VOID OsMemHeapInitialize(POsMemHeap pOsMemHeap, MRVL_ULONG linearAddress, MRVL_ULONG physicalAddress, MRVL_U32 size)
{
    PMEMORY_ALLOCATION pAllocation;

    pOsMemHeap->mHeapSize           = size;

    pOsMemHeap->mLinearAddress      = linearAddress;
    pOsMemHeap->mPhysicalAddress    = physicalAddress;

    INIT_LIST_HEAD(&pOsMemHeap->mAvailableAllocationList);
    INIT_LIST_HEAD(&pOsMemHeap->mAllocatedAllocationList);

    pAllocation = CreateAllocationDescriptor();

    pAllocation->AllocationSize     = size;
    pAllocation->LinearAddress      = pOsMemHeap->mLinearAddress;
    pAllocation->PhysicalAddress    = pOsMemHeap->mPhysicalAddress;

    mrvl_list_add(&pAllocation->list_entry, &pOsMemHeap->mAvailableAllocationList);
}

MRVL_VOID OsMemHeapDestroy(POsMemHeap pOsMemHeap)
{
    ReleaseAllocationList(&pOsMemHeap->mAllocatedAllocationList);
    ReleaseAllocationList(&pOsMemHeap->mAvailableAllocationList);
}


PMEMORY_ALLOCATION CreateAllocationDescriptor()
{
    PMEMORY_ALLOCATION allocationDesc = (PMEMORY_ALLOCATION)malloc(sizeof(MEMORY_ALLOCATION));

    INIT_LIST_HEAD(&allocationDesc->list_entry);

    return allocationDesc;
}


MRVL_VOID ReleaseAllocationDescriptor(PMEMORY_ALLOCATION pAllocation)
{
    free(pAllocation);
}


MRVL_VOID   InsertAllocationToFreeList(POsMemHeap pOsMemHeap, PMEMORY_ALLOCATION pAllocation)
{
    struct list_head *pos;

    if (!list_empty(&pOsMemHeap->mAvailableAllocationList))
    {
        list_for_each(pos, &pOsMemHeap->mAvailableAllocationList)
        {
            PMEMORY_ALLOCATION pFree = list_entry(pos, MEMORY_ALLOCATION, list_entry);

            if ( (pAllocation->LinearAddress < pFree->LinearAddress) &&
                 ((pAllocation->LinearAddress + pAllocation->AllocationSize) == pFree->LinearAddress))
            {                
                pFree->LinearAddress = pAllocation->LinearAddress;
                pFree->AllocationSize   = pFree->AllocationSize + pAllocation->AllocationSize;

                ReleaseAllocationDescriptor(pAllocation);
                return;               
            }
            else if ( (pAllocation->LinearAddress > pFree->LinearAddress) &&
                      ((pFree->LinearAddress + pFree->AllocationSize) == pAllocation->LinearAddress) )
            {                
                pFree->AllocationSize   = pFree->AllocationSize + pAllocation->AllocationSize;

                ReleaseAllocationDescriptor(pAllocation);
                return;               
            }
            else
            {
                continue;
            }
        }
    }

    if (!list_empty(&pOsMemHeap->mAvailableAllocationList))
    {
        list_for_each(pos, &pOsMemHeap->mAvailableAllocationList)
        {
            PMEMORY_ALLOCATION pFree = list_entry(pos, MEMORY_ALLOCATION, list_entry);

            if ( (pAllocation->LinearAddress < pFree->LinearAddress))
            {                
                continue;            
            }
            else 
            {                                                   
                list_add_tail(&pAllocation->list_entry, pos);
                return;
            }
        }
    }

    mrvl_list_add(&pAllocation->list_entry, &pOsMemHeap->mAvailableAllocationList);
}


MRVL_VOID FillAllocationDescriptor(PMEMORY_ALLOCATION pAllocation, MRVL_U32 linearAddr, MRVL_U32 phyAddr,MRVL_U32 size,MRVL_U32 isUpper)
{
    pAllocation->LinearAddress      = linearAddr;
    pAllocation->PhysicalAddress    = phyAddr;
    pAllocation->flags.isUpper      = isUpper;
    pAllocation->AllocationSize     = size;
}


MRVL_ULONG InternalCreateAllocation(POsMemHeap pOsMemHeap, MRVL_U32 Size, MRVL_U32 Alignment, MRVL_U32 isUpper)
{
    PMEMORY_ALLOCATION  pAllocation = 0, pFree = 0, pMin = 0;
    struct list_head    *pos;
    
    if (Size == 0)
    {
        printf("Invalid allocation size %X \n", Size);
        return MEM_INVALID_ADDRESS;
    }

    if (Alignment == 0)
        Alignment = 1;

    if (!list_empty(&pOsMemHeap->mAvailableAllocationList))
    {
        MRVL_ULONG          alignedAddr;
        MRVL_ULONG          upLinearAddr, upPhyAddr, lowLinearAddr, lowPhyAddr, totalSize;
        PMEMORY_ALLOCATION  pFragment = 0;
        MRVL_ULONG          fragLinear, fragPhy, alignedFragmentSize;

        if (isUpper)
        {
            list_reverse_for_each(pos, &pOsMemHeap->mAvailableAllocationList)
            {
                pFree = list_entry(pos, MEMORY_ALLOCATION, list_entry);

                lowLinearAddr   = pFree->LinearAddress;
                lowPhyAddr      = pFree->PhysicalAddress;
                upLinearAddr    = pFree->LinearAddress + pFree->AllocationSize;
                upPhyAddr       = pFree->PhysicalAddress + pFree->AllocationSize;
                totalSize       = pFree->AllocationSize;

                alignedAddr = HEAP_MEM_PAGE_ALIGN_DOWN(upLinearAddr - Size, Alignment);

                if (alignedAddr < lowLinearAddr)
                {
                    // Size is not big enough, go to next.
                    continue;
                }
                else
                {
                    alignedFragmentSize = upLinearAddr - Size - alignedAddr;

                    if (alignedFragmentSize >  0)
                    {
                        pFragment = CreateAllocationDescriptor();

                        fragLinear  = upLinearAddr - alignedFragmentSize;
                        fragPhy     = upPhyAddr - alignedFragmentSize;

                        FillAllocationDescriptor(pFragment, fragLinear, fragPhy, alignedFragmentSize, 1);

                        mrvl_list_add(&pFragment->list_entry, &pFree->list_entry);
                    }

                    if (alignedAddr == lowLinearAddr)
                    {
                        mrvl_list_del(&pFree->list_entry);

                        pAllocation = pFree;

                        FillAllocationDescriptor(pAllocation, alignedAddr, upPhyAddr - Size - alignedFragmentSize, Size, 1);

                        break;
                    }   
                    else if (alignedAddr > lowLinearAddr)
                    {
                        FillAllocationDescriptor(pFree, lowLinearAddr, lowPhyAddr, totalSize - Size - alignedFragmentSize, 1);

                        pAllocation = CreateAllocationDescriptor();

                        FillAllocationDescriptor(pAllocation, alignedAddr, upPhyAddr - Size - alignedFragmentSize, Size, 1);

                        break;
                    }
                }
            }
        }
        else
        {
            MRVL_ULONG    subSize, minSize = 0xFFFFFFFF;

            // Caculate the optimized piece.
            list_for_each(pos, &pOsMemHeap->mAvailableAllocationList)
            {
                pFree = list_entry(pos, MEMORY_ALLOCATION, list_entry);

                lowLinearAddr   = pFree->LinearAddress;
                alignedAddr     = HEAP_MEM_PAGE_ALIGN_UP(lowLinearAddr, Alignment);

                alignedFragmentSize = alignedAddr - lowLinearAddr;

                subSize = (MRVL_ULONG)((MRVL_S32)pFree->AllocationSize - (MRVL_S32)(Size + alignedFragmentSize));

                if (minSize > subSize)
                {
                    pMin    = pFree;
                    minSize = subSize;
                }
            }

            // Can not find suitable memory block.
            if ((pMin == NULL) || 
                (pMin != NULL && (minSize & 0x80000000) != 0) 
               )
            {    
                goto NoMemory;
            }
            
            // Allocate memory from this space.
            list_for_each(pos, &pOsMemHeap->mAvailableAllocationList)
            {
                pFree = list_entry(pos, MEMORY_ALLOCATION, list_entry);

                if (pMin != pFree)
                {
                    continue;
                }

                lowLinearAddr   = pFree->LinearAddress;
                lowPhyAddr      = pFree->PhysicalAddress;
                upLinearAddr    = pFree->LinearAddress + pFree->AllocationSize;
                upPhyAddr       = pFree->PhysicalAddress + pFree->AllocationSize;
                totalSize       = pFree->AllocationSize;

                alignedAddr = HEAP_MEM_PAGE_ALIGN_UP(lowLinearAddr, Alignment);

                if (alignedAddr + Size > upLinearAddr)
                {
                    continue;
                }
                else
                {
                    alignedFragmentSize = alignedAddr - lowLinearAddr;

                    if (alignedFragmentSize > 0)
                    {
                        fragLinear  = lowLinearAddr;
                        fragPhy     = lowPhyAddr;

                        pFragment = CreateAllocationDescriptor();

                        FillAllocationDescriptor(pFragment, lowLinearAddr, lowPhyAddr, alignedFragmentSize, 0);

                        list_add_tail(&pFragment->list_entry, &pFree->list_entry);
                    }

                    if (alignedAddr + Size == upLinearAddr)
                    {
                        mrvl_list_del(&pFree->list_entry);

                        pAllocation = pFree;

                        FillAllocationDescriptor(pAllocation, alignedAddr, lowPhyAddr + alignedFragmentSize, Size, 0);

                        break;
                    }
                    else
                    {
                        FillAllocationDescriptor(pFree, alignedAddr + Size,  lowPhyAddr + alignedFragmentSize + Size, totalSize - alignedFragmentSize -Size, 0);

                        pAllocation = CreateAllocationDescriptor();

                        FillAllocationDescriptor(pAllocation, alignedAddr, lowPhyAddr + alignedFragmentSize, Size, 0);
                        
                        break;

                    }
                }
            }

        }// if upper

    }// if list is empty

NoMemory:

    if (pAllocation)
    {
        mrvl_list_add(&pAllocation->list_entry, &pOsMemHeap->mAllocatedAllocationList);
        return pAllocation->LinearAddress;
    }
    else
    {
        return MEM_INVALID_ADDRESS;
    }   
}


MRVL_VOIDP CreateAllocation(POsMemHeap pOsMemHeap, MRVL_U32 Size, MRVL_U32 Alignment)
{
    return (MRVL_VOIDP)InternalCreateAllocation(pOsMemHeap, Size, Alignment, 0);
}


MRVL_VOIDP CreateUpperAllocation(POsMemHeap pOsMemHeap, MRVL_U32 Size, MRVL_U32 Alignment)
{
    return (MRVL_VOIDP)InternalCreateAllocation(pOsMemHeap, Size, Alignment, 1);
}


PMEMORY_ALLOCATION FindAllocationDescriptorFromLinearAddr(POsMemHeap pOsMemHeap, MRVL_VOIDP LinearAddress)
{

    PMEMORY_ALLOCATION  pAllocation = 0;
    struct list_head    *pos;

    if ( !list_empty(&pOsMemHeap->mAllocatedAllocationList) )
    {
        list_for_each(pos, &pOsMemHeap->mAllocatedAllocationList)
        {
            pAllocation = list_entry(pos, MEMORY_ALLOCATION, list_entry);

            if ( pAllocation->LinearAddress == (MRVL_ULONG)LinearAddress )
            {
                return pAllocation;
            }
        }
    }

    return 0;
}


PMEMORY_ALLOCATION FindAllocationDescriptorFromPhyAddr(POsMemHeap pOsMemHeap, MRVL_ULONG PhyAddress)
{

    PMEMORY_ALLOCATION  pAllocation = 0;
    struct list_head    *pos;

    if ( !list_empty(&pOsMemHeap->mAllocatedAllocationList) )
    {
        list_for_each(pos, &pOsMemHeap->mAllocatedAllocationList)
        {
            pAllocation = list_entry(pos, MEMORY_ALLOCATION, list_entry);

            if ( pAllocation->PhysicalAddress == PhyAddress )
            {
                return pAllocation;
            }
        }
    }

    return 0;
}


MRVL_VOID DeleteAllocation(POsMemHeap pOsMemHeap, MRVL_VOIDP Address)
{
    PMEMORY_ALLOCATION pAllocation;

    pAllocation = FindAllocationDescriptorFromLinearAddr(pOsMemHeap, Address);

    if (!pAllocation)
    {
        printf("Invalid address 0X%p \n", Address);
    }

    mrvl_list_del(&pAllocation->list_entry);

    InsertAllocationToFreeList(pOsMemHeap, pAllocation);
}


MRVL_ULONG GetPhysicalAddress(POsMemHeap pOsMemHeap, MRVL_VOIDP LinearAddr)
{
    PMEMORY_ALLOCATION pAllocation;
    
    pAllocation = FindAllocationDescriptorFromLinearAddr(pOsMemHeap, LinearAddr);

    if (!pAllocation)
    {
        printf("Invalid linear address 0X%p \n", LinearAddr);
        return MEM_INVALID_ADDRESS;
    }

    return (MRVL_ULONG)pAllocation->PhysicalAddress;
}


MRVL_VOIDP GetLinearAddress(POsMemHeap pOsMemHeap, MRVL_ULONG PhyAddr)
{
    PMEMORY_ALLOCATION pAllocation;

    pAllocation = FindAllocationDescriptorFromPhyAddr(pOsMemHeap, PhyAddr);

    if (!pAllocation)
    {
        printf("Invalid linear address 0X%lX \n", PhyAddr);
    }

    return (MRVL_VOIDP)pAllocation->LinearAddress;

}

MRVL_VOIDP RecreateAllocation(POsMemHeap pOsMemHeap, MRVL_U32 oldSize, MRVL_VOIDP oldMem, MRVL_U32 newSize, MRVL_U32 newAlignment)
{
    MRVL_VOIDP newMem = 0;

    if (oldSize == 0 ||
        newSize == 0 ||
        !oldMem )
    {
        printf("Invalid recreate operation\n");
        return (MRVL_VOIDP)MEM_INVALID_ADDRESS;
    }

    newMem = CreateAllocation(pOsMemHeap, newSize, newAlignment);
    memset(newMem, 0, newSize);
    memcpy(newMem, oldMem, oldSize);
    
    DeleteAllocation(pOsMemHeap, oldMem);

    return newMem;
}

MRVL_VOIDP GetHeapBaseLinearAddress(POsMemHeap pOsMemHeap)
{
    return (MRVL_VOIDP)pOsMemHeap->mLinearAddress;
}


MRVL_ULONG GetHeapBasePhysicalAddress(POsMemHeap pOsMemHeap)
{
    return pOsMemHeap->mPhysicalAddress;
}

MRVL_VOIDP CreateAllocationByOffset(POsMemHeap pOsMemHeap, MRVL_U32 offset, MRVL_U32 size, MRVL_BOOL isCpuClear)
{
    if ( (offset + size) > pOsMemHeap->mHeapSize)
    {
        printf("Out of heap size. Offset:%x, size:%x, heapsize:%x\n", offset, size, pOsMemHeap->mHeapSize);
        return (MRVL_VOIDP)MEM_INVALID_ADDRESS;
    }

    struct list_head    *pos;
    PMEMORY_ALLOCATION  pAllocaiton, pAccquired;

    list_for_each(pos, &pOsMemHeap->mAvailableAllocationList)
    {
        MRVL_U32    accquiredLowAddr, accquiredUpAddr, allocationLowAddr, allocationUpAddr;

        pAllocaiton = list_entry(pos, MEMORY_ALLOCATION, list_entry);

        accquiredLowAddr    = pOsMemHeap->mLinearAddress + offset;
        accquiredUpAddr     = pOsMemHeap->mLinearAddress + offset + size;
        allocationLowAddr   = pAllocaiton->LinearAddress;
        allocationUpAddr    = pAllocaiton->LinearAddress + pAllocaiton->AllocationSize;

        if (accquiredLowAddr < allocationLowAddr || accquiredUpAddr > allocationUpAddr)
        {
            continue;
        }

        if ( accquiredLowAddr == allocationLowAddr && accquiredUpAddr == allocationUpAddr)
        {
            mrvl_list_del(&pAllocaiton->list_entry);
            mrvl_list_add(&pAllocaiton->list_entry, &pOsMemHeap->mAllocatedAllocationList);
        }
        else
        {
            pAccquired = CreateAllocationDescriptor();

            FillAllocationDescriptor(pAccquired, 
                                     accquiredLowAddr, 
                                     pAllocaiton->PhysicalAddress + (accquiredLowAddr - allocationLowAddr), 
                                     size, 
                                     0);

            mrvl_list_add(&pAccquired->list_entry, &pOsMemHeap->mAllocatedAllocationList);

            if (accquiredLowAddr > allocationLowAddr)
            {
                pAllocaiton->AllocationSize = accquiredLowAddr - allocationLowAddr;
            }

            if (accquiredUpAddr < allocationUpAddr)
            {
                PMEMORY_ALLOCATION pFragment = CreateAllocationDescriptor();

                FillAllocationDescriptor(pFragment, 
                                        accquiredUpAddr, 
                                        pAllocaiton->PhysicalAddress + pAllocaiton->AllocationSize - (allocationUpAddr - accquiredUpAddr), 
                                        allocationUpAddr - accquiredUpAddr, 
                                        0);

                mrvl_list_add(&pFragment->list_entry, &pAllocaiton->list_entry);
            }
        }

        if (isCpuClear)
        {
            memset((MRVL_VOIDP)accquiredLowAddr, 0, size);
        }

        return (MRVL_VOIDP)accquiredLowAddr;
    }

    list_for_each(pos, &pOsMemHeap->mAllocatedAllocationList)
    {
        pAllocaiton = list_entry(pos, MEMORY_ALLOCATION, list_entry);

        if ((pAllocaiton->LinearAddress - pOsMemHeap->mLinearAddress) == offset &&
            (pAllocaiton->AllocationSize == size))
        {
            return (MRVL_VOIDP)pAllocaiton->LinearAddress;
        }
    }

    if (isCpuClear)
    {
        MRVL_U32 i;

        for(i = 0; i < size; i+=4)
        {
            *(MRVL_U32 *)(pOsMemHeap->mLinearAddress + offset + i) = 0;
        }

        // Write remaining bytes.
        for (i = 0; i < size%4; i ++)
        {
            *(MRVL_U8 *)(pOsMemHeap->mLinearAddress + offset + (size & ~3) + i) = 0;
        }
    }

    return (MRVL_VOIDP)(pOsMemHeap->mLinearAddress+offset);
}

MRVL_VOID   DeleteAllAllocationByOffset(POsMemHeap pOsMemHeap)
{
    PMEMORY_ALLOCATION pAllocation;

    ReleaseAllocationList(&pOsMemHeap->mAllocatedAllocationList);
    ReleaseAllocationList(&pOsMemHeap->mAvailableAllocationList);

    pAllocation = CreateAllocationDescriptor();

    pAllocation->AllocationSize     = pOsMemHeap->mHeapSize;
    pAllocation->LinearAddress      = pOsMemHeap->mLinearAddress;
    pAllocation->PhysicalAddress    = pOsMemHeap->mPhysicalAddress;

    mrvl_list_add(&pAllocation->list_entry, &pOsMemHeap->mAvailableAllocationList);
}

MRVL_VOID ReleaseAllocationList(struct list_head *head)
{
    struct list_head    *pos;
    PMEMORY_ALLOCATION  pAllocation;

    if (!list_empty(head))
    {
        list_for_each(pos, head)
        {
            struct list_head nextPos;

            memcpy(&nextPos, pos, sizeof(struct list_head));

            pAllocation = list_entry(pos, MEMORY_ALLOCATION, list_entry);

            mrvl_list_del(&pAllocation->list_entry);

            ReleaseAllocationDescriptor(pAllocation);

            pos = &nextPos;
        }
    }
}

MRVL_U32  CaculateFreeSpace(POsMemHeap pOsMemHeap)
{
    struct list_head    *pos;
    PMEMORY_ALLOCATION  pAllocation;
    MRVL_U32            freeSize = 0, busySize = 0;

    if (!list_empty(&pOsMemHeap->mAvailableAllocationList))
    {
        list_for_each(pos, &pOsMemHeap->mAvailableAllocationList)
        {          
            pAllocation = list_entry(pos, MEMORY_ALLOCATION, list_entry);
            
            freeSize += pAllocation->AllocationSize;
        }
    }    

    if (!list_empty(&pOsMemHeap->mAllocatedAllocationList))
    {
        list_for_each(pos, &pOsMemHeap->mAllocatedAllocationList)
        {          
            pAllocation = list_entry(pos, MEMORY_ALLOCATION, list_entry);
            
            busySize += pAllocation->AllocationSize;
        }
    }
    
    xf86DrvMsg(0, X_INFO, "Memory Heap Status :\n");
    xf86DrvMsg(0, X_INFO, "    Free size      : [%d] bytes\n", freeSize);
    xf86DrvMsg(0, X_INFO, "    Allocated size : [%d] bytes\n", busySize);
    xf86DrvMsg(0, X_INFO, "    Total size     : [%d] bytes\n", busySize + freeSize);

    if ((pOsMemHeap->mHeapSize - (busySize + freeSize)) != 0)
    {
        xf86DrvMsg(0, X_INFO, "    Leaking size   : [%d] bytes\n", pOsMemHeap->mHeapSize - (busySize + freeSize));
    }

    return freeSize;
}

MRVL_VOID  PrintFreeSpace(POsMemHeap pOsMemHeap)
{
    struct list_head    *pos;
    PMEMORY_ALLOCATION  pAllocation;

    fprintf(stderr, "Memory Heap Status :\n");

    if (!list_empty(&pOsMemHeap->mAvailableAllocationList))
    {
        list_for_each(pos, &pOsMemHeap->mAvailableAllocationList)
        {          
            pAllocation = list_entry(pos, MEMORY_ALLOCATION, list_entry);
            
            xf86DrvMsg(0, X_INFO, "    Free addr      : [%X] \n", pAllocation->LinearAddress);
            xf86DrvMsg(0, X_INFO, "    Free size      : [%d] bytes\n\n", pAllocation->AllocationSize);
            xf86DrvMsg(0, X_INFO, "    Free end addr  : [%X] \n\n", pAllocation->LinearAddress + pAllocation->AllocationSize);
        }
    }    
}
