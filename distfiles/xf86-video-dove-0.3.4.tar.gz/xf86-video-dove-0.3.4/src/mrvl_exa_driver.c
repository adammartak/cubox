/******************************************************************************
//(C) Copyright 2009 Marvell International Ltd.
//All Rights Reserved
******************************************************************************/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "xf86.h"
#include <X11/Xmd.h>
#include "fb.h"
#include "xf86.h"
#include <video/dovefb.h>
#include <sys/ioctl.h>

#include "dovefb_driver.h"

#if MRVL_EXA_PERF_PROFILING
static char* mrvlExaPictOpNames[] = {
  "PictOpClear",
  "PictOpSrc",
  "PictOpDst",
  "PictOpOver",
  "PictOpOverReverse",
  "PictOpIn",
  "PictOpInReverse",
  "PictOpOut",
  "PictOpOutReverse",
  "PictOpAtop",
  "PictOpAtopReverse",
  "PictOpXor",
  "PictOpAdd"
};
#endif

/*GCU Hal Init Flag*/
static Bool initialized = FALSE;

static const CARD32 mrvlExaRop[16] = {
    /* GXclear        */  ROP_BLACK,            
    /* GXand          */  ROP_DST_AND_SRC,    /* src AND dst */
    /* GXandReverse   */  ROP_SRC_AND_NOT_DST,    /* src AND NOT dst */
    /* GXcopy         */  ROP_SRC,             /* src */
    /* GXandInverted  */  ROP_NOT_SRC_AND_DST,    /* NOT src AND dst */
    /* GXnoop         */  ROP_DST,    /* dst */
    /* GXxor          */  ROP_DST_XOR_SRC,    /* src XOR dst */
    /* GXor           */  ROP_DST_OR_SRC,    /* src OR dst */
    /* GXnor          */  ROP_NOT_SRC_AND_NOT_DST,    /* NOT src AND NOT dst */
    /* GXequiv        */  ROP_NOT_SRC_XOR_DST,    /* NOT src XOR dst */
    /* GXinvert       */  ROP_NOT_DST,    /* NOT dst */
    /* GXorReverse    */  ROP_SRC_OR_NOT_DST,    /* src OR NOT dst */
    /* GXcopyInverted */  ROP_NOT_SRC,    /* NOT src */
    /* GXorInverted   */  ROP_NOT_SRC_OR_DST,    /* NOT src OR dst */
    /* GXnand         */  ROP_NOT_SRC_OR_NOT_DST,    /* NOT src OR NOT dst */
    /* GXset          */  ROP_WHITE              /* 1 */
};


/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
PixmapPtr
mrvlCreateTempPixmap(ScreenPtr pScreen, int width, int height, int bpp)
{            
    return pScreen->CreatePixmap(pScreen, width, height, bpp, 0);
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
void
mrvlDestroyTempPixmap(ScreenPtr pScreen, PixmapPtr pPixmap)
{    
    if (pPixmap != NULL)
    {
        pScreen->DestroyPixmap(pPixmap);
    }
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
Bool
mrvlExaInitHal(ScreenPtr pScreen)
{    
    ScrnInfoPtr     pScrn = xf86Screens[pScreen->myNum];
    gceSTATUS       status;
    MRVLGetPrivate(pScreen);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Initializing Vivante Hal\n");

    if (initialized) {
        return TRUE;
    }

    status = gcoOS_Construct(gcvNULL, &pDev->exaInfo.Os);
    if (status < 0)
    {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Unable to construct OS object, status=%d\n", status);
        return FALSE;
    }

    status = gcoHAL_Construct(gcvNULL, pDev->exaInfo.Os, &pDev->exaInfo.Hal);
    if (status < 0)
    {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Unable to construct HAL object, status=%d\n", status);
        return FALSE;
    }

    status = gcoHAL_Get2DEngine(pDev->exaInfo.Hal, &pDev->exaInfo.Engine2D);
    if (status < 0)
    {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Unable to construct 2D engine object, status=%d\n", status);
        return FALSE;
    }

    status = gcoHAL_QueryVideoMemory(pDev->exaInfo.Hal, 
                                    NULL, 
                                    NULL, 
                                    NULL, 
                                    NULL,
                                    (void **)&pDev->exaInfo.videoMemPhysicalAddr,
                                    &pDev->exaInfo.videoMemSize);
    if (status != gcvSTATUS_OK)
    {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "gcoHAL_QueryVideoMemory fails, status=%d\n", status);
        return FALSE;
    }

    status = gcoHAL_MapMemory(pDev->exaInfo.Hal,
                            (void *)pDev->exaInfo.videoMemPhysicalAddr,
                            pDev->exaInfo.videoMemSize,
                            &pDev->exaInfo.videoMemVirtualAddr);
    if (status != gcvSTATUS_OK)
    {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "gcoHAL_MapMemory fails, status=%d\n", status);
        return FALSE;
    }

    initialized = TRUE;
    
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Initialize vivante Hal objects successfully\n");

    return TRUE;
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
Bool 
mrvlExaShutdownHal(ScreenPtr pScreen)
{
    ScrnInfoPtr     pScrn = xf86Screens[pScreen->myNum];
    gceSTATUS       status;
    MRVLGetPrivate(pScreen);

    if (!initialized)
    {
        return TRUE;
    }

    status = gcoHAL_UnmapMemory(pDev->exaInfo.Hal,
                            (void *)pDev->exaInfo.videoMemPhysicalAddr,
                            pDev->exaInfo.videoMemSize,
                            pDev->exaInfo.videoMemVirtualAddr);
    if (status != gcvSTATUS_OK)
    {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "gcoHAL_MapMemory fails, status=%d\n", status);
    }

    /* Shutdown */
    if ( pDev->exaInfo.Hal != gcvNULL ) 
    {       
        gcoHAL_Commit(pDev->exaInfo.Hal, gcvTRUE);
        gcoHAL_Destroy(pDev->exaInfo.Hal);
        pDev->exaInfo.Hal = gcvNULL;
    }

    if (pDev->exaInfo.Os != gcvNULL) 
    {
        gcoOS_Destroy(pDev->exaInfo.Os);
        pDev->exaInfo.Os = gcvNULL;
    }    

    initialized = FALSE;
    
    return TRUE;
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
#if 0
static gceSURF_FORMAT mrvlExaGetPictFormat(PicturePtr pPict)
{
    switch ( pPict->format ) 
    {
    case PICT_a8r8g8b8:
         return gcvSURF_A8R8G8B8;
    case PICT_x8r8g8b8:
        return gcvSURF_X8R8G8B8;
    case PICT_a8b8g8r8:
        return gcvSURF_A8B8G8R8;
#if MRVL_EXA_XBGR_SUPPORT
    case PICT_x8b8g8r8:
        return gcvSURF_A8R8G8B8;
#else
    case PICT_x8b8g8r8:
        return gcvSURF_X8B8G8R8;
#endif
        /* 24bpp formats */
    case PICT_r8g8b8:
        return gcvSURF_R8G8B8;
    case PICT_b8g8r8:
        return gcvSURF_B8G8R8;  
        /* 16bpp formats */
    case PICT_r5g6b5:
        return gcvSURF_R5G6B5;
    case PICT_b5g6r5:
        return gcvSURF_B5G6R5;
    case PICT_a1r5g5b5:
        return gcvSURF_A1R5G5B5;
    case PICT_x1r5g5b5:
         return gcvSURF_X1R5G5B5;
    case PICT_a1b5g5r5:
        return gcvSURF_A1B5G5R5;
    case PICT_x1b5g5r5:
        return gcvSURF_UNKNOWN;
    case PICT_a4r4g4b4:
        return gcvSURF_A4R4G4B4;
    case PICT_x4r4g4b4:
        return gcvSURF_X4R4G4B4;    
    case PICT_a4b4g4r4:
        return gcvSURF_A4B4G4R4;
    case PICT_x4b4g4r4:
        return gcvSURF_UNKNOWN;

    default:
        return gcvSURF_UNKNOWN;
    }
}
#endif

/*******************************************************************************
mrvlExaPrepareSolid() sets up the driver for doing a solid fill.

Parameters:
        pPixmap     Destination pixmap
        alu     raster operation
        planemask   write mask for the fill
        fg  "foreground" color for the fill

This call should set up the driver for doing a series of solid fills through 
the Solid() call. The alu raster op is one of the GX* graphics functions listed 
in X.h, and typically maps to a similar single-byte "ROP" setting in all hardware. 
The planemask controls which bits of the destination should be affected, and will 
only represent the bits up to the depth of pPixmap. The fg is the pixel value of 
the foreground color referred to in ROP descriptions.

Note that many drivers will need to store some of the data in the driver private 
record, for sending to the hardware with each drawing command.

The mrvlExaPrepareSolid() call is required of all drivers, but it may fail for
any reason. Failure results in a fallback to software rendering. 
*******************************************************************************/
Bool mrvlExaPrepareSolid(PixmapPtr pPixmap, int alu, Pixel planemask, Pixel fgColor)
{
    MRVLGetPrivateByPix(pPixmap);
    MRVLGetPixmapPrivate(pPixmapSurf, pPixmap);

    if (!pDev->UseSolid)
    {
        goto fallback;
    }  

#if MRVL_EXA_PERF_PROFILING
    ++pDev->exaInfo.pm.index.g_SolidCount;
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_SOLID_PREP, 
                        "PERF_SOLID : Prepare->[%d]: pixmap %p, alu %d, planemask %d, fgColor %d\n", 
                        ++pDev->exaInfo.pm.index.g_SolidPrepare, pPixmap, alu, planemask, fgColor);
    perf_start_time(&pDev->exaInfo.pm);
#endif

    pDev->exaInfo.op.solid.pPix             = pPixmap;
    pDev->exaInfo.op.solid.fgColor          = fgColor;
    pDev->exaInfo.op.bNeedFence             = TRUE;

    if (!pDev->UseSoftwareSolid)
    {
        gceSTATUS status;

        status = gco2D_LoadSolidBrush(pDev->exaInfo.Engine2D,
                                pPixmapSurf->format,
                                0,
                                fgColor,
                                planemask);

        if( status != gcvSTATUS_OK )
        {
            MRVL_FALLBACK("mrvlExaPrepareSolid: gco2D_LoadSolidBrush fails\n");
        }

        status = gco2D_SetTarget(pDev->exaInfo.Engine2D, 
                             pPixmapSurf->dwPhyAddr, 
                             pPixmapSurf->iAlignedStride,  
                             gcvSURF_0_DEGREE,
                             0);
        if(status != gcvSTATUS_OK )
        {
            MRVL_FALLBACK("mrvlExaPrepareSolid: gco2D_SetTarget failed. status = %d\n", status);
        }
    }

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_SOLID_PREP, 
                        "PERF_SOLID : Prepare->   end time [%d] us\n", perf_end_time(&pDev->exaInfo.pm));
#endif

    return TRUE;

fallback:

#if MRVL_EXA_PERF_PROFILING
    ++pDev->exaInfo.pm.index.g_SolidCountF;
#endif

    return FALSE;

}


/*******************************************************************************
mrvlExaSolid() performs a solid fill set up in the last PrepareSolid() call.

Parameters:
        pPixmap     destination pixmap
        x1  left coordinate
        y1  top coordinate
        x2  right coordinate
        y2  bottom coordinate

Performs the fill set up by the last PrepareSolid() call, covering the area 
from (x1,y1) to (x2,y2) in pPixmap. Note that the coordinates are in the 
coordinate space of the destination pixmap, so the driver will need to set 
up the hardware's offset and pitch for the destination coordinates according 
to the pixmap's offset and pitch within framebuffer. This likely means using 
mrvlGetPixmapOffset() and exaGetPixmapPitch().

This call is required if PrepareSolid() ever succeeds. 
*******************************************************************************/
void mrvlExaSolid(PixmapPtr pPixmap, int x1, int y1, int x2, int y2)
{
    MRVLGetPrivateByPix(pPixmap);
    MRVLGetPixmapPrivate(pPixmapSurf, pPixmap);

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_SOLID_DO, 
                        "PERF_SOLID : Do->[%d]: pixmap %p, x1 %d, y1 %d, x2 %d, y2 %d \n", 
                        ++pDev->exaInfo.pm.index.g_SolidDo, pPixmap, x1, y1, x2, y2);
    perf_start_time(&pDev->exaInfo.pm);
#endif

    if (pDev->UseSoftwareSolid)
    {
        int             pix_pitch       = pPixmapSurf->iAlignedStride;
        unsigned char   *pixAddr        = pPixmapSurf->pVirtAddr;
        unsigned char   *pixStartAddr   = pixAddr + y1 * pix_pitch  + x1 * pPixmap->drawable.bitsPerPixel/8;
        int     i = 0, j = 0;

        mrvlPrepareAccess(pPixmap, 0);

        for (i = 0; i < (y2 - y1); i++)
        {
            for (j = 0; j < (x2 -x1); j++)
            {
                if (pPixmap->drawable.bitsPerPixel == 16)
                    *((unsigned short *)pixStartAddr + j) = pDev->exaInfo.op.solid.fgColor;
                else if (pPixmap->drawable.bitsPerPixel == 32)
                    *((unsigned long *)pixStartAddr + j) = pDev->exaInfo.op.solid.fgColor;
                else if (pPixmap->drawable.bitsPerPixel == 8)
                    *((unsigned char *)pixStartAddr + j) = pDev->exaInfo.op.solid.fgColor;
            }

            pixStartAddr += pix_pitch;
        }

        mrvlFinishAccess(pPixmap, 0);
    }
    
    if (!pDev->UseSoftwareSolid)
    { 
        gceSTATUS status;
        gcsRECT destRect;
       
        /* Init destination rectangle. */
        destRect.left   = x1;
        destRect.top    = y1;
        destRect.right  = x2;
        destRect.bottom = y2;

        status = gco2D_SetClipping(pDev->exaInfo.Engine2D, &destRect);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlExaSolid: Failed to set clipping, %d line\n", __LINE__);
            return;
        }

        status = gco2D_Blit(pDev->exaInfo.Engine2D, 
                            1, 
                            &destRect, 
                            0xF0, 
                            0xF0, 
                            pPixmapSurf->format);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlExaSolid: Failed to gco2D_blit\n");
            return;
        } 

        if (((x2 - x1) * (y2 - y1)) <= MRVL_EXA_MIN_PIXEL_FENCE_COUNT)
        {
            pDev->exaInfo.op.bNeedFence = FALSE;
        }
   
    }

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_SOLID_DO, 
                        "PERF_SOLID : Do->        end time [%d] us\n", perf_end_time(&pDev->exaInfo.pm));    
#endif
}

/*******************************************************************************
mrvlExaDoneSolid() finishes a set of solid fills.

Parameters:
        pPixmap     destination pixmap.

The DoneSolid() call is called at the end of a series of consecutive Solid() 
calls following a successful PrepareSolid(). This allows drivers to finish
up emitting drawing commands that were buffered, or clean up state from 
PrepareSolid().

This call is required if PrepareSolid() ever succeeds. 
*******************************************************************************/
void mrvlExaDoneSolid(PixmapPtr pPixmap)
{
    MRVLGetPrivateByPix(pPixmap);
    MRVLGetPixmapPrivate(pPixmapSurf, pPixmap);

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_SOLID_DONE, 
                        "PERF_SOLID : Done->[%d] : pixmap %p\n", ++pDev->exaInfo.pm.index.g_SolidDone, pPixmap);
    perf_start_time(&pDev->exaInfo.pm);
#endif

    if (!pDev->UseSoftwareSolid)
    {
        gceSTATUS status;

        if (pDev->exaInfo.op.bNeedFence)
        {
            mrvlFencePoolCommit(pPixmap->drawable.pScreen, pPixmapSurf->pFakeFence);
        }

        status = gco2D_Flush(pDev->exaInfo.Engine2D);
        if ( status != gcvSTATUS_OK )
        {
            xf86DrvMsg(0, X_ERROR, "mrvlExaDoneSolid: gcoSURF_Flush result : %d\n", status);
        }
        
#if MRVL_EXA_PERF_PROFILING
        Bool    reservedValue = pDev->UseCommitStall;

        if (*pDev->exaInfo.pm.pLogConfig & EXA_TRACE_DUMP_IMAGE)
        {
            pDev->UseCommitStall = gcvTRUE;
        }
#endif
        status = gcoHAL_Commit(pDev->exaInfo.Hal, pDev->UseCommitStall ? gcvTRUE : gcvFALSE);            
        if ( status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "gcoHAL_Commit result : %d\n", status);
        }
#if MRVL_EXA_PERF_PROFILING            
        pDev->UseCommitStall = reservedValue;
#endif            
    }
    
#if MRVL_EXA_PERF_PROFILING
    if (*pDev->exaInfo.pm.pLogConfig & EXA_TRACE_DUMP_IMAGE)
    {        
        MRVL_LOG("PERF_SOLID : DUMP index %d\n", pDev->exaInfo.pm.dumpEXAFrameIndex);
        VIVDumpImage(pDev->exaInfo.pm.dumpEXAFileName,
                 &pDev->exaInfo.pm.dumpEXAFrameIndex, 
                 (char *)pPixmapSurf->pVirtAddr, 
                 pPixmapSurf->dwAlignedWidth, 
                 pPixmap->drawable.height,
                 pPixmap->drawable.bitsPerPixel);
    }

    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_SOLID_DONE, 
                        "PERF_SOLID : Done->      end time [%d] us\n", perf_end_time(&pDev->exaInfo.pm));
#endif
}

/*******************************************************************************
mrvlExaPrepareCopy() sets up the driver for doing a copy within video memory.

Parameters:
        pSrcPixmap  source pixmap
        pDstPixmap  destination pixmap
        dx  X copy direction
        dy  Y copy direction
        alu     raster operation
        planemask   write mask for the fill

This call should set up the driver for doing a series of copies from the the 
pSrcPixmap to the pDstPixmap. The dx flag will be positive if the hardware 
should do the copy from the left to the right, and dy will be positive if the 
copy should be done from the top to the bottom. This is to deal with 
self-overlapping copies when pSrcPixmap == pDstPixmap. If your hardware can 
only support blits that are (left to right, top to bottom) or (right to left, 
bottom to top), then you should set EXA_TWO_BITBLT_DIRECTIONS, and EXA will 
break down Copy operations to ones that meet those requirements. The alu raster 
op is one of the GX* graphics functions listed in X.h, and typically maps to 
a similar single-byte "ROP" setting in all hardware. The planemask controls 
which bits of the destination should be affected, and will only represent the 
bits up to the depth of pPixmap.

Note that many drivers will need to store some of the data in the driver 
private record, for sending to the hardware with each drawing command.

The PrepareCopy() call is required of all drivers, but it may fail for any
reason. Failure results in a fallback to software rendering. 
*******************************************************************************/
Bool mrvlExaPrepareCopy(PixmapPtr pSrc, PixmapPtr pDst, int xdir, int ydir, int alu, Pixel planemask)
{
    MRVLGetPrivateByPix(pDst);    
    
    if (!pDev->UseCopy)
    {
        goto fallback;
    }

#if MRVL_EXA_PERF_PROFILING
    ++pDev->exaInfo.pm.index.g_CopyCount;
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_COPY_PREP, 
                        "PERF_COPY  : Prepare->[%d]: pSrc %p, pDst %p, xdir %d, ydir %d, alu %d, mask %d\n", 
                        ++pDev->exaInfo.pm.index.g_CopyPrepare, pSrc, pDst, xdir, ydir, alu, planemask);
    perf_start_time(&pDev->exaInfo.pm);
#endif

    pDev->exaInfo.op.copy.pSrc              = pSrc;
    pDev->exaInfo.op.copy.pDst              = pDst;
    pDev->exaInfo.op.copy.fg_rop            = mrvlExaRop[alu];
    pDev->exaInfo.op.copy.bg_rop            = mrvlExaRop[alu];  
    pDev->exaInfo.op.bNeedFence             = TRUE;     

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_COPY_PREP, 
                        "PERF_COPY  : Prepare->   end time [%d] us\n", perf_end_time(&pDev->exaInfo.pm));
#endif

    return TRUE;

fallback:

#if MRVL_EXA_PERF_PROFILING
    ++pDev->exaInfo.pm.index.g_CopyCountF;
#endif

    return FALSE;
}


/*******************************************************************************
mrvlExaCopy() performs a copy set up in the last PrepareCopy call.

Parameters:
        pDstPixmap  destination pixmap
        srcX    source X coordinate
        srcY    source Y coordinate
        dstX    destination X coordinate
        dstY    destination Y coordinate
        width   width of the rectangle to be copied
        height  height of the rectangle to be copied.

Performs the copy set up by the last PrepareCopy() call, copying the rectangle 
from (srcX, srcY) to (srcX + width, srcY + width) in the source pixmap to the 
same-sized rectangle at (dstX, dstY) in the destination pixmap. Those 
rectangles may overlap in memory, if pSrcPixmap == pDstPixmap. Note that this 
call does not receive the pSrcPixmap as an argument -- if it's needed in this 
function, it should be stored in the driver private during PrepareCopy(). As 
with Solid(), the coordinates are in the coordinate space of each pixmap, so 
the driver will need to set up source and destination pitches and offsets from 
those pixmaps, probably using mrvlGetPixmapOffset() and exaGetPixmapPitch().

This call is required if PrepareCopy ever succeeds. 
*******************************************************************************/
void mrvlExaCopy(PixmapPtr pDst, int srcX, int srcY, int dstX, int dstY, int width, int height)
{
    MRVLGetPrivateByPix(pDst);  
    MRVLGetPixmapPrivate(pSrcPixmapSurf, pDev->exaInfo.op.copy.pSrc);
    MRVLGetPixmapPrivate(pDstPixmapSurf, pDst);  

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_COPY_DO,
                        "PERF_COPY  : Do->[%d]: pDst %p, srcX %d, srcY %d, dstX %d, dstY %d, width %d, height %d\n", 
                        ++pDev->exaInfo.pm.index.g_CopyDo, pDst, srcX, srcY, dstX, dstY, width, height);
    perf_start_time(&pDev->exaInfo.pm);
#endif

    if (pDev->UseSoftwareCopy)
    {
        unsigned long     src_pitch = (unsigned long)pSrcPixmapSurf->iAlignedStride;
        unsigned long     dst_pitch = (unsigned long)pDstPixmapSurf->iAlignedStride;
        unsigned char     *srcAddr  = pSrcPixmapSurf->pVirtAddr;
        unsigned char     *dstAddr  = pDstPixmapSurf->pVirtAddr;
        BoxRec            src_box, dst_box;

        dst_box.x1 = dstX; 
        dst_box.y1 = dstY;
        dst_box.x2 = dstX + width;
        dst_box.y2 = dstY + height;

        src_box.x1 = srcX;
        src_box.y1 = srcY;
        src_box.x2 = srcX + width;
        src_box.y2 = srcY + height;

        mrvlMemcpy(pDev->exaInfo.op.copy.pSrc,
                      pDev->exaInfo.op.copy.pDst,
                      &src_box,
                      &dst_box,
                      srcAddr,
                      src_pitch,
                      dstAddr,
                      dst_pitch);
    }
    else
    {
        gcsRECT     destRect, srcRect;
        gceSTATUS   status;
        ScrnInfoPtr         pScrn = xf86Screens[pDst->drawable.pScreen->myNum];
        xf86CrtcConfigPtr   xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
        int   c;

        /* Init destination rectangle. */
        destRect.left   = dstX;
        destRect.top    = dstY;
        destRect.right  = dstX + width;
        destRect.bottom = dstY + height;

        srcRect.left   = srcX;
        srcRect.top    = srcY;
        srcRect.right  = srcX + width;
        srcRect.bottom = srcY + height;
       
        /* Do the blit. */
        status = gco2D_SetClipping(pDev->exaInfo.Engine2D, &destRect);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlExaCopy: Failed to set dst clipping, %d line\n", __LINE__);
            return;
        }

        status = gcoSURF_Blit(pSrcPixmapSurf->pSurf,
                              pDstPixmapSurf->pSurf,
                              1,
                              &srcRect,
                              &destRect,
                              NULL,
                              pDev->exaInfo.op.copy.fg_rop,
                              pDev->exaInfo.op.copy.bg_rop,
                              gcvSURF_OPAQUE,
                              0,
                              gcvNULL,
                              0);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlExaCopy: Failed to set source rectangle, %d line\n", __LINE__);
            return;
        }     

        if ((width * height) <= MRVL_EXA_MIN_PIXEL_FENCE_COUNT)
        {
            pDev->exaInfo.op.bNeedFence = FALSE;
        }   

        /*  If current rotaion is not 0 degree, need to report damage by driver. 
            We would better to find a better solution for this issue. */
        for (c = 0; c < xf86_config->num_crtc; c++)
        {
            if (xf86_config->crtc[c]->rotation != RR_Rotate_0)
            {
                mrvlMarkPixmapDirty(&pDst->drawable, dstX, dstY, dstX + width, dstY + height);
                break;
            }
        }
    }        

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_COPY_DO, 
                        "PERF_COPY  : Do->        end time [%d] us\n", perf_end_time(&pDev->exaInfo.pm));
#endif
  
}

/*******************************************************************************
mrvlExaDoneCopy() finishes a set of copies.

Parameters:
        pDstPixmap  destination pixmap.

The DoneCopy() call is called at the end of a series of consecutive Copy() 
calls following a successful PrepareCopy(). This allows drivers to finish 
up emitting drawing commands that were buffered, or clean up state from 
PrepareCopy().

This call is required if PrepareCopy() ever succeeds.  
*******************************************************************************/
void
mrvlExaDoneCopy(PixmapPtr       pDstPixmap)
{
    MRVLGetPrivateByPix(pDstPixmap); 
    MRVLGetPixmapPrivate(pSrcPixmapSurf, pDev->exaInfo.op.copy.pSrc);
    MRVLGetPixmapPrivate(pDstPixmapSurf, pDev->exaInfo.op.copy.pDst);

#if MRVL_EXA_PERF_PROFILING
    ++pDev->exaInfo.pm.index.g_CopyCount;
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_COPY_DONE, 
                        "PERF_COPY  : Done->[%d]: pDst %p\n", ++pDev->exaInfo.pm.index.g_CopyDone, pDstPixmap);
    perf_start_time(&pDev->exaInfo.pm);
#endif

    if (!pDev->UseSoftwareCopy)
    {
        gceSTATUS status;

        if (pDev->exaInfo.op.bNeedFence)
        {
            mrvlFencePoolCommit(pDstPixmap->drawable.pScreen, pSrcPixmapSurf->pFakeFence);
            mrvlFencePoolCommit(pDstPixmap->drawable.pScreen, pDstPixmapSurf->pFakeFence);
        }

        status = gco2D_Flush(pDev->exaInfo.Engine2D);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "gcoSURF_Flush result : %d\n", status);
        }

#if MRVL_EXA_PERF_PROFILING
        Bool    reservedValue = pDev->UseCommitStall;

        if (*pDev->exaInfo.pm.pLogConfig & EXA_TRACE_DUMP_IMAGE)
        {
            pDev->UseCommitStall = gcvTRUE;
        }
#endif
        status = gcoHAL_Commit(pDev->exaInfo.Hal, pDev->UseCommitStall ? gcvTRUE : gcvFALSE); 
        
#if MRVL_EXA_PERF_PROFILING
        pDev->UseCommitStall = reservedValue;
#endif
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "gcoHAL_Commit result : %d\n", status);
        }

    }

#if MRVL_EXA_PERF_PROFILING
    if (*pDev->exaInfo.pm.pLogConfig & EXA_TRACE_DUMP_IMAGE)
    {      
        MRVL_LOG("PERF_COPY  : DUMP SRC %d\n", pDev->exaInfo.pm.dumpEXAFrameIndex);
        VIVDumpImage(pDev->exaInfo.pm.dumpEXAFileName,
                 &pDev->exaInfo.pm.dumpEXAFrameIndex, 
                 (char *)pSrcPixmapSurf->pVirtAddr, 
                 pSrcPixmapSurf->dwAlignedWidth, 
                 pDev->exaInfo.op.copy.pSrc->drawable.height,
                 pDev->exaInfo.op.copy.pSrc->drawable.bitsPerPixel);

        MRVL_LOG("PERF_COPY  : DUMP DST: %d\n", pDev->exaInfo.pm.dumpEXAFrameIndex);
        VIVDumpImage(pDev->exaInfo.pm.dumpEXAFileName,
                 &pDev->exaInfo.pm.dumpEXAFrameIndex, 
                 (char *)pDstPixmapSurf->pVirtAddr, 
                 pDstPixmapSurf->dwAlignedWidth, 
                 pDev->exaInfo.op.copy.pDst->drawable.height,
                 pDev->exaInfo.op.copy.pDst->drawable.bitsPerPixel);
    }

    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_COPY_DONE, 
                        "PERF_COPY  : Done->      end time [%d] us\n", perf_end_time(&pDev->exaInfo.pm));
#endif
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
static void
mrvlTransformPoint(PictTransform *transform, xPointFixed *point)
{
    PictVector v;

    v.vector[0] = point->x;
    v.vector[1] = point->y;
    v.vector[2] = xFixed1;
 
    PictureTransformPoint(transform, &v);

    point->x = v.vector[0];
    point->y = v.vector[1];
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
static Bool
mrvlCheckPictureFormat(PictFormatShort format, int type)
{
    if (format == PICT_x8b8g8r8)
    {
        return FALSE;
    }
    else
    {
	    return TRUE;
    }
}


/*******************************************************************************
mrvlExaCheckComposite() checks to see if a composite operation could be accelerated.

Parameters:
        op  Render operation
        pSrcPicture     source Picture
        pMaskPicture    mask picture
        pDstPicture     destination Picture

The CheckComposite() call checks if the driver could handle acceleration of op with
the given source, mask, and destination pictures. This allows drivers to check source 
and destination formats, supported operations, transformations, and component alpha 
state, and send operations it can't support to software rendering early on. This avoids 
costly pixmap migration to the wrong places when the driver can't accelerate operations. 
Note that because migration hasn't happened, the driver can't know during CheckComposite() 
what the offsets and pitches of the pixmaps are going to be.

See PrepareComposite() for more details on likely issues that drivers will have in 
accelerating Composite operations.

The CheckComposite() call is recommended if PrepareComposite() is implemented, 
but is not required. 
*******************************************************************************/
Bool
mrvlExaCheckComposite(int op, PicturePtr pSrcPict, PicturePtr pMaskPict, PicturePtr pDstPict)
{    
#if MRVL_EXA_PERF_PROFILING
    MRVLGetPrivate(pDstPict->pDrawable->pScreen);

    ++pDev->exaInfo.pm.index.g_CompositeCount;
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_COMP_CHECK, 
                        "PERF_COMP  : Check-> [%d]: op %s, pSrcPict %p, pMaskPict %p, pDstPict %p\n", 
                        ++pDev->exaInfo.pm.index.g_CompCheck, mrvlExaPictOpNames[op], pSrcPict, pMaskPict, pDstPict);
    perf_start_time(&pDev->exaInfo.pm);
#endif

    if (pMaskPict && pMaskPict->transform != NULL)
    {
        MRVL_FALLBACK("mrvlExaCheckComposite: Unsupported mask transform\n");
    }

#if MRVL_EXA_XBGR_SUPPORT == 0
	/* Check the color formats. */
	if (!mrvlCheckPictureFormat(pSrcPict->format, 0))
	{
        MRVL_FALLBACK("mrvlExaCheckComposite: Unsupported src picture format\n");
	}
#endif

	if (!mrvlCheckPictureFormat(pDstPict->format, 1))
	{
        MRVL_FALLBACK("mrvlExaCheckComposite: Unsupported dst picture format\n");
	}

	if (pMaskPict && !mrvlCheckPictureFormat(pMaskPict->format, 2))
	{
        MRVL_FALLBACK("mrvlExaCheckComposite: Unsupported mask picture format\n");
	}

	/* Check the supported operations. */
	if (op > (mrvlGetBlendOperationSize()/sizeof(BlendOp)))
	{
        MRVL_FALLBACK("mrvlExaCheckComposite: Unsupported blend op\n");
	}

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_COMP_CHECK,
                        "PERF_COMP  : Check->     end time [%d] us\n", perf_end_time(&pDev->exaInfo.pm));
#endif

    return TRUE;

fallback:

#if MRVL_EXA_PERF_PROFILING
    ++pDev->exaInfo.pm.index.g_CompositeCountF;
#endif

    return FALSE;
}


/*******************************************************************************
mrvlExaPrepareComposite() sets up the driver for doing a Composite operation described 
in the Render extension protocol spec.

Parameters:
        op  Render operation
        pSrcPicture     source Picture
        pMaskPicture    mask picture
        pDstPicture     destination Picture
        pSrc    source pixmap
        pMask   mask pixmap
        pDst    destination pixmap

This call should set up the driver for doing a series of Composite operations, 
as described in the Render protocol spec, with the given pSrcPicture, 
pMaskPicture, and pDstPicture. The pSrc, pMask, and pDst are the pixmaps 
containing the pixel data, and should be used for setting the offset and 
pitch used for the coordinate spaces for each of the Pictures.

Notes on interpreting Picture structures:

    * The Picture structures will always have a valid pDrawable.
    * The Picture structures will never have alphaMap set.
    * The mask Picture (and therefore pMask) may be NULL, in which case the 
      operation is simply src OP dst instead of src IN mask OP dst, and mask 
      coordinates should be ignored.
    * pMaskPicture may have componentAlpha set, which greatly changes the 
      behavior of the Composite operation. componentAlpha has no effect 
      when set on pSrcPicture or pDstPicture.
    * The source and mask Pictures may have a transformation set 
      (Picture->transform != NULL), which means that the source coordinates 
      should be transformed by that transformation, resulting in scaling, 
      rotation, etc. The PictureTransformPoint() call can transform coordinates 
      for you. Transforms have no effect on Pictures when used as a destination.
    * The source and mask pictures may have a filter set. PictFilterNearest 
      and PictFilterBilinear are defined in the Render protocol, but others 
      may be encountered, and must be handled correctly (usually by 
      PrepareComposite failing, and falling back to software). Filters have no 
      effect on Pictures when used as a destination.
    * The source and mask Pictures may have repeating set, which must be respected. 
      Many chipsets will be unable to support repeating on pixmaps that have a 
      width or height that is not a power of two.

If your hardware can't support source pictures (textures) with non-power-of-two 
pitches, you should set EXA_OFFSCREEN_ALIGN_POT.

Note that many drivers will need to store some of the data in the driver 
private record, for sending to the hardware with each drawing command.

The PrepareComposite() call is not required. However, it is highly recommended 
for performance of antialiased font rendering and performance of cairo applications. 
Failure results in a fallback to software rendering.   
*******************************************************************************/
Bool
mrvlExaPrepareComposite(int op, 
                        PicturePtr pSrcPict, PicturePtr pMaskPict, PicturePtr pDstPict, 
                        PixmapPtr  pSrc, PixmapPtr pMask, PixmapPtr pDst)
{
    MRVLGetPrivateByPix(pDst);
#if MRVL_EXA_XBGR_SUPPORT
    MRVLGetPixmapPrivate(pSrcPixmapSurf, pSrc);
#endif


#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_COMP_PREP, 
                        "PERF_COMP  : Prepare->[%d]: op %s, pSrcPict %p, pMaskPict %p, pDstPict %p, pSrc %p, pDst %p, pDst %p\n", 
                        ++pDev->exaInfo.pm.index.g_CompPrepare, mrvlExaPictOpNames[op], pSrcPict, pMaskPict, pDstPict, pSrc, pMask, pDst);
    perf_start_time(&pDev->exaInfo.pm);
#endif

    if (!pDev->UseComposite)
    {
        goto fallback;
    }

#if MRVL_EXA_XBGR_SUPPORT
    if (pSrcPict->format == PICT_x8b8g8r8)
    {
        if (!pSrcPixmapSurf->bRBWrapped)
        {
            mrvlWrapRBChannel(pSrcPixmapSurf->pSurf, 
                          (unsigned int *)(pSrcPixmapSurf->pVirtAddr));

            pSrcPixmapSurf->bRBWrapped = TRUE;
        }
    }
#endif

    // FIX ME: need to handle this case in future. 3D pipe line is required for this case.
    if (pSrcPict->repeat == 1 && 
        pSrcPict->repeatType != RepeatNormal && 
        (pSrc->drawable.width > 1 ||
        pSrc->drawable.height > 1) )
    {
        MRVL_FALLBACK("mrvlExaPrepareComposite: Unsuppored repeat case, repeat %d, type %d\n", pSrcPict->repeat, pSrcPict->repeatType);
    }
    
    pDev->exaInfo.op.composite.op               = op;
    pDev->exaInfo.op.composite.pSrc             = pSrc;
    pDev->exaInfo.op.composite.pDst             = pDst;
    pDev->exaInfo.op.composite.pMask            = pMask;
    pDev->exaInfo.op.composite.pSrcPict         = pSrcPict;
    pDev->exaInfo.op.composite.pDstPict         = pDstPict;
    pDev->exaInfo.op.composite.pMaskPict        = pMaskPict;
    pDev->exaInfo.op.bNeedFence                 = TRUE;

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_COMP_PREP, 
                        "PERF_COMP  : Prepare->   end time [%d] us\n", perf_end_time(&pDev->exaInfo.pm));
#endif
    	
    return TRUE;

fallback:

#if MRVL_EXA_PERF_PROFILING
    ++pDev->exaInfo.pm.index.g_CompositeCountF;
#endif

    return FALSE;
}

/*******************************************************************************
Composite() performs a Composite operation set up in the last PrepareComposite() call.

Parameters:
        pDstPixmap  destination pixmap
        srcX    source X coordinate
        srcY    source Y coordinate
        maskX   source X coordinate
        maskY   source Y coordinate
        dstX    destination X coordinate
        dstY    destination Y coordinate
        width   destination rectangle width
        height  destination rectangle height

Performs the Composite operation set up by the last PrepareComposite() call, to the 
rectangle from (dstX, dstY) to (dstX + width, dstY + height) in the destination Pixmap. 
Note that if a transformation was set on the source or mask Pictures, the source 
rectangles may not be the same size as the destination rectangles and filtering. 
Getting the coordinate transformation right at the subpixel level can be tricky, 
and rendercheck can test this for you.

This call is required if PrepareComposite() ever succeeds. 
*******************************************************************************/
void
mrvlExaComposite(PixmapPtr pDst, int srcX, int srcY, int maskX, int maskY, int dstX, int dstY, int width, int height)
{    
	gcsRECT             srcRect, dstRect, maskRect;
    Bool                bSrcRepeat = FALSE;
    xPointFixed         srcTopLeft, srcTopRight, srcBottomLeft, srcBottomRight;
    xPointFixed         maskTopLeft, maskTopRight, maskBottomLeft, maskBottomRight;
	MRVLGetPrivateByPix(pDst);    
    ScrnInfoPtr         pScrn = xf86Screens[pDst->drawable.pScreen->myNum];
    xf86CrtcConfigPtr   xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
    int                 c;
    Bool                bRotation = FALSE;
    gceSURF_ROTATION    rotationDegree = gcvSURF_0_DEGREE;
    
    MRVLGetPixmapPrivate(pSrcPixmapSurf, pDev->exaInfo.op.composite.pSrc);
    MRVLGetPixmapPrivate(pDstPixmapSurf, pDev->exaInfo.op.composite.pDst); 
    MRVLGetPixmapPrivate(pRepeatPixmapSurf, pDev->exaInfo.repeatPixmap);
    MRVLGetPixmapPrivate(pAlphaPixmapSurf, pDev->exaInfo.alphaPixmap);
    MRVLGetPixmapPrivate(pTempMaskPixmapSurf, pDev->exaInfo.maskPixmap);

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_COMP_DO, 
                        "PERF_COMP  : Do->[%d]: pDst %p, srcX %d, srcY %d, maskX %d, maskY %d, dstX %d, dstY %d, width %d, height %d\n", 
                        ++pDev->exaInfo.pm.index.g_CompDo, pDst, srcX, srcY, maskX, maskY, dstX, dstY, width, height);
    perf_start_time(&pDev->exaInfo.pm);
#endif

    for (c = 0; c < xf86_config->num_crtc; c++)
    {        
        if (pDev->controller[c].crtc_rotate_mem == pDstPixmapSurf->pVirtAddr)
        {
            bRotation = TRUE;

            switch ((xf86_config->crtc[c])->rotation)
            {
                case RR_Rotate_0:
                    rotationDegree = gcvSURF_0_DEGREE;
                    break;
                case RR_Rotate_90:
                    rotationDegree = gcvSURF_270_DEGREE;
                    break;
                case RR_Rotate_180:
                    rotationDegree = gcvSURF_180_DEGREE;
                    break;
                case RR_Rotate_270:
                    rotationDegree = gcvSURF_90_DEGREE;
                    break;
            }

            break;
        }
    }

    // patch for full screen pixmap
    if (bRotation)
    {        
        srcTopLeft.x               = IntToxFixed(srcX);
        srcTopLeft.y               = IntToxFixed(srcY);
        srcTopRight.x              = IntToxFixed(srcX + width);
        srcTopRight.y              = IntToxFixed(srcY);
        srcBottomLeft.x            = IntToxFixed(srcX);
        srcBottomLeft.y            = IntToxFixed(srcY + height);
        srcBottomRight.x           = IntToxFixed(srcX + width);
        srcBottomRight.y           = IntToxFixed(srcY + height);

        mrvlTransformPoint(&pDev->exaInfo.op.composite.pSrcPict->transform[0], &srcTopLeft);
        mrvlTransformPoint(&pDev->exaInfo.op.composite.pSrcPict->transform[0], &srcTopRight);
        mrvlTransformPoint(&pDev->exaInfo.op.composite.pSrcPict->transform[0], &srcBottomLeft);
        mrvlTransformPoint(&pDev->exaInfo.op.composite.pSrcPict->transform[0], &srcBottomRight);

        switch ((xf86_config->crtc[c])->rotation)
        {
            case RR_Rotate_90:
            srcRect.left   = xFixedToInt(srcBottomLeft.x);
            srcRect.top    = xFixedToInt(srcBottomLeft.y);
            srcRect.right  = xFixedToInt(srcTopRight.x);
            srcRect.bottom = xFixedToInt(srcTopRight.y);
            break;

            case RR_Rotate_180:
            srcRect.left   = xFixedToInt(srcBottomRight.x);
            srcRect.top    = xFixedToInt(srcBottomRight.y);
            srcRect.right  = xFixedToInt(srcTopLeft.x);
            srcRect.bottom = xFixedToInt(srcTopLeft.y);
            break;

            case RR_Rotate_270:
            srcRect.left   = xFixedToInt(srcTopRight.x);
            srcRect.top    = xFixedToInt(srcTopRight.y);
            srcRect.right  = xFixedToInt(srcBottomLeft.x);
            srcRect.bottom = xFixedToInt(srcBottomLeft.y);
            break;

            default:
            return;
        }

        if (srcRect.left < 0)
        {
            srcRect.left += 1;
            srcRect.right += 1;
        }

        if (srcRect.top < 0)
        {
            srcRect.top += 1;
            srcRect.bottom += 1;
        }

        dstRect.left   = dstX;
        dstRect.top    = dstY;
        dstRect.right  = dstX + width;
        dstRect.bottom = dstY + height;

        mrvlGeneralRotationBlit(pDev->exaInfo.Engine2D,
                                pSrcPixmapSurf->pSurf,
                                pDstPixmapSurf->pSurf,                                
                                NULL,
                                &srcRect,
                                &dstRect,
                                rotationDegree);
        return ;
    }

    srcTopLeft.x               = IntToxFixed(srcX);
    srcTopLeft.y               = IntToxFixed(srcY);
    srcTopRight.x              = IntToxFixed(srcX + width);
    srcTopRight.y              = IntToxFixed(srcY);
    srcBottomLeft.x            = IntToxFixed(srcX);
    srcBottomLeft.y            = IntToxFixed(srcY + height);
    srcBottomRight.x           = IntToxFixed(srcX + width);
    srcBottomRight.y           = IntToxFixed(srcY + height);

    if (pDev->exaInfo.op.composite.pSrcPict->transform != NULL)
    {        
        mrvlTransformPoint(&pDev->exaInfo.op.composite.pSrcPict->transform[0], &srcTopLeft);
        mrvlTransformPoint(&pDev->exaInfo.op.composite.pSrcPict->transform[0], &srcTopRight);
        mrvlTransformPoint(&pDev->exaInfo.op.composite.pSrcPict->transform[0], &srcBottomLeft);
        mrvlTransformPoint(&pDev->exaInfo.op.composite.pSrcPict->transform[0], &srcBottomRight);

        srcRect.left   = xFixedToInt(srcTopLeft.x);
        srcRect.top    = xFixedToInt(srcTopLeft.y);
        srcRect.right  = xFixedToInt(srcBottomRight.x);
        srcRect.bottom = xFixedToInt(srcBottomRight.y);
    }
    else
    {
        srcRect.left   = srcX;
	    srcRect.top    = srcY;
	    srcRect.right  = srcX + width;
	    srcRect.bottom = srcY + height;
    }		

    if (pDev->exaInfo.op.composite.pMaskPict)
    {
        maskTopLeft.x               = IntToxFixed(maskX);
        maskTopLeft.y               = IntToxFixed(maskY);
        maskTopRight.x              = IntToxFixed(maskX + width);
        maskTopRight.y              = IntToxFixed(maskY);
        maskBottomLeft.x            = IntToxFixed(maskX);
        maskBottomLeft.y            = IntToxFixed(maskY + height);
        maskBottomRight.x           = IntToxFixed(maskX + width);
        maskBottomRight.y           = IntToxFixed(maskY + height);

        if (pDev->exaInfo.op.composite.pMaskPict->transform != NULL)
        {
            mrvlTransformPoint(&pDev->exaInfo.op.composite.pMaskPict->transform[0], &maskTopLeft);
            mrvlTransformPoint(&pDev->exaInfo.op.composite.pMaskPict->transform[0], &maskTopRight);
            mrvlTransformPoint(&pDev->exaInfo.op.composite.pMaskPict->transform[0], &maskBottomLeft);
            mrvlTransformPoint(&pDev->exaInfo.op.composite.pMaskPict->transform[0], &maskBottomRight);

            maskRect.left   = xFixedToInt(maskTopLeft.x);
            maskRect.top    = xFixedToInt(maskTopLeft.y);
            maskRect.right  = xFixedToInt(maskBottomRight.x);
            maskRect.bottom = xFixedToInt(maskBottomRight.y);
        }
        else
        {
            maskRect.left   = maskX;
	        maskRect.top    = maskY;
	        maskRect.right  = maskX + width;
	        maskRect.bottom = maskY + height;
        }
    }

	dstRect.left   = dstX;
	dstRect.top    = dstY;
	dstRect.right  = dstX + width;
	dstRect.bottom = dstY + height;

    if (pDev->exaInfo.op.composite.pSrcPict->pDrawable && 
        pDev->exaInfo.op.composite.pSrcPict->repeat && 
        !pDev->exaInfo.op.composite.pSrcPict->transform)
    {               
        // FIX ME: need to resize the rectangle of source surface.
        if (srcX >= 0 &&
	        (srcX + width) >= pDev->exaInfo.op.composite.pSrc->drawable.width && 
	        srcY >= 0 &&
	        (srcY + height) >= pDev->exaInfo.op.composite.pSrc->drawable.height && 
            pDev->exaInfo.op.composite.pSrc->drawable.width == 1 && 
            pDev->exaInfo.op.composite.pSrc->drawable.height == 1)
        {
            srcRect.left   = 0;
	        srcRect.top    = 0;
	        srcRect.right  = 1;
	        srcRect.bottom = 1;
        }
        else
        {            
            if (!mrvlGeneralRepeatBlt(pDev->exaInfo.op.composite.pSrcPict->repeatType,
                                pDev->exaInfo.Engine2D,
                                pDev->exaInfo.op.composite.pSrc->drawable.width,
                                pDev->exaInfo.op.composite.pSrc->drawable.height,
                                pSrcPixmapSurf->pSurf,
                                pRepeatPixmapSurf->pSurf,
                                &srcRect))
            {
                xf86DrvMsg(0, X_ERROR, "mrvlExaComposite: mrvlGeneralRepeatBlt fails\n");
                return;
            }            

            bSrcRepeat = TRUE;

        }
    }

    if (pDev->exaInfo.op.composite.pMaskPict)
    {        
        MRVLGetPixmapPrivate(pMaskPixmapSurf, pDev->exaInfo.op.composite.pMask);
        
        mrvlAlphaBlendBlt(PictOpIn,
                        pDev->exaInfo.Engine2D,
                        bSrcRepeat ? pRepeatPixmapSurf->pSurf : pSrcPixmapSurf->pSurf,
                        pMaskPixmapSurf->pSurf,
                        pAlphaPixmapSurf->pSurf,
                        pTempMaskPixmapSurf->pSurf,
                        &srcRect, 
                        &maskRect,
                        TRUE
                        );
    }

    mrvlAlphaBlendBlt(pDev->exaInfo.op.composite.op,
                    pDev->exaInfo.Engine2D,
                    pDev->exaInfo.op.composite.pMaskPict ? pTempMaskPixmapSurf->pSurf : 
                            ( bSrcRepeat ? pRepeatPixmapSurf->pSurf : pSrcPixmapSurf->pSurf),
                    pDstPixmapSurf->pSurf,
                    pAlphaPixmapSurf->pSurf,
                    pTempMaskPixmapSurf->pSurf,
                    pDev->exaInfo.op.composite.pMaskPict ?  &maskRect : &srcRect, 
                    &dstRect,
                    FALSE
                    );

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_COMP_DO, 
                        "PERF_COMP  : Do->        end time [%d] us\n", perf_end_time(&pDev->exaInfo.pm));
#endif
    
    return;
}

/*******************************************************************************
mrvlExaDoneComposite() finishes a set of Composite operations.

Parameters:
        pPixmap     destination pixmap.

The DoneComposite() call is called at the end of a series of consecutive 
Composite() calls following a successful PrepareComposite(). This allows 
drivers to finish up emitting drawing commands that were buffered, or 
clean up state from PrepareComposite().

This call is required if PrepareComposite() ever succeeds. 
*******************************************************************************/
void 
mrvlExaDoneComposite(PixmapPtr pDst)
{
	MRVLGetPrivateByPix(pDst); 
    gceSTATUS status;
    MRVLGetPixmapPrivate(pSrcPixmapSurf, pDev->exaInfo.op.composite.pSrc);
    MRVLGetPixmapPrivate(pDstPixmapSurf, pDev->exaInfo.op.composite.pDst);

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_COMP_DONE, 
                        "PERF_COMP  : Done->[%d]: pDst %p\n", ++pDev->exaInfo.pm.index.g_CompDone, pDst);
    perf_start_time(&pDev->exaInfo.pm);
#endif

    if (pDev->exaInfo.op.bNeedFence)
    {
        mrvlFencePoolCommit(pDst->drawable.pScreen, pDstPixmapSurf->pFakeFence);
        mrvlFencePoolCommit(pDst->drawable.pScreen, pSrcPixmapSurf->pFakeFence);

        if (pDev->exaInfo.op.composite.pMaskPict)
        {
            MRVLGetPixmapPrivate(pMaskPixmapSurf, pDev->exaInfo.op.composite.pMask);

            mrvlFencePoolCommit(pDst->drawable.pScreen, pMaskPixmapSurf->pFakeFence);
        }
    }

    status = gco2D_Flush(pDev->exaInfo.Engine2D);
    if (status != gcvSTATUS_OK)
    {
        xf86DrvMsg(0, X_ERROR, "gcoSURF_Flush result : %d\n", status);
    }

#if MRVL_EXA_PERF_PROFILING
    Bool    reservedValue = pDev->UseCommitStall;

    if (*pDev->exaInfo.pm.pLogConfig & EXA_TRACE_DUMP_IMAGE)
    {
        pDev->UseCommitStall = gcvTRUE;
    }
#endif
    status = gcoHAL_Commit(pDev->exaInfo.Hal, pDev->UseCommitStall ? gcvTRUE : gcvFALSE); 
    
#if MRVL_EXA_PERF_PROFILING    
    pDev->UseCommitStall = reservedValue;
#endif
    if (status != gcvSTATUS_OK)
    {
        xf86DrvMsg(0, X_ERROR, "gcoHAL_Commit result : %d\n", status);
    }

#if MRVL_EXA_PERF_PROFILING
    if (*pDev->exaInfo.pm.pLogConfig & EXA_TRACE_DUMP_IMAGE)
    {        
        MRVL_LOG("PERF_COMP  : DUMP DST %d\n", pDev->exaInfo.pm.dumpEXAFrameIndex);
        VIVDumpImage(pDev->exaInfo.pm.dumpEXAFileName,
                 &pDev->exaInfo.pm.dumpEXAFrameIndex, 
                 (char *)pDstPixmapSurf->pVirtAddr, 
                 pDstPixmapSurf->dwAlignedWidth, 
                 pDev->exaInfo.op.composite.pDst->drawable.height,
                 pDev->exaInfo.op.composite.pDst->drawable.bitsPerPixel);
    }

    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_COMP_DONE, 
                        "PERF_COMP  : Done->      end time [%d] us\n", perf_end_time(&pDev->exaInfo.pm));
#endif

    return;
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
int 
mrvlMarkSync(ScreenPtr pScreen)
{
    MRVLGetPrivate(pScreen);

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_MARK, 
                        "PERF_MARK  : Mark enter\n");
#endif   

    return ++pDev->exaGCSyncMarker;

}

/*******************************************************************************
mrvlExaWaitMarker() waits for all rendering before the given marker to 
have completed. If the driver does not implement MarkSync(), marker is 
meaningless, and all rendering by the hardware should be completed before 
mrvlExaWaitMarker() returns.

Note that drivers should call exaWaitSync() to wait for all acceleration to 
finish, as otherwise EXA will be unaware of the driver having synchronized, 
resulting in excessive WaitMarker() calls.

WaitMarker() is required of all drivers. 
*******************************************************************************/
void
mrvlExaWaitMarker(ScreenPtr pScreen, int marker)
{
    MRVLGetPrivate(pScreen);

#if MRVL_EXA_PERF_PROFILING == 1
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_WAIT_SYNC, 
                        "PERF_WAIT  : Wait->[%d]: marker \n");
    perf_start_time(&pDev->exaInfo.pm);
#endif

    if (pDev->exaGCMarkerSynced != marker)
    {
        // Sync marker value.
        pDev->exaGCMarkerSynced = marker;
    }

#if MRVL_EXA_PERF_PROFILING == 1
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_WAIT_SYNC, 
                        "PERF_WAIT  : Wait->      end time [%d] us\n", perf_end_time(&pDev->exaInfo.pm));
#endif
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/

Bool    
mrvlPrepareAccess(PixmapPtr pPix, int index)
{
    MRVLGetPixmapPrivate(pPixSurf, pPix);

    // For pixmaps located in system memory, return directly.
    if (!pPixSurf->bOffscreen)
    {
        return TRUE;
    }

#if MRVL_EXA_PERF_PROFILING
    MRVLGetPrivate(pPix->drawable.pScreen);

    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_PREP_ACC, 
                        "PERF_PreAcc: prepare CPU access-> pixmap %p, index %d, DrivPriv %p, marker %d, synced %d\n", 
                        pPix, index, pPixSurf, pPixSurf->pFakeFence->syncMarker, *pPixSurf->pFakeFence->pFenceMarker);
#endif
    
    mrvlFencePoolStall(pPixSurf->pFakeFence);

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_PREP_ACC, 
                        "PERF_PreAcc: end with time [%d] us\n", perf_end_time(&pDev->exaInfo.pm));
#endif

    return TRUE;
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
void    
mrvlFinishAccess(PixmapPtr pPix, int index)
{   
#if MRVL_EXA_PERF_PROFILING
    MRVLGetPrivate(pPix->drawable.pScreen);

    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_FINI_ACC,
                        "PERF_FiniAc: Finish access-> pixmap %p, index %d\n", pPix, index);
#endif
    
    return;    
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
#if MRVL_EXA_ENABLE_UP_DOWNLOAD 
Bool
mrvlExaUploadToScreen(PixmapPtr pDst, int x, int y, int w, int h, char *src, int src_pitch)
{    
#if MRVL_EXA_PERF_PROFILING
    MRVLGetPrivate(pDst->drawable.pScreen);

    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_UPLOAD,
                        "PERF_Upload: Upload to screen-> pDst %p, x %d, y %d, w %d, h %d, src %p, src_pitch %d\n", 
                        pDst, x, y, w, h, src, src_pitch);

    perf_start_time(&pDev->exaInfo.pm);
#endif

#if MRVL_EXA_FORCE_HW_LOAD == 0
    MRVLGetPixmapPrivate(pDstPixmapSurf, pDst);
    Bool ret = TRUE;

    if (*pDstPixmapSurf->pFakeFence->pFenceMarker >= pDstPixmapSurf->pFakeFence->syncMarker)
    {
        //MRVLGetPrivateByPix(pDst);
        int                 dst_pitch = pDstPixmapSurf->iAlignedStride;
        unsigned char       *dstAddr = pDstPixmapSurf->pVirtAddr;

        BoxRec box;

        box.x1 = x; 
        box.y1 = y;
        box.x2 = x + w;
        box.y2 = y + h;

        mrvlMemcpyBox(pDst, &box, (CARD8 *)src, src_pitch, (CARD8 *)dstAddr, dst_pitch, FALSE, TRUE);
    }
    else
#endif
    {
        ret = mrvlImageTransferToScreen(pDst, x, y, w, h, src, src_pitch, 1);
    }

#if MRVL_EXA_PERF_PROFILING   
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_UPLOAD,
                        "PERF_Upload: end with time [%d] us \n", 
                        perf_end_time(&pDev->exaInfo.pm));
#endif

    return ret;
}
#endif

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
#if MRVL_EXA_ENABLE_UP_DOWNLOAD
Bool 
mrvlExaDownloadFromScreen(PixmapPtr pSrc, int x, int y,int w, int h, char *dst, int dst_pitch)
{
#if MRVL_EXA_PERF_PROFILING
    MRVLGetPrivate(pSrc->drawable.pScreen);

    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_DOWNLOAD,
                        "PERF_Download: Download from screen-> pSrc %p, x %d, y %d, w %d, h %d, dst %p, dst_pitch %d\n", 
                        pSrc, x, y, w, h, dst, dst_pitch);

    perf_start_time(&pDev->exaInfo.pm);
#endif
#if MRVL_EXA_FORCE_HW_LOAD == 0
    MRVLGetPixmapPrivate(pSrcPixmapSurf, pSrc);
    Bool    ret = TRUE;

    if (*pSrcPixmapSurf->pFakeFence->pFenceMarker >= pSrcPixmapSurf->pFakeFence->syncMarker)
    {
        //MRVLGetPrivateByPix(pSrc);

        int             src_pitch = pSrcPixmapSurf->iAlignedStride;
        unsigned char   *srcAddr = pSrcPixmapSurf->pVirtAddr;
        
        BoxRec box;

        box.x1 = x; 
        box.y1 = y;
        box.x2 = x + w;
        box.y2 = y + h;

        mrvlMemcpyBox(pSrc, &box, (CARD8 *)srcAddr, src_pitch, (CARD8 *)dst, dst_pitch, TRUE, FALSE);
    
        
    }
    else
#endif
    {
        ret = mrvlImageTransferFromScreen(pSrc, x, y, w, h, dst, dst_pitch, 1);
    }

#if MRVL_EXA_PERF_PROFILING   
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_DOWNLOAD,
                        "PERF_Download: end with time [%d] us \n", 
                        perf_end_time(&pDev->exaInfo.pm));
#endif

    return ret;

}
#endif

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
void *
mrvlExaCreatePixmap2(ScreenPtr pScreen, 
                            int width, 
                            int height,
                            int depth, 
                            int usage_hint, 
                            int bitsPerPixel,
                            int *new_fb_pitch)
{
    MRVLGetPrivate(pScreen);
    MRVLGetScrnInfo(pScreen);
    MRVLDecPixmapPrivate(pPixmapSurf);
    gceSTATUS       status;   
    gceSURF_FORMAT  format = gcvSURF_R5G6B5;    
#if MRVL_EXA_ALLOC_PIXMAP_FROM_SYSTEM
    Bool            bAllocFromSystem = TRUE;
#else
    Bool            bAllocFromSystem = FALSE;
#endif

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_CREATE_PIX2,
                        "PERF_CREATE2: CreatePixmap2->width %d, height %d, depth %d, usage_int %d, bitsPerPixel %d\n", 
                        width, height, depth, usage_hint, bitsPerPixel);
    perf_start_time(&pDev->exaInfo.pm);
#endif
        
    pPixmapSurf = (PixmapSurfacePtr)xalloc(sizeof(PixmapSurface));

    if (!pPixmapSurf)
    {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvlExaCreatePixmap2: Unable to allocate memory for driver private\n");
#if MRVL_EXA_PERF_PROFILING
        MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_CREATE_PIX2,
                        "PERF_CREATE2: CreatePixmap2,  fail to allocate driver private, ->end with [%d] us\n", 
                        perf_end_time(&pDev->exaInfo.pm));
#endif
        return NULL;
    }

    memset(pPixmapSurf, 0, sizeof(PixmapSurface));
    
    pPixmapSurf->iWidth     = width;
    pPixmapSurf->iHeight    = height;
    pPixmapSurf->iDepth     = depth;        

    if (!width || !height)
    {
        pPixmapSurf->bDriverAlloc = FALSE;
        pPixmapSurf->bOffscreen   = FALSE;
#if MRVL_EXA_PERF_PROFILING
        MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_CREATE_PIX2,
                        "PERF_CREATE2: CreatePixmap2,  unresovled width or height, ->end with [%d] us\n", 
                        perf_end_time(&pDev->exaInfo.pm));
#endif         
        return pPixmapSurf;
    }     

    // Now driver needs to allocate memory for pixmap. 
    pPixmapSurf->bDriverAlloc       = TRUE;

    if (bitsPerPixel == 16)
        format = gcvSURF_R5G6B5;
    else if (bitsPerPixel == 32)
        format = gcvSURF_A8R8G8B8;
    else
    {
        // Till now, we can not support other formats. so allocate these pixmaps in system memory space.
        bAllocFromSystem = TRUE;
    }     

    if (bAllocFromSystem)
    {
        size_t      sysPaddedWidth = ((width * depth + FB_MASK) >> FB_SHIFT) * sizeof(FbBits);
        size_t      sysDataSize = height * sysPaddedWidth;

        pPixmapSurf->pVirtAddr  = xalloc(sysDataSize);
        if (pPixmapSurf->pVirtAddr == NULL)
        {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvlExaCreatePixmap2: Unable to allocate memory from system memory\n");
#if MRVL_EXA_PERF_PROFILING
            MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_CREATE_PIX2,
                        "PERF_CREATE2: CreatePixmap2,  faild to allocate memory from system, ->end with [%d] us\n", 
                        perf_end_time(&pDev->exaInfo.pm));
#endif           
            return NULL;
        } 

        *new_fb_pitch                   = sysPaddedWidth;
        pPixmapSurf->dwType             = EXA_PIXMAP_UNSUPPORTED_BPP;
        pPixmapSurf->dwMemorySegment    = MEM_SYSTEM_SEGMENT;        
        pPixmapSurf->bOffscreen         = FALSE;       
    }
    else
    {
        // Otherwise, we allocate memory from video segment.
        pPixmapSurf->format     = format;
        
        status = gcoSURF_Construct(pDev->exaInfo.Hal,
                          width,
                          height,
                          1,
                          gcvSURF_BITMAP,
                          format,
                          gcvPOOL_SYSTEM,
                          &pPixmapSurf->pSurf
                          );
        if( status != gcvSTATUS_OK )
        {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "gcoSURF_Construct failed. file %s, line %d\n", __FILE__, __LINE__);
#if MRVL_EXA_PERF_PROFILING
            MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_CREATE_PIX2,
                        "PERF_CREATE2: CreatePixmap2,  gcoSURF_Construct failed, ->end with [%d] us\n", 
                        perf_end_time(&pDev->exaInfo.pm));
#endif 
            return NULL;
        }  

        status = gcoSURF_Lock(pPixmapSurf->pSurf,   
                              &pPixmapSurf->dwPhyAddr,
                              (gctPOINTER)&pPixmapSurf->pVirtAddr
                              );
        if( status != gcvSTATUS_OK )
        {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "gcoSURF_Lock failed. file %s, line %d\n", __FILE__, __LINE__);
#if MRVL_EXA_PERF_PROFILING
            MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_CREATE_PIX2,
                        "PERF_CREATE2: CreatePixmap2,  gcoSURF_Lock failed, ->end with [%d] us\n", 
                        perf_end_time(&pDev->exaInfo.pm));
#endif 
            return NULL;
        }    

        status = gcoSURF_GetAlignedSize(pPixmapSurf->pSurf,
                                        &pPixmapSurf->dwAlignedWidth,
                                        &pPixmapSurf->dwAlignedHeight,
                                        &pPixmapSurf->iAlignedStride);
        if( status != gcvSTATUS_OK )
        {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "gcoSURF_GetAlignedSize failed. file %s, line %d\n", __FILE__, __LINE__);
#if MRVL_EXA_PERF_PROFILING
            MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_CREATE_PIX2,
                        "PERF_CREATE2: CreatePixmap2,  gcoSURF_GetAlignedSize failed, ->end with [%d] us\n", 
                        perf_end_time(&pDev->exaInfo.pm));
#endif 
            return NULL;
        }         

#if MRVL_EXA_PERF_PROFILING
       //MRVL_LOG("mrvlExaCreatePixmap2->surface lock: virtual %p, physical %X\n", 
       //                     pPixmapSurf->pVirtAddr, pPixmapSurf->dwPhyAddr);
#endif  
       
        pPixmapSurf->pFakeFence = mrvlFencePoolAlloc(&pDev->exaInfo.fakeFencePool); 
        if (pPixmapSurf->pFakeFence == NULL)
        {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Fail to allocate fence. file %s, line %d\n", __FILE__, __LINE__);
#if MRVL_EXA_PERF_PROFILING
            MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_CREATE_PIX2,
                        "PERF_CREATE2: CreatePixmap2,  fail to allocate fence, ->end with [%d] us\n", 
                        perf_end_time(&pDev->exaInfo.pm));
#endif 
            return NULL;
        }

        pPixmapSurf->dwType             = EXA_PIXMAP_CAN_ACCEL_TYPE;
        pPixmapSurf->dwMemorySegment    = MEM_VIDEO_SEGMENT; 
        pPixmapSurf->bOffscreen         = TRUE;

        if (width > VIVANTE_MAX_WIDTH || height > VIVANTE_MAX_HEIGHT)
        {
            pPixmapSurf->dwType         = EXA_PIXMAP_OVERSIZE_TYPE;
            pPixmapSurf->bOffscreen     = FALSE;
        }     

        *new_fb_pitch                   = pPixmapSurf->iAlignedStride;
    }

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_CREATE_PIX2,
                        "PERF_CREATE2: CreatePixmap2     ->end with [%d] us\n", 
                        perf_end_time(&pDev->exaInfo.pm));
#endif

    return (void *)pPixmapSurf;                      
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
Bool
mrvlExaIsLCDFrameBuffer(ScreenPtr pScreen, unsigned char *pData)
{
    MRVLGetPrivate(pScreen);

    return ((unsigned long) ((CARD8 *) pData - (CARD8 *) pDev->exaInfo.ExaDriver->memoryBase) <
	        pDev->exaInfo.ExaDriver->memorySize);
}
/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
Bool 
mrvlModifyPixmapHeader(PixmapPtr pPixmap, int width, int height, int depth, int bitsPerPixel, int devKind, pointer pPixData)
{
    MRVLGetPixmapPrivate(pPixmapSurf, pPixmap);        
    MRVLGetPrivateByPix(pPixmap);
    ScrnInfoPtr     pScrn = xf86Screens[pPixmap->drawable.pScreen->myNum];

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_MODI_HEADER,
                        "PERF_MODIFY: ModifyPixmapHeader-> pixmap %p, pDriverPriv %p, bitsPerPixel %d, depth %d,  width %d, height %d, devKind %d, pPixData %p\n", 
                        pPixmap, pPixmapSurf, bitsPerPixel, depth, width, height, devKind, pPixData);
    perf_start_time(&pDev->exaInfo.pm);
#endif

    if (pPixData == pDev->fbstart)
    {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, 
                        "ModifyPixmapHeader-> pixmap %p, bitsPerPixel %d, depth %d,  width %d, height %d, devKind %d, pPixData %p\n", 
                        pPixmap, bitsPerPixel, depth, width, height, devKind, pPixData);
    }
    
    if (!pPixmap)
    {
	    return FALSE;
	}

    /*
     * If all arguments are specified, reinitialize everything (including
     * validated state).
     */
    if ((width > 0) && 
        (height > 0) && 
        (depth > 0) && 
        (bitsPerPixel > 0) &&
	    (devKind > 0) && 
	    pPixData) 
	{
    	pPixmap->drawable.depth = depth;
    	pPixmap->drawable.bitsPerPixel = bitsPerPixel;
    	pPixmap->drawable.id = 0;
    	pPixmap->drawable.serialNumber = NEXT_SERIAL_NUMBER;
    	pPixmap->drawable.x = 0;
    	pPixmap->drawable.y = 0;
    	pPixmap->drawable.width = width;
    	pPixmap->drawable.height = height;
    	pPixmap->devKind = devKind;
    	pPixmap->refcnt = 1;
    	pPixmap->devPrivate.ptr = pPixData;
    } 
    else 
    {
    	/*
    	 * Only modify specified fields, keeping all others intact.
    	 */
    
    	if (width > 0)
    	{
    	    pPixmap->drawable.width = width;
    	}
    
    	if (height > 0)
    	{
    	    pPixmap->drawable.height = height;
    	}
    
    	if (depth > 0)
    	{
    	    pPixmap->drawable.depth = depth;
    	}
    
    	if (bitsPerPixel > 0)
    	{
    	    pPixmap->drawable.bitsPerPixel = bitsPerPixel;
    	}
    	else if ((bitsPerPixel < 0) && (depth > 0))
    	{
    	    pPixmap->drawable.bitsPerPixel = BitsPerPixel(depth);
    	}
    
    	/*
    	 * CAVEAT:  Non-SI DDXen may use devKind and devPrivate fields for
    	 *          other purposes.
    	 */
    	if (devKind > 0)
    	{
    	    pPixmap->devKind = devKind;
    	}
    	else if ((devKind < 0) && ((width > 0) || (depth > 0)))
    	{
    	    pPixmap->devKind = PixmapBytePad(pPixmap->drawable.width,
    		pPixmap->drawable.depth);
        }
    
    	if (pPixData)
    	{
    	    pPixmap->devPrivate.ptr = pPixData;
    	}
    }    
        
    if (pPixmapSurf->pFakeFence)
    {
        mrvlFencePoolAssignPixmap(pPixmapSurf->pFakeFence, pPixmap);
    }

    pPixmapSurf->pPixmap = pPixmap;
    pPixmapSurf->dwFrameBufferType = LCD_FRAME_NONE;

    if (pPixmapSurf->bDriverAlloc == TRUE)
    {
        pPixmap->devPrivate.ptr = pPixmapSurf->pVirtAddr;
    }

    // We need to map frame buffer and rotate shadow buffer into vivante surface.
    if (mrvlExaIsLCDFrameBuffer(pPixmap->drawable.pScreen, pPixData))
    {
        gceSTATUS       status;
        gceSURF_FORMAT  format;
        unsigned long   memOffset = (CARD8 *) pPixData - (CARD8 *) pDev->exaInfo.ExaDriver->memoryBase;
        
        if (bitsPerPixel == 16)
            format = gcvSURF_R5G6B5;
        else if (bitsPerPixel == 32)
            format = gcvSURF_A8R8G8B8;
        else
        {
            xf86DrvMsg(0, X_ERROR, "mrvlModifyPixmapHeader: Invalid pixmap format\n");
            return FALSE;
        } 
        
        if(pPixmapSurf->pSurf != NULL)
        {
            status = gcoSURF_Destroy(pPixmapSurf->pSurf);
            if( status != gcvSTATUS_OK )
            {
                xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvlModifyPixmapHeader: Destroy primary surface failed.\n");
                return FALSE;
            }
            pPixmapSurf->pSurf = NULL;
        }
        
        status = gcoSURF_Construct(pDev->exaInfo.Hal,
                             pScrn->displayWidth,
                             height,
                             1,
                             gcvSURF_BITMAP,
                             format,
                             gcvPOOL_USER,
                             &pPixmapSurf->pSurf
                            );
        if( status != gcvSTATUS_OK )
        {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvlModifyPixmapHeader: Create primary surface failed.\n");
            return FALSE;
        }  
        
        status = gcoSURF_MapUserSurface(pPixmapSurf->pSurf,
                                        0, 
                                        pDev->fbstart + memOffset,
                                        (int)(pDev->memPhysBase + memOffset)
                                        );    
        if( status != gcvSTATUS_OK )
        {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvlModifyPixmapHeader: Mapping primary surface failed.\n");
            return FALSE;
        }  

        pPixmapSurf->pFakeFence = mrvlFencePoolAlloc(&pDev->exaInfo.fakeFencePool); 
        if (pPixmapSurf->pFakeFence == NULL)
        {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Fail to allocate fence. file %s, line %d\n", __FILE__, __LINE__);
            return FALSE;
        }
        
        if (memOffset == 0)
        {
            pPixmapSurf->dwFrameBufferType       = LCD_FRAME_FRONT_BUFFER; 
        }
        else
        {
            pPixmapSurf->dwFrameBufferType       = LCD_FRAME_SHADOW_BUFFER;     
        }

        pPixmapSurf->dwMemorySegment    = MEM_LCD_FRAME_BUFFER;
        pPixmapSurf->bOffscreen         = TRUE; 
        pPixmapSurf->format             = format;         
        pPixmapSurf->dwAlignedWidth     = pScrn->displayWidth;
        pPixmapSurf->dwAlignedHeight    = height;     
        pPixmapSurf->dwPhyAddr          = pDev->memPhysBase + memOffset;
        pPixmapSurf->pVirtAddr          = pDev->fbstart + memOffset;

        // TODO: shadow buffer????
        pPixmapSurf->iAlignedStride     = pScrn->displayWidth * pScrn->bitsPerPixel / 8;

        // save the virtual address of pixmap.
        pPixmap->devPrivate.ptr = pPixmapSurf->pVirtAddr;

        if (pPixmapSurf->dwFrameBufferType == LCD_FRAME_SHADOW_BUFFER)
        {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Map shadow buffer into vivante surface successfully\n");
        }
        else
        {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Map front buffer into vivante surface successfully\n");
        }
    }
    
#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_MODI_HEADER, 
                        "PERF_MODIFY: Modify->    end time [%d] us\n", perf_end_time(&pDev->exaInfo.pm));
#endif
   
    return TRUE;
}

/*******************************************************************************
* xxx:

*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
void mrvlDestroyPixmap(ScreenPtr pScreen, void *driverPriv)
{
    MRVLDecPixmapPrivate(pPixmapSurf) = (PixmapSurfacePtr)driverPriv;    
    MRVLGetPrivate(pScreen); 
    MRVLGetScrnInfo(pScreen);   
   
    if (!pPixmapSurf)
    {
       xf86DrvMsg(0, X_ERROR, "Destory invalid driver private\n");
       return;
    }

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_DESTROY_PIX, 
                        "PERF_DESTROY: Destroy-> driverPriv %p, pixmap %p\n", 
                        pPixmapSurf, pPixmapSurf->pPixmap);
    perf_start_time(&pDev->exaInfo.pm);
#endif

    // Destory front buffer.
    if (pPixmapSurf->dwFrameBufferType)
    {
        gceSTATUS status;

        //Destroy fence memory.
        if (pPixmapSurf->pFakeFence != NULL)
        {
            // Need to wait GPU ready.
            mrvlFencePoolStall(pPixmapSurf->pFakeFence);
            mrvlFencePoolFree(&pDev->exaInfo.fakeFencePool, pPixmapSurf->pFakeFence);
        }

        if (pPixmapSurf->pSurf != NULL)
        {                                
            status = gcoSURF_Destroy(pPixmapSurf->pSurf);
            if( status != gcvSTATUS_OK )
            {
                xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvlDestroyPixmap: gcoSURF_Destroy failed.\n");                
            }   
        }
    }

    // Detroy pixmaps allocated by driver.
    if (pPixmapSurf->bDriverAlloc)
    {
        gceSTATUS status;

        // System memory
        if (pPixmapSurf->dwMemorySegment == MEM_SYSTEM_SEGMENT)
        {
            xfree(pPixmapSurf->pVirtAddr);
        }

        // Video memory
        if (pPixmapSurf->dwMemorySegment == MEM_VIDEO_SEGMENT)
        {
            //Destroy fence memory.
            if (pPixmapSurf->pFakeFence != NULL)
            {
                // Need to wait GPU ready.
                mrvlFencePoolStall(pPixmapSurf->pFakeFence);
                mrvlFencePoolFree(&pDev->exaInfo.fakeFencePool, pPixmapSurf->pFakeFence);
            }

            if (pPixmapSurf->pSurf != NULL)
            {               
                status = gcoSURF_Unlock(pPixmapSurf->pSurf, NULL);
                if( status != gcvSTATUS_OK )
                {
                    xf86DrvMsg(0, X_ERROR, "gcoSURF_Unlock failed. file %s, line %d\n", __FILE__, __LINE__);
                }  

                status = gcoSURF_Destroy(pPixmapSurf->pSurf);
                if( status != gcvSTATUS_OK )
                {
                    xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvlDestroyPixmap: gcoSURF_Destroy failed.\n");                
                }   
            }
        }
    }    

    xfree(driverPriv);

#if MRVL_EXA_PERF_PROFILING
    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_DESTROY_PIX, 
                        "PERF_DESTROY: Destroy->   end time [%d] us\n", perf_end_time(&pDev->exaInfo.pm));
#endif
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
static Bool 
mrvlPixmapIsOffscreen(PixmapPtr pPix)
{
    MRVLGetPixmapPrivate(pPixSurf, pPix);   
    ScreenPtr   pScreen = pPix->drawable.pScreen;

#if MRVL_EXA_PERF_PROFILING
    MRVLGetPrivate(pPix->drawable.pScreen);

    MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_OFFSCREEN, 
                        "PERF_OFFSCR: Offscreen-> pixmap %p\n", pPix);
    perf_start_time(&pDev->exaInfo.pm);
#endif

    // The front buffer is always in memory and pinned.
    if (pScreen->GetScreenPixmap(pScreen) == pPix)
    {
#if MRVL_EXA_PERF_PROFILING
        MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_OFFSCREEN, 
                            "PERF_OFFSCR: Offscreen-> end time [%d] us, front buffer \n", perf_end_time(&pDev->exaInfo.pm));
#endif
        return TRUE;
    }

    if (pPixSurf &&         
        pPixSurf->bOffscreen == TRUE)
    {        
#if MRVL_EXA_PERF_PROFILING
        MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_OFFSCREEN, 
                            "PERF_OFFSCR: Offscreen-> end time [%d] us, offscreen buffer \n", perf_end_time(&pDev->exaInfo.pm));
#endif       
        return TRUE;        
    }
    else
    {
#if MRVL_EXA_PERF_PROFILING
        MRVL_FERF_TRACE_LOG(&pDev->exaInfo.pm, EXA_TRACE_OFFSCREEN, 
                            "PERF_OFFSCR: Offscreen-> end time [%d] us, system buffer \n", perf_end_time(&pDev->exaInfo.pm));
#endif
        return FALSE;
    }
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
Bool
mrvlExaInit(ScreenPtr pScreen)
{    
    MRVLGetPrivate(pScreen);
    MRVLGetScrnInfo(pScreen);
    ExaDriverPtr    pExa;
    Bool            ret;
    xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);

    xf86DrvMsg(pScreen->myNum, X_INFO, "mrvlExaInit: Initializing EXA interface \n");

    pExa = exaDriverAlloc();
    if (!pExa) {
        xf86DrvMsg(pScreen->myNum, X_ERROR, "mrvlExaInit: Unable to allocate exa driver\n");
        pDev->UseExa = FALSE;
        return FALSE;
    }
    
    pDev->exaInfo.ExaDriver = pExa;
    
    pExa->exa_major         = EXA_VERSION_MAJOR;
    pExa->exa_minor         = EXA_VERSION_MINOR;

#if MRVL_EXA_MODE == 1 // Classic
    pExa->flags             = EXA_OFFSCREEN_PIXMAPS;
    xf86DrvMsg(pScreen->myNum, X_ERROR, "EXA: Classic Mode\n");
#elif MRVL_EXA_MODE == 2 // Driver
    pExa->flags             = EXA_HANDLES_PIXMAPS | EXA_OFFSCREEN_PIXMAPS;
#ifdef EXA_SUPPORTS_PREPARE_AUX
    pExa->flags             |= EXA_SUPPORTS_PREPARE_AUX;
#endif
    xf86DrvMsg(pScreen->myNum, X_ERROR, "EXA: Driver Mode\n");
#else // Mixed
    pExa->flags             = EXA_HANDLES_PIXMAPS | EXA_MIXED_PIXMAPS | EXA_OFFSCREEN_PIXMAPS;
    xf86DrvMsg(pScreen->myNum, X_ERROR, "EXA: Mixed Mode\n");
#endif

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvlExaInit: frame buffer virtual address = %p, physical address = %lX, size = %X, crtc_num %d\n", pDev->fbstart, pDev->memPhysBase, pScrn->videoRam, xf86_config->num_crtc);

    pExa->memoryBase        = pDev->fbstart;  
    pExa->offScreenBase     = pScrn->virtualY * pScrn->displayWidth * pScrn->bitsPerPixel * (xf86_config->num_crtc + 1) / 8;
    pExa->memorySize        = pScrn->videoRam ;

    xf86DrvMsg(pScrn->scrnIndex, X_INFO,  "mrvlExaInit: virtual X [%d], virtual Y [%d],  bpp [%d]\n", pScrn->virtualX, pScrn->virtualY, pScrn->bitsPerPixel);    

    pExa->pixmapOffsetAlign = 64; 
    pExa->pixmapPitchAlign  = 4 *  MRVL_SURF_WIDTH_ALIGNMENT;

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvlExaInit: offscreen base = 0x%lX, pitch alignment %d, ofset alignment %d\n", pExa->offScreenBase, pExa->pixmapPitchAlign, pExa->pixmapOffsetAlign);

#if MRVL_EXA_ALLOC_PIXMAP_FROM_SYSTEM
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvlExaInit: Allocate all pixmaps from system memory, just for debug use\n");
#endif

    pExa->maxX              = VIVANTE_MAX_WIDTH;
    pExa->maxY              = VIVANTE_MAX_HEIGHT;

    pExa->WaitMarker        = mrvlExaWaitMarker;
    pExa->MarkSync          = mrvlMarkSync;

    pExa->PrepareSolid      = mrvlExaPrepareSolid;
    pExa->Solid             = mrvlExaSolid;
    pExa->DoneSolid         = mrvlExaDoneSolid;

    pExa->PrepareCopy       = mrvlExaPrepareCopy;
    pExa->Copy              = mrvlExaCopy;
    pExa->DoneCopy          = mrvlExaDoneCopy;

    if (pDev->RenderAccel)
    {
        pExa->CheckComposite    = mrvlExaCheckComposite;
        pExa->PrepareComposite  = mrvlExaPrepareComposite;
        pExa->Composite         = mrvlExaComposite;
        pExa->DoneComposite     = mrvlExaDoneComposite;
    }
    else
    {
        pExa->CheckComposite    = NULL;
        pExa->PrepareComposite  = NULL;
        pExa->Composite         = NULL;
        pExa->DoneComposite     = NULL;
    }
   
    pExa->PrepareAccess     = mrvlPrepareAccess;
    pExa->FinishAccess      = mrvlFinishAccess;

#if MRVL_EXA_ENABLE_UP_DOWNLOAD
    pExa->UploadToScreen     = mrvlExaUploadToScreen;
    pExa->DownloadFromScreen = mrvlExaDownloadFromScreen;
#else
    pExa->UploadToScreen     = NULL;
    pExa->DownloadFromScreen = NULL;
#endif

    if (pExa->flags & EXA_HANDLES_PIXMAPS)
    {
        pExa->CreatePixmap       = NULL;
        pExa->CreatePixmap2      = mrvlExaCreatePixmap2;
        pExa->DestroyPixmap      = mrvlDestroyPixmap;
        pExa->ModifyPixmapHeader = mrvlModifyPixmapHeader;
        pExa->PixmapIsOffscreen  = mrvlPixmapIsOffscreen;
    }
    
    ret = exaDriverInit(pScreen, pExa);

    if (!mrvlFencePoolInit(pDev->exaInfo.Hal, &pDev->exaInfo.fakeFencePool))
    {
        xf86DrvMsg(0, X_ERROR, "initialize fence pool fails\n");
        return FALSE;
    }

#if MRVL_EXA_PERF_PROFILING
    mrvlInitializeProfilingModel(pScreen, &pDev->exaInfo.pm, "/exa.rgb", 0);       
#endif
   
    // Create these pixmps in MRVLCRTCResize functon where we can get actual size.
#if 0
    pDev->exaInfo.alphaPixmap   = mrvlCreateTempPixmap(pScreen, 
                                                     pScreen->width, 
                                                     pScreen->height, 
                                                     32);
    pDev->exaInfo.maskPixmap    = mrvlCreateTempPixmap(pScreen, 
                                                     pScreen->width, 
                                                     pScreen->height, 
                                                     32);    
    pDev->exaInfo.repeatPixmap  = mrvlCreateTempPixmap(pScreen, 
                                                     pScreen->width, 
                                                     pScreen->height, 
                                                     32);
#endif

    xf86DrvMsg(pScreen->myNum, X_INFO, "mrvlExaInit: EXA Initialization complete. ret = %d\n", ret);

    return ret;
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
Bool
mrvlExaShutdown(ScreenPtr pScreen)
{
    MRVLGetPrivate(pScreen);

    xf86DrvMsg(pScreen->myNum, X_INFO, "Shutdown EXA\n");       

    mrvlDestroyTempPixmap(pScreen, pDev->exaInfo.alphaPixmap);
    mrvlDestroyTempPixmap(pScreen, pDev->exaInfo.maskPixmap);
    mrvlDestroyTempPixmap(pScreen, pDev->exaInfo.repeatPixmap);            
    if(pDev->exaInfo.fakeFencePool.bInit)
    {
        mrvlFencePoolDeinit(pDev->exaInfo.Hal, &pDev->exaInfo.fakeFencePool);
    }

    exaDriverFini(pScreen);

    xfree(pDev->exaInfo.ExaDriver);
    pDev->exaInfo.ExaDriver = NULL;  
          
    return TRUE;
}
