#include <linux/fb.h>
#include <sys/ioctl.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <linux/types.h>
#include <video/dovefb.h>
#include <sys/mman.h>
#include <stdlib.h>

#include "dovefb_driver.h"

/*
 * EDID blocks out in the wild have a variety of bugs, try to collect
 * them here (note that userspace may work around broken monitors first,
 * but fixes should make their way here so that the kernel "just works"
 * on as many displays as possible).
 */

/* First detailed mode wrong, use largest 60Hz mode */
#define EDID_QUIRK_PREFER_LARGE_60      (1 << 0)
/* Reported 135MHz pixel clock is too high, needs adjustment */
#define EDID_QUIRK_135_CLOCK_TOO_HIGH       (1 << 1)
/* Prefer the largest mode at 75 Hz */
#define EDID_QUIRK_PREFER_LARGE_75      (1 << 2)
/* Detail timing is in cm not mm */
#define EDID_QUIRK_DETAILED_IN_CM       (1 << 3)
/* Detailed timing descriptors have bogus size values, so just take the
 * maximum size and use that.
 */
#define EDID_QUIRK_DETAILED_USE_MAXIMUM_SIZE    (1 << 4)
/* Monitor forgot to set the first detailed is preferred bit. */
#define EDID_QUIRK_FIRST_DETAILED_PREFERRED (1 << 5)
/* use +hsync +vsync for detailed mode */
#define EDID_QUIRK_DETAILED_SYNC_PP     (1 << 6)
/* define the number of Extension EDID block */
#define MAX_EDID_EXT_NUM 4

#define LEVEL_DMT   0
#define LEVEL_GTF   1
#define LEVEL_CVT   2

static struct edid_quirk {
    char *vendor;
    int product_id;
    unsigned int quirks;
} mrvl_edid_quirk_list[] = {
    /* Acer AL1706 */
    { "ACR", 44358, EDID_QUIRK_PREFER_LARGE_60 },
    /* Acer F51 */
    { "API", 0x7602, EDID_QUIRK_PREFER_LARGE_60 },
    /* Unknown Acer */
    { "ACR", 2423, EDID_QUIRK_FIRST_DETAILED_PREFERRED },

    /* Belinea 10 15 55 */
    { "MAX", 1516, EDID_QUIRK_PREFER_LARGE_60 },
    { "MAX", 0x77e, EDID_QUIRK_PREFER_LARGE_60 },

    /* Envision Peripherals, Inc. EN-7100e */
    { "EPI", 59264, EDID_QUIRK_135_CLOCK_TOO_HIGH },

    /* Funai Electronics PM36B */
    { "FCM", 13600, EDID_QUIRK_PREFER_LARGE_75 |
      EDID_QUIRK_DETAILED_IN_CM },

    /* LG Philips LCD LP154W01-A5 */
    { "LPL", 0, EDID_QUIRK_DETAILED_USE_MAXIMUM_SIZE },
    { "LPL", 0x2a00, EDID_QUIRK_DETAILED_USE_MAXIMUM_SIZE },

    /* Philips 107p5 CRT */
    { "PHL", 57364, EDID_QUIRK_FIRST_DETAILED_PREFERRED },

    /* Proview AY765C */
    { "PTS", 765, EDID_QUIRK_FIRST_DETAILED_PREFERRED },

    /* Samsung SyncMaster 205BW.  Note: irony */
    { "SAM", 541, EDID_QUIRK_DETAILED_SYNC_PP },
    /* Samsung SyncMaster 22[5-6]BW */
    { "SAM", 596, EDID_QUIRK_PREFER_LARGE_60 },
    { "SAM", 638, EDID_QUIRK_PREFER_LARGE_60 },
};


/* Valid EDID header has these bytes */
static unsigned char edid_header[] = {
	0x00, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00
};

#define MODEPREFIX NULL, NULL, NULL, 0, M_T_DRIVER
#define MODESUFFIX 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,FALSE,FALSE,0,NULL,0,0.0,0.0

/*SVD times table */
static const DisplayModeRec CEA_861_D_MODES[64] =
{
    { MODEPREFIX,    25175,  640,  656,  752,  800, 0,  480,  490,  492,  525, 0, V_NHSYNC | V_NVSYNC, MODESUFFIX },               //1:  640x 480@59.94
    { MODEPREFIX,    27000,  720,  736,  798,  858, 0,  480,  489,  495,  525, 0, V_NHSYNC | V_NVSYNC, MODESUFFIX },               //2:  720x 480@59.94
    { MODEPREFIX,    27000,  720,  736,  798,  858, 0,  480,  489,  495,  525, 0, V_NHSYNC | V_NVSYNC, MODESUFFIX },               //3:  720x 480@59.94
    { MODEPREFIX,    74250, 1280, 1390, 1430, 1650, 0,  720,  725,  730,  750, 0, V_PHSYNC | V_PVSYNC, MODESUFFIX },               //4: 1280x 720@60.00
    { MODEPREFIX,    74250, 1920, 2008, 2052, 2200, 0, 1080, 1084, 1094, 1125, 0, V_PHSYNC | V_PVSYNC | V_INTERLACE, MODESUFFIX }, //5: 1920x1080@30.00
    { MODEPREFIX,    27000, 1440, 1478, 1602, 1716, 0,  480,  488,  494,  525, 0, V_NHSYNC | V_NVSYNC | V_INTERLACE | V_DBLSCAN, MODESUFFIX }, //6: 1440x 480@29.97
    { MODEPREFIX,    27000, 1440, 1478, 1602, 1716, 0,  480,  488,  494,  525, 0, V_NHSYNC | V_NVSYNC | V_INTERLACE | V_DBLSCAN, MODESUFFIX }, //7: 1440x 480@29.97
    { MODEPREFIX,    27000, 1440, 1478, 1602, 1716, 0,  240,  244,  247,  262, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //8: 1440x 240@60.05
    { MODEPREFIX,    27000, 1440, 1478, 1602, 1716, 0,  240,  244,  247,  262, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //9: 1440x 240@60.05
    { MODEPREFIX,    54000, 2880, 2956, 3204, 3432, 0,  480,  488,  494,  525, 0, V_NHSYNC | V_NVSYNC | V_INTERLACE | V_DBLSCAN, MODESUFFIX }, //10: 2880x 480@29.97
    { MODEPREFIX,    54000, 2880, 2956, 3204, 3432, 0,  480,  488,  494,  525, 0, V_NHSYNC | V_NVSYNC | V_INTERLACE | V_DBLSCAN, MODESUFFIX }, //11: 2880x 480@29.97
    { MODEPREFIX,    54000, 2880, 2956, 3204, 3432, 0,  240,  244,  247,  262, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //12: 2880x 240@60.05
    { MODEPREFIX,    54000, 2880, 2956, 3204, 3432, 0,  240,  244,  247,  262, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //13: 2880x 240@60.05
    { MODEPREFIX,    54000, 1440, 1472, 1596, 1716, 0,  480,  489,  495,  525, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //14: 1440x 480@59.94
    { MODEPREFIX,    54000, 1440, 1472, 1596, 1716, 0,  480,  489,  495,  525, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //15: 1440x 480@59.94
    { MODEPREFIX,   148500, 1920, 2008, 2052, 2200, 0, 1080, 1084, 1089, 1125, 0, V_PHSYNC | V_PVSYNC, MODESUFFIX },               //16: 1920x1080@60.00
    { MODEPREFIX,    27000,  720,  732,  796,  864, 0,  576,  581,  586,  625, 0, V_NHSYNC | V_NVSYNC, MODESUFFIX },               //17:  720x 576@50.00
    { MODEPREFIX,    27000,  720,  732,  796,  864, 0,  576,  581,  586,  625, 0, V_NHSYNC | V_NVSYNC, MODESUFFIX },               //18:  720x 576@50.00
    { MODEPREFIX,    74250, 1280, 1720, 1760, 1980, 0,  720,  725,  730,  750, 0, V_PHSYNC | V_PVSYNC, MODESUFFIX },               //19: 1280x 720@50.00
    { MODEPREFIX,    74250, 1920, 2448, 2492, 2640, 0, 1080, 1084, 1094, 1125, 0, V_PHSYNC | V_PVSYNC | V_INTERLACE, MODESUFFIX }, //20: 1920x1080@25.00
    { MODEPREFIX,    27000, 1440, 1464, 1590, 1728, 0,  576,  580,  586,  625, 0, V_NHSYNC | V_NVSYNC | V_INTERLACE | V_DBLSCAN, MODESUFFIX }, //21: 1440x 576@25.00
    { MODEPREFIX,    27000, 1440, 1464, 1590, 1728, 0,  576,  580,  586,  625, 0, V_NHSYNC | V_NVSYNC | V_INTERLACE | V_DBLSCAN, MODESUFFIX }, //22: 1440x 576@25.00
    { MODEPREFIX,    27000, 1440, 1464, 1590, 1728, 0,  288,  290,  293,  312, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //23: 1440x 288@50.08
    { MODEPREFIX,    27000, 1440, 1464, 1590, 1728, 0,  288,  290,  293,  312, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //24: 1440x 288@50.08
    { MODEPREFIX,    54000, 2880, 2928, 3180, 3456, 0,  576,  580,  586,  625, 0, V_NHSYNC | V_NVSYNC | V_INTERLACE | V_DBLSCAN, MODESUFFIX }, //25: 2880x 576@25.00
    { MODEPREFIX,    54000, 2880, 2928, 3180, 3456, 0,  576,  580,  586,  625, 0, V_NHSYNC | V_NVSYNC | V_INTERLACE | V_DBLSCAN, MODESUFFIX }, //26: 2880x 576@25.00
    { MODEPREFIX,    54000, 2880, 2928, 3180, 3456, 0,  288,  290,  293,  312, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //27: 2880x 288@50.08
    { MODEPREFIX,    54000, 2880, 2928, 3180, 3456, 0,  288,  290,  293,  312, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //28: 2880x 288@50.08
    { MODEPREFIX,    54000, 1440, 1464, 1592, 1728, 0,  576,  581,  586,  625, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //29: 1440x 576@50.00
    { MODEPREFIX,    54000, 1440, 1464, 1592, 1728, 0,  576,  581,  586,  625, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //30: 1440x 576@50.00
    { MODEPREFIX,   148500, 1920, 2448, 2492, 2640, 0, 1080, 1084, 1089, 1125, 0, V_PHSYNC | V_PVSYNC, MODESUFFIX },               //31: 1920x1080@50.00
    { MODEPREFIX,    74250, 1920, 2558, 2602, 2750, 0, 1080, 1084, 1089, 1125, 0, V_PHSYNC | V_PVSYNC, MODESUFFIX },               //32: 1920x1080@24.00
    { MODEPREFIX,    74250, 1920, 2448, 2492, 2640, 0, 1080, 1084, 1089, 1125, 0, V_PHSYNC | V_PVSYNC, MODESUFFIX },               //33: 1920x1080@25.00
    { MODEPREFIX,    74250, 1920, 2008, 2052, 2200, 0, 1080, 1084, 1089, 1125, 0, V_PHSYNC | V_PVSYNC, MODESUFFIX },               //34: 1920x1080@30.00
    { MODEPREFIX,   108000, 2880, 2944, 3192, 3432, 0,  480,  489,  495,  525, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //35: 2880x 480@59.94
    { MODEPREFIX,   108000, 2880, 2944, 3192, 3432, 0,  480,  489,  495,  525, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //36: 2880x 480@59.94
    { MODEPREFIX,   108000, 2880, 2928, 3184, 3456, 0,  576,  581,  586,  625, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //37: 2880x 576@50.00
    { MODEPREFIX,   108000, 2880, 2928, 3184, 3456, 0,  576,  581,  586,  625, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //38: 2880x 576@50.00
    { MODEPREFIX,    72000, 1920, 1952, 2120, 2304, 0, 1080, 1126, 1136, 1250, 0, V_PHSYNC | V_NVSYNC | V_INTERLACE, MODESUFFIX }, //39: 1920x1080@25.00
    { MODEPREFIX,   148500, 1920, 2448, 2492, 2640, 0, 1080, 1084, 1094, 1125, 0, V_PHSYNC | V_PVSYNC | V_INTERLACE, MODESUFFIX }, //40: 1920x1080@50.00
    { MODEPREFIX,   148500, 1280, 1720, 1760, 1980, 0,  720,  725,  730,  750, 0, V_PHSYNC | V_PVSYNC, MODESUFFIX },               //41: 1280x 720@100.00
    { MODEPREFIX,    54000,  720,  732,  796,  864, 0,  576,  581,  586,  625, 0, V_NHSYNC | V_NVSYNC, MODESUFFIX },               //42:  720x 576@100.00
    { MODEPREFIX,    54000,  720,  732,  796,  864, 0,  576,  581,  586,  625, 0, V_NHSYNC | V_NVSYNC, MODESUFFIX },               //43:  720x 576@100.00
    { MODEPREFIX,    54000, 1440, 1464, 1590, 1728, 0,  576,  580,  586,  625, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //44: 1440x 576@50.00
    { MODEPREFIX,    54000, 1440, 1464, 1590, 1728, 0,  576,  580,  586,  625, 0, V_NHSYNC | V_NVSYNC | V_DBLSCAN, MODESUFFIX },               //45: 1440x 576@50.00
    { MODEPREFIX,   148500, 1920, 2008, 2052, 2200, 0, 1080, 1084, 1094, 1125, 0, V_PHSYNC | V_PVSYNC | V_INTERLACE, MODESUFFIX }, //46: 1920x1080@60.00
    { MODEPREFIX,   148500, 1280, 1390, 1430, 1650, 0,  720,  725,  730,  750, 0, V_PHSYNC | V_PVSYNC, MODESUFFIX },               //47: 1280x 720@120.00
    { MODEPREFIX,    54000,  720,  736,  798,  858, 0,  480,  489,  495,  525, 0, V_NHSYNC | V_NVSYNC, MODESUFFIX },               //48:  720x 480@119.88
    { MODEPREFIX,    54000,  720,  736,  798,  858, 0,  480,  489,  495,  525, 0, V_NHSYNC | V_NVSYNC, MODESUFFIX },               //49:  720x 480@119.88
    { MODEPREFIX,    54000, 1440, 1478, 1602, 1716, 0,  480,  488,  494,  525, 0, V_NHSYNC | V_NVSYNC | V_INTERLACE | V_DBLSCAN, MODESUFFIX }, //50: 1440x 480@59.94
    { MODEPREFIX,    54000, 1440, 1478, 1602, 1716, 0,  480,  488,  494,  525, 0, V_NHSYNC | V_NVSYNC | V_INTERLACE | V_DBLSCAN, MODESUFFIX }, //51: 1440x 480@59.94
    { MODEPREFIX,   108000,  720,  732,  796,  864, 0,  576,  581,  586,  625, 0, V_NHSYNC | V_NVSYNC, MODESUFFIX },               //52:  720x 576@200.00
    { MODEPREFIX,   108000,  720,  732,  796,  864, 0,  576,  581,  586,  625, 0, V_NHSYNC | V_NVSYNC, MODESUFFIX },               //53:  720x 576@200.00
    { MODEPREFIX,   108000, 1440, 1464, 1590, 1728, 0,  576,  580,  586,  625, 0, V_NHSYNC | V_NVSYNC | V_INTERLACE | V_DBLSCAN, MODESUFFIX }, //54: 1440x 576@100.00
    { MODEPREFIX,   108000, 1440, 1464, 1590, 1728, 0,  576,  580,  586,  625, 0, V_NHSYNC | V_NVSYNC | V_INTERLACE | V_DBLSCAN, MODESUFFIX }, //55: 1440x 576@100.00
    { MODEPREFIX,   108000,  720,  736,  798,  858, 0,  480,  489,  495,  525, 0, V_NHSYNC | V_NVSYNC, MODESUFFIX },               //56:  720x 480@239.76
    { MODEPREFIX,   108000,  720,  736,  798,  858, 0,  480,  489,  495,  525, 0, V_NHSYNC | V_NVSYNC, MODESUFFIX },               //57:  720x 480@239.76
    { MODEPREFIX,   108000, 1440, 1478, 1602, 1716, 0,  480,  488,  494,  525, 0, V_NHSYNC | V_NVSYNC | V_INTERLACE | V_DBLSCAN, MODESUFFIX }, //58: 1440x 480@119.88
    { MODEPREFIX,   108000, 1440, 1478, 1602, 1716, 0,  480,  488,  494,  525, 0, V_NHSYNC | V_NVSYNC | V_INTERLACE | V_DBLSCAN, MODESUFFIX }, //59: 1440x 480@119.88
    { MODEPREFIX,    59400, 1280, 3040, 3080, 3300, 0,  720,  725,  730,  750, 0, V_PHSYNC | V_PVSYNC, MODESUFFIX },               //60: 1280x 720@24.00
    { MODEPREFIX,    74250, 1280, 3700, 3740, 3960, 0,  720,  725,  730,  750, 0, V_PHSYNC | V_PVSYNC, MODESUFFIX },               //61: 1280x 720@25.00
    { MODEPREFIX,    74250, 1280, 3040, 3080, 3300, 0,  720,  725,  730,  750, 0, V_PHSYNC | V_PVSYNC, MODESUFFIX },               //62: 1280x 720@30.00
    { MODEPREFIX,   297000, 1920, 2008, 2052, 2200, 0, 1080, 1084, 1089, 1125, 0, V_PHSYNC | V_PVSYNC, MODESUFFIX },               //63: 1920x1080@120.00
    { MODEPREFIX,   297000, 1920, 2448, 2492, 2640, 0, 1080, 1084, 1094, 1125, 0, V_PHSYNC | V_PVSYNC, MODESUFFIX },               //64: 1920x1080@100.00
};

/**
 * edid_is_valid - sanity check EDID data
 * @edid: EDID data
 *
 * Sanity check the EDID block by looking at the header, the version number
 * and the checksum.  Return 0 if the EDID doesn't check out, or 1 if it's
 * valid.
 */
Bool mrvl_edid_is_valid(struct edid *edid)
{
    int i;
	unsigned char csum = 0;
	unsigned char *raw_edid = (unsigned char *)edid;

	if (memcmp(edid->header, edid_header, sizeof(edid_header)))
		goto bad;

	if (edid->version != 1) {
		xf86DrvMsg(0, X_ERROR, "EDID has major version %d, instead of 1\n", edid->version);
		goto bad;
	}
	if (edid->revision > 4)
		xf86DrvMsg(0, X_INFO, "EDID minor > 4, assuming backward compatibility\n");

	for (i = 0; i < EDID_LENGTH; i++)
		csum += raw_edid[i];
	if (csum) {
		xf86DrvMsg(0, X_ERROR, "EDID checksum is invalid, remainder is %d\n", csum);
		goto bad;
	}

	return TRUE;

bad:
	
	return FALSE;
}

#define HDMI_IDENTIFIER 0x000C03
#define VENDOR_BLOCK    0x03
/**
 * drm_detect_hdmi_monitor - detect whether monitor is hdmi.
 * @edid: monitor EDID information
 *
 * Parse the CEA extension according to CEA-861-B.
 * Return true if HDMI, false if not or unknown.
 */
Bool 
mrvl_detect_hdmi_monitor(struct edid *edid)
{
	char *edid_ext = NULL;
	int i, hdmi_id, edid_ext_num;
	int start_offset, end_offset;
	Bool is_hdmi = FALSE;

	/* No EDID or EDID extensions */
	if (edid == NULL || edid->extensions == 0)
		goto end;

	/* Chose real EDID extension number */
	edid_ext_num = edid->extensions > MAX_EDID_EXT_NUM ?
		       MAX_EDID_EXT_NUM : edid->extensions;

	/* Find CEA extension */
	for (i = 0; i < edid_ext_num; i++) {
		edid_ext = (char *)edid + EDID_LENGTH * (i + 1);
		/* This block is CEA extension */
		if (edid_ext[0] == 0x02)
			break;
	}

	if (i == edid_ext_num)
		goto end;

	/* Data block offset in CEA extension block */
	start_offset = 4;
	end_offset = edid_ext[2];

	/*
	 * Because HDMI identifier is in Vendor Specific Block,
	 * search it from all data blocks of CEA extension.
	 */
	for (i = start_offset; i < end_offset;
		/* Increased by data block len */
		i += ((edid_ext[i] & 0x1f) + 1)) {
		/* Find vendor specific block */
		if ((edid_ext[i] >> 5) == VENDOR_BLOCK) {
			hdmi_id = edid_ext[i + 1] | (edid_ext[i + 2] << 8) |
				  edid_ext[i + 3] << 16;
			/* Find HDMI identifier */
			if (hdmi_id == HDMI_IDENTIFIER)
				is_hdmi = TRUE;
			break;
		}
	}

end:
	return is_hdmi;
}

/**
 * edid_vendor - match a string against EDID's obfuscated vendor field
 * @edid: EDID to match
 * @vendor: vendor string
 *
 * Returns true if @vendor is in @edid, false otherwise
 */
static Bool edid_vendor(struct edid *edid, char *vendor)
{
	char edid_vendor[3];

	edid_vendor[0] = ((edid->mfg_id[0] & 0x7c) >> 2) + '@';
	edid_vendor[1] = (((edid->mfg_id[0] & 0x3) << 3) |
			  ((edid->mfg_id[1] & 0xe0) >> 5)) + '@';
	edid_vendor[2] = (edid->mfg_id[1] & 0x1f) + '@';

	return !strncmp(edid_vendor, vendor, 3);
}

/**
 * mrvl_edid_get_quirks - return quirk flags for a given EDID
 * @edid: EDID to process
 *
 * This tells subsequent routines what fixes they need to apply.
 */
static unsigned int 
mrvl_edid_get_quirks(struct edid *edid)
{
    struct edid_quirk *quirk;
    int i;

    for (i = 0; i < sizeof(mrvl_edid_quirk_list)/sizeof(struct edid_quirk); i++) {
        quirk = &mrvl_edid_quirk_list[i];

        if (edid_vendor(edid, quirk->vendor) &&
            (EDID_PRODUCT_ID(edid) == quirk->product_id))
            return quirk->quirks;
    }

    return 0;
}

/*
 * 0 is reserved.  The spec says 0x01 fill for unused timings.  Some old
 * monitors fill with ascii space (0x20) instead.
 */
static int
mrvl_bad_std_timing(unsigned char a, unsigned char b)
{
    return (a == 0x00 && b == 0x00) ||
           (a == 0x01 && b == 0x01) ||
           (a == 0x20 && b == 0x20);
}

DisplayModePtr 
mrvl_mode_std(struct std_timing *t,
                      int revision,
                      int timing_level)
{
    DisplayModePtr mode = NULL;
    int hsize, vsize;
    int vrefresh_rate;
    unsigned aspect_ratio = (t->vfreq_aspect & EDID_TIMING_ASPECT_MASK)
        >> EDID_TIMING_ASPECT_SHIFT;
    unsigned vfreq = (t->vfreq_aspect & EDID_TIMING_VFREQ_MASK)
        >> EDID_TIMING_VFREQ_SHIFT;

    if (mrvl_bad_std_timing(t->hsize, t->vfreq_aspect))
        return NULL;

    /* According to the EDID spec, the hdisplay = hsize * 8 + 248 */
    hsize = t->hsize * 8 + 248;
    /* vrefresh_rate = vfreq + 60 */
    vrefresh_rate = vfreq + 60;
    /* the vdisplay is calculated based on the aspect ratio */
    if (aspect_ratio == 0) {
        if (revision < 3)
            vsize = hsize;
        else
            vsize = (hsize * 10) / 16;
    } else if (aspect_ratio == 1)
        vsize = (hsize * 3) / 4;
    else if (aspect_ratio == 2)
        vsize = (hsize * 4) / 5;
    else
        vsize = (hsize * 9) / 16;

    /* HDTV hack */
    if (hsize == 1360 && vsize == 765 && vrefresh_rate == 60) {
        mode = xf86CVTMode(hsize, vsize, vrefresh_rate, FALSE, FALSE);
        mode->HDisplay = 1366;
        mode->VSyncStart = mode->VSyncStart - 1;
        mode->VSyncEnd = mode->VSyncEnd - 1;
        return mode;
    }

    extern DisplayModePtr FindDMTMode(int hsize, int vsize, int refresh, Bool rb);
    /* check whether it can be found in default mode table */
    mode = FindDMTMode(hsize, vsize, vrefresh_rate, TRUE);
    if (mode)
        return mode;

    switch (timing_level) {
    case LEVEL_DMT:
        break;
    case LEVEL_GTF:
        mode = xf86GTFMode(hsize, vsize, vrefresh_rate, 0, 0);
        break;
    case LEVEL_CVT:
        mode = xf86GTFMode(hsize, vsize, vrefresh_rate, 0, 0);
        break;
    }

    return mode;
}

DisplayModePtr 
mrvl_mode_detailed(struct edid *edid,
                   struct detailed_timing *timing,
                   unsigned int quirks)
{
    struct detailed_pixel_timing *pt = &timing->data.pixel_data;
    DisplayModePtr Mode;
    unsigned hactive = (pt->hactive_hblank_hi & 0xf0) << 4 | pt->hactive_lo;
    unsigned vactive = (pt->vactive_vblank_hi & 0xf0) << 4 | pt->vactive_lo;
    unsigned hblank = (pt->hactive_hblank_hi & 0xf) << 8 | pt->hblank_lo;
    unsigned vblank = (pt->vactive_vblank_hi & 0xf) << 8 | pt->vblank_lo;
    unsigned hsync_offset = (pt->hsync_vsync_offset_pulse_width_hi & 0xc0) << 2 | pt->hsync_offset_lo;
    unsigned hsync_pulse_width = (pt->hsync_vsync_offset_pulse_width_hi & 0x30) << 4 | pt->hsync_pulse_width_lo;
    unsigned vsync_offset = (pt->hsync_vsync_offset_pulse_width_hi & 0xc) >> 2 | pt->vsync_offset_pulse_width_lo >> 4;
    unsigned vsync_pulse_width = (pt->hsync_vsync_offset_pulse_width_hi & 0x3) << 4 | (pt->vsync_offset_pulse_width_lo & 0xf);

    /*
     * Refuse to create modes that are insufficiently large.  64 is a random
     * number, maybe the spec says something about what the minimum is.  In
     * particular I see this frequently with _old_ EDID, 1.0 or so, so maybe
     * our parser is just being too aggresive there.
     */
    if (hactive < 64 || vactive < 64) {
        xf86DrvMsg(0, X_INFO,
            "%s: Ignoring tiny %dx%d mode\n", __func__,
            hactive, vactive);
        return NULL;
    }

    /* We don't do stereo */
    if (pt->misc & MRVL_EDID_PT_STEREO) {
        xf86DrvMsg(0, X_INFO,
		   "%s: Ignoring: We don't handle stereo.\n", __func__);
        return NULL;
    }

    /* We only do seperate sync currently */
    if (!(pt->misc & MRVL_EDID_PT_SEPARATE_SYNC)) {
         xf86DrvMsg(0, X_INFO,
		    "%s: %dx%d Warning: We only handle separate"
                    " sync.\n", __func__, hactive, vactive);
        return NULL;
    }

    /* it is incorrect if hsync/vsync width is zero */
    if (!hsync_pulse_width || !vsync_pulse_width) {
        xf86DrvMsg(0, X_INFO, "Incorrect Detailed timing. "
            "Wrong Hsync/Vsync pulse width\n");
        return NULL;
    }

    Mode = xnfcalloc(1, sizeof(DisplayModeRec));

    Mode->type = M_T_DRIVER;

    if (quirks & EDID_QUIRK_135_CLOCK_TOO_HIGH)
        timing->pixel_clock = 1088;

	Mode->Clock = timing->pixel_clock * 10;

    Mode->HDisplay = hactive;
    Mode->HSyncStart = Mode->HDisplay + hsync_offset;
    Mode->HSyncEnd = Mode->HSyncStart + hsync_pulse_width;
    Mode->HTotal = Mode->HDisplay + hblank;

    /* EDID standard is ambiguous on how interlaced modes should be
	specified; workaround clearly broken modes.*/
    if (pt->misc & MRVL_EDID_PT_INTERLACED)
    {
        vactive             *= 2;
        vsync_offset        *= 2;
        vsync_pulse_width   *= 2;
        vblank              *= 2;
        vblank              |= 1;
    }

    Mode->VDisplay = vactive;
    Mode->VSyncStart = Mode->VDisplay + vsync_offset;
    Mode->VSyncEnd = Mode->VSyncStart + vsync_pulse_width;
    Mode->VTotal = Mode->VDisplay + vblank;

    /* perform basic check on the detail timing */
    if (Mode->HSyncEnd > Mode->HTotal || Mode->VSyncEnd > Mode->VTotal) {
        xfree(Mode);
        return NULL;
    }

    /* Some EDIDs have bogus h/vtotal values */
    if (Mode->HSyncEnd > Mode->HTotal)
		Mode->HTotal = Mode->HSyncEnd + 1;
    if (Mode->VSyncEnd > Mode->VTotal)
		Mode->VTotal = Mode->VSyncEnd + 1;

    xf86SetModeDefaultName(Mode);

    /* We ignore h/v_size and h/v_border for now. */

    if (pt->misc & MRVL_EDID_PT_INTERLACED)
        Mode->Flags |= V_INTERLACE;

    if (quirks & EDID_QUIRK_DETAILED_SYNC_PP)
	    Mode->Flags |= V_PVSYNC | V_PHSYNC;
    else {
        if (pt->misc & MRVL_EDID_PT_HSYNC_POSITIVE)
            Mode->Flags |= V_PHSYNC;
        else
            Mode->Flags |= V_NHSYNC;

        if (pt->misc & MRVL_EDID_PT_VSYNC_POSITIVE)
            Mode->Flags |= V_PVSYNC;
        else
            Mode->Flags |= V_NVSYNC;
    }

    return Mode;
}

/**
 * stanard_timing_level - get std. timing level(CVT/GTF/DMT)
 * @edid: EDID block to scan
 */
static int 
mrvl_standard_timing_level(struct edid *edid)
{
    if (edid->revision >= 2) {
        if (edid->revision >= 4 && (edid->features & MRVL_EDID_FEATURE_DEFAULT_GTF))
            return LEVEL_CVT;
        return LEVEL_GTF;
    }
    return LEVEL_DMT;
}

/**
 * add_detailed_mode_eedid - get detailed mode info from addtional timing
 *          EDID block
 * @connector: attached connector
 * @edid: EDID block to scan(It is only to get addtional timing EDID block)
 * @quirks: quirks to apply
 *
 * Some of the detailed timing sections may contain mode information.  Grab
 * it and add it to the list.
 */
static DisplayModePtr 
mrvl_add_detailed_info_eedid(struct edid *edid, unsigned int quirks, DisplayModePtr Modes)
{
    int i, j;
    char *edid_ext = NULL;
    struct detailed_timing *timing;
    struct detailed_non_pixel *data;
    int edid_ext_num;
    int start_offset, end_offset;
    int timing_level;
    DisplayModePtr Mode = NULL;

    if (edid->version == 1 && edid->revision < 3) {
        /* If the EDID version is less than 1.3, there is no
         * extension EDID.
         */
        xf86DrvMsg(0, X_WARNING, "Warning: EDID version is less than 1.3.\n");
        return Modes;
    }

    if (!edid->extensions) {
        /* if there is no extension EDID, it is unnecessary to
         * parse the E-EDID to get detailed info
         */
        xf86DrvMsg(0, X_WARNING, "Warning: No extension.\n");
        return Modes;
    }

    /* Chose real EDID extension number */
    edid_ext_num = edid->extensions > MAX_EDID_EXT_NUM ?
               MAX_EDID_EXT_NUM : edid->extensions;

    /* Find CEA extension */
    for (i = 0; i < edid_ext_num; i++) {
        edid_ext = (char *)edid + EDID_LENGTH * (i + 1);
        /* This block is CEA extension */
        if (edid_ext[0] == 0x02)
            break;
    }

    if (i == edid_ext_num) {
        /* if there is no additional timing EDID block, return */
        xf86DrvMsg(0, X_WARNING, "Warning: No additional timing.\n");
        return Modes;
    }

    /* Get the start offset of detailed timing block */
    start_offset = edid_ext[2];
    if (start_offset == 0) {
        /* If the start_offset is zero, it means that neither detailed
         * info nor data block exist. In such case it is also
         * unnecessary to parse the detailed timing info.
         */
        xf86DrvMsg(0, X_WARNING, "Warning: start offset of extension block can't be 0.\n");
        return Modes;
    }

    timing_level = mrvl_standard_timing_level(edid);
    end_offset = EDID_LENGTH;
    end_offset -= sizeof(struct detailed_timing);
    for (i = start_offset; i < end_offset;
            i += sizeof(struct detailed_timing)) {
        timing = (struct detailed_timing *)(edid_ext + i);
        data = &timing->data.other_data;
        /* Detailed mode timing */
        if (timing->pixel_clock) {
            Mode = mrvl_mode_detailed(edid, timing, quirks);
            if (!Mode)
                continue;

            
            xf86DrvMsg(0, X_INFO, "Add new mode from extension block..\n");
            xf86PrintModeline(0, Mode);
            Modes = xf86ModesAdd(Modes, Mode);

            continue;
        }

        /* Other timing or info */
        switch (data->type) {
        case EDID_DETAIL_MONITOR_SERIAL:
            break;
        case EDID_DETAIL_MONITOR_STRING:
            break;
        case EDID_DETAIL_MONITOR_RANGE:
            /* Get monitor range data */
            break;
        case EDID_DETAIL_MONITOR_NAME:
            break;
        case EDID_DETAIL_MONITOR_CPDATA:
            break;
        case EDID_DETAIL_STD_MODES:
            /* Five modes per detailed section */
            for (j = 0; j < 5; i++) {
                struct std_timing *std;

                std = &data->data.timings[j];
                Mode = mrvl_mode_std(std,
                               edid->revision,
                               timing_level);
                if (Mode) {
                    Modes = xf86ModesAdd(Modes, Mode);
                }
            }
            break;
        default:
            break;
        }
    }

    return Modes;
}
#if 0
/*

*/
static int
mrvlModeRefresh(const DisplayModeRec *mode)
{
    return (int)(xf86ModeVRefresh(mode) + 0.5);
}

/*

*/

static DisplayModePtr
mrvlFindModes(DisplayModePtr Modes, int hsize, int vsize, int refresh)
{
    int i;
    const DisplayModeRec *ret;

    for (i = 0; i < sizeof(Modes) / sizeof(DisplayModeRec); i++) {
	    ret = &Modes[i];

	    if (ret->HDisplay == hsize &&
	        ret->VDisplay == vsize &&
	        refresh == mrvlModeRefresh(ret))
	        return xf86DuplicateMode(ret);
        }

    return NULL;
}
#endif

/*

*/
static DisplayModePtr 
mrvl_add_svd_mode_eedid(struct edid *edid, DisplayModePtr Modes)
{
    int i;
    char *edid_ext = NULL;
    int edid_ext_num;
    int svd_num, svd_tag;
    DisplayModePtr Mode = NULL;

    if (edid->version == 1 && edid->revision < 3) {
        /* If the EDID version is less than 1.3, there is no
         * extension EDID.
         */
        return Modes;
    }

    if (!edid->extensions) {
        /* if there is no extension EDID, it is unnecessary to
         * parse the E-EDID to get detailed info
         */
        return Modes;
    }

    /* Chose real EDID extension number */
    edid_ext_num = edid->extensions > MAX_EDID_EXT_NUM ?
               MAX_EDID_EXT_NUM : edid->extensions;

    /* Find CEA extension */
    for (i = 0; i < edid_ext_num; i++) {
        edid_ext = (char *)edid + EDID_LENGTH * (i + 1);
        /* This block is CEA extension */
        if (edid_ext[0] == 0x02)
            break;
    }

    if (i == edid_ext_num) {
        /* if there is no additional timing EDID block, return */
        return Modes;
    }

    /* Check SVD tag */
    svd_tag = (edid_ext[4] & 0xe0) >> 5;
    if (svd_tag != 2)
    {
        return Modes;
    }

    /* Get SVD length */
    svd_num = edid_ext[4] & 0x1f;
    if (svd_num == 0) {
        return Modes;
    }

    for (i = 0; i < svd_num; i++)
    {
        int svd_id = edid_ext[5+i] & 0x7f;

        if (svd_id >=64 || svd_id <= 0)
            continue;

        if (CEA_861_D_MODES[svd_id - 1].Flags & V_DBLSCAN)
            continue;

        //xf86DrvMsg(0, X_INFO, "Printing extended SVD num: %d %X\n", svd_id, svd_id);

        Mode = xf86DuplicateMode(&CEA_861_D_MODES[svd_id - 1]);

        //xf86PrintModeline(0, Mode);

        Modes = xf86ModesAdd(Modes, Mode);
    }

    return Modes;
}

/** Return - 0 + if a should be earlier, same or later than b in list
 */
static int
xf86ModeCompare (DisplayModePtr a, DisplayModePtr b)
{
    int	diff;

    diff = ((b->type & M_T_PREFERRED) != 0) - ((a->type & M_T_PREFERRED) != 0);
    if (diff)
	return diff;
    diff = b->HDisplay * b->VDisplay - a->HDisplay * a->VDisplay;
    if (diff)
	return diff;
    diff = b->Clock - a->Clock;
    return diff;
}

/**
 * Insertion sort input in-place and return the resulting head
 */
static DisplayModePtr
mrvlSortModes (DisplayModePtr input)
{
    DisplayModePtr  output = NULL, i, o, n, *op, prev;

    /* sort by preferred status and pixel area */
    while (input)
    {
	i = input;
	input = input->next;
	for (op = &output; (o = *op); op = &o->next)
	    if (xf86ModeCompare (o, i) > 0)
		break;
	i->next = *op;
	*op = i;
    }
    /* prune identical modes */
    for (o = output; o && (n = o->next); o = n)
    {
	if (!strcmp (o->name, n->name) && xf86ModesEqual (o, n))
	{
	    o->next = n->next;
	    xfree (n->name);
	    xfree (n);
	    n = o;
	}
    }
    /* hook up backward links */
    prev = NULL;
    for (o = output; o; o = o->next)
    {
	o->prev = prev;
	prev = o;
    }
    return output;
}

/**
 * mrvl_add_extended_edid_modes - add modes from EDID data, if available
 * @connector: connector we're probing
 * @edid: edid data
 *
 * Add the specified modes to the connector's mode list.
 *
 * Return number of modes added or 0 if we couldn't find any.
 */
DisplayModePtr
mrvl_add_extended_edid_modes(struct edid *edid, DisplayModePtr modes)
{
    unsigned int quirks;
    DisplayModePtr detailed_modes = NULL, svd_modes = NULL;
    DisplayModePtr m = NULL;

    if (edid == NULL) {
        return modes;
    }

    if (!edid->extensions)
    {
        return modes;
    }

    quirks = mrvl_edid_get_quirks(edid);

    detailed_modes = mrvl_add_detailed_info_eedid(edid, quirks, detailed_modes);

    svd_modes = mrvl_add_svd_mode_eedid(edid, svd_modes);

    m = detailed_modes;
#if 0
    if (m)
        xf86DrvMsg(0, X_INFO, "Printing extended detailed timings:\n");

    while(m)
    {
        xf86PrintModeline(0, m);
        m = m->next;
    }
#endif
    m = svd_modes;
#if 0
    if (m)
        xf86DrvMsg(0, X_INFO, "Printing extended SVD timings:\n");

    while(m)
    {
        xf86PrintModeline(0, m);
        m = m->next;
    }
#endif
    modes = xf86ModesAdd(modes, svd_modes);

    /* FIXME: SVD overrides detailed timing according to CEA-861-E */
    if(svd_modes == NULL)
    {
        modes = xf86ModesAdd(modes, detailed_modes);
    }
    else
    {
        DisplayModePtr n = NULL;

        m = n = detailed_modes;

        while(m)
        {
            n = m;
            m = m->next;
            xfree(n->name);
            xfree(n);
        }
    }

    mrvlSortModes(modes);

    return modes;
}
