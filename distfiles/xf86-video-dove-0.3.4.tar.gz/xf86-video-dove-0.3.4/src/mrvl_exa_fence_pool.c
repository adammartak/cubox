#include "dovefb_driver.h"

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
Bool
mrvlFencePoolInit(gcoHAL pHal, FakeFencePoolPtr pFakeFencePool)
{
    gceSTATUS       status;
	
    if(pFakeFencePool->bInit)
        return TRUE;
    
    status = gcoSURF_Construct(pHal,
                      FAKE_FENCE_POOL_MAX_WIDTH,
                      FAKE_FENCE_POOL_MAX_HEIGHT,
                      1,
                      gcvSURF_BITMAP,
                      gcvSURF_A8R8G8B8,
                      gcvPOOL_SYSTEM,
                      &pFakeFencePool->fenceSurf
                      );
    if( status != gcvSTATUS_OK )
    {
        xf86DrvMsg(0, X_ERROR, "mrvlFencePoolInit: gcoSURF_Construct failed. file %s, line %d\n", __FILE__, __LINE__);
        return FALSE;
    } 
    
    status = gcoSURF_Lock(pFakeFencePool->fenceSurf, 
                         &pFakeFencePool->physicalAddress, 
                         (gctPOINTER)&pFakeFencePool->virtualAddress);
    if( status != gcvSTATUS_OK )
    {
        xf86DrvMsg(0, X_ERROR, "mrvlFencePoolInit: gcoSURF_Lock failed. file %s, line %d\n", __FILE__, __LINE__);
        return FALSE;
    }  

    *(unsigned int *)pFakeFencePool->virtualAddress = 0; 

    status = gcoSURF_GetAlignedSize(pFakeFencePool->fenceSurf,
                                    &pFakeFencePool->dwAlignedWidth,
                                    &pFakeFencePool->dwAlignedHeight,
                                    &pFakeFencePool->iAlignedStride);
    if( status != gcvSTATUS_OK )
    {
        xf86DrvMsg(0, X_ERROR, "mrvlFencePoolInit:gcoSURF_GetAlignedSize failed. file %s, line %d\n", __FILE__, __LINE__);
        return FALSE;
    }   

    xf86DrvMsg(0, X_ERROR, "mrvlFencePoolInit: virtual address %p, physical address %X\n", 
                            pFakeFencePool->virtualAddress,  pFakeFencePool->physicalAddress);
    
    pFakeFencePool->allocIndex = 0;
    pFakeFencePool->bInit      = TRUE;
    
    INIT_LIST_HEAD(&pFakeFencePool->freeList);
    INIT_LIST_HEAD(&pFakeFencePool->busyList);     

    return TRUE;              
}
/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
void 
mrvlFencePoolDeinit(gcoHAL pHal, FakeFencePoolPtr pFakeFencePool)
{
    gceSTATUS       status;

    if(pFakeFencePool->bInit == FALSE)
        return;
	
    status = gcoSURF_Unlock(pFakeFencePool->fenceSurf, NULL);
    if( status != gcvSTATUS_OK )
    {
        xf86DrvMsg(0, X_ERROR, "gcoSURF_Unlock failed. file %s, line %d\n", __FILE__, __LINE__);
    }  
    
    status = gcoSURF_Destroy(pFakeFencePool->fenceSurf);
    if( status != gcvSTATUS_OK )
    {
        xf86DrvMsg(0, X_ERROR, "gcoSRUF_Destroy failed. file %s, line %d\n", __FILE__, __LINE__);
    }         
    
    if (!list_empty(&pFakeFencePool->freeList))
    {
        struct list_head *pos, nextPos;
        
        list_for_each(pos, &pFakeFencePool->freeList)
        {
            memcpy(&nextPos, pos, sizeof(struct list_head));

            FakeFencePtr pFakeFence = list_entry(pos, FakeFence, list_entry);

            mrvl_list_del(&pFakeFence->list_entry);
                       
            xfree(pFakeFence);           

            pos = &nextPos;
        }   
    }
    
    if (!list_empty(&pFakeFencePool->busyList))
    {
        struct list_head *pos, nextPos;
        
        list_for_each(pos, &pFakeFencePool->busyList)
        {
            memcpy(&nextPos, pos, sizeof(struct list_head));

            FakeFencePtr pFakeFence = list_entry(pos, FakeFence, list_entry);

            mrvl_list_del(&pFakeFence->list_entry);
                       
            xfree(pFakeFence);           

            pos = &nextPos;
        }   
    }
	
    pFakeFencePool->bInit = FALSE;
}
/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
FakeFencePtr 
mrvlFencePoolAlloc(FakeFencePoolPtr pFakeFencePool)
{
    FakeFencePtr pFakeFence;

    if (pFakeFencePool->bInit == FALSE)
    {
        xf86DrvMsg(0, X_ERROR,  "mrvlFencePoolAlloc: Unintialized fence pool\n");
        return NULL;
    }
        
    if (!list_empty(&pFakeFencePool->freeList))
    {
        struct list_head *first_item = pFakeFencePool->freeList.next;
        
        pFakeFence = list_entry(first_item, FakeFence, list_entry);
        
        mrvl_list_del(first_item);
    }
    else
    {        
        pFakeFence = (FakeFencePtr)xalloc(sizeof(FakeFence));
        if (!pFakeFence)
            return NULL;
            
        pFakeFence->xDir = pFakeFencePool->allocIndex % FAKE_FENCE_POOL_MAX_WIDTH;
        pFakeFence->yDir = pFakeFencePool->allocIndex / FAKE_FENCE_POOL_MAX_WIDTH;
        
        pFakeFence->pFenceMarker = (unsigned int *)pFakeFencePool->virtualAddress + pFakeFencePool->allocIndex;
        pFakeFence->dwFenceMarkerAddr = pFakeFencePool->physicalAddress + pFakeFencePool->allocIndex * 4;                                   
        
        pFakeFencePool->allocIndex++;
    }
     
    mrvl_list_add(&pFakeFence->list_entry, &pFakeFencePool->busyList);
    
    *pFakeFence->pFenceMarker = 0;
    pFakeFence->syncMarker    = 0;

    return pFakeFence;
}
/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
void
mrvlFencePoolFree(FakeFencePoolPtr pFakeFencePool, FakeFencePtr pFakeFence)
{
    if (!pFakeFence)
        return;
        
    mrvl_list_del(&pFakeFence->list_entry);
    mrvl_list_add(&pFakeFence->list_entry, &pFakeFencePool->freeList);        
}
/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
Bool
mrvlFencePoolCommit(ScreenPtr pScreen, FakeFencePtr pFakeFence)
{
    MRVLGetPrivate(pScreen);
    gcsRECT         dstRect;
    gceSTATUS       status;
    unsigned int    aligned_fence_paddr = 0, fence_align = 0, aligned_fence_pitch = 0;
    unsigned int    fence_paddr = pFakeFence->dwFenceMarkerAddr;
    unsigned int    fence_data = ++pFakeFence->syncMarker;

    if (!pFakeFence)
        return FALSE;

    dstRect.left    = 0;
    dstRect.top     = 0;
    dstRect.right   = 1;
    dstRect.bottom  = 1;

    aligned_fence_paddr   = MEM_PAGE_ALIGN_DOWN(fence_paddr, 64);
    fence_align           = fence_paddr - aligned_fence_paddr;
    dstRect.left          = (fence_align / 4);
    dstRect.right         = (fence_align / 4) + 1;
    aligned_fence_pitch   = MEM_PAGE_ALIGN_UP((sizeof(unsigned int) + fence_align), 32);

    status = gco2D_LoadSolidBrush(pDev->exaInfo.Engine2D,
                                gcvSURF_A8R8G8B8,
                                0,
                                fence_data,
                                0xFFFFFFFF);

    if( status != gcvSTATUS_OK )
    {
        xf86DrvMsg(0, X_ERROR,  "mrvlFencePoolCommit: LoadSolidBrush failed. status = %d\n", status);
        return FALSE;
    }

    status = gco2D_SetClipping(pDev->exaInfo.Engine2D, &dstRect);
    if (status != gcvSTATUS_OK)
    {
        xf86DrvMsg(0, X_ERROR, "mrvlFencePoolCommit: Failed to set clipping, %d line\n", __LINE__);
        return FALSE;
    }

    status = gco2D_SetTarget(pDev->exaInfo.Engine2D, 
                             aligned_fence_paddr, 
                             aligned_fence_pitch,  
                             gcvSURF_0_DEGREE,
                             0);
    if (status != gcvSTATUS_OK)
    {
        xf86DrvMsg(0, X_ERROR, "mrvlFencePoolCommit: Failed to set target, %d line\n", __LINE__);
        return FALSE;
    }

    status = gco2D_Blit(pDev->exaInfo.Engine2D, 1, &dstRect, 0xF0, 0xF0, gcvSURF_A8R8G8B8);
    if (status != gcvSTATUS_OK)
    {
        xf86DrvMsg(0, X_ERROR, "mrvlFencePoolCommit: Failed to blit, %d line\n", __LINE__);
        return FALSE;
    }

    return TRUE;
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
Bool
mrvlFencePoolKickOff(ScreenPtr pScreen, FakeFencePtr pFakeFence)
{
    gceSTATUS status;
    MRVLGetPrivate(pScreen)

    mrvlFencePoolCommit(pScreen, pFakeFence);
	
    status = gco2D_Flush(pDev->exaInfo.Engine2D);
    if ( status != gcvSTATUS_OK )
    {
        xf86DrvMsg(0, X_ERROR, "mrvlExaDoneSolid: gcoSURF_Flush result : %d\n", status);
    }

    status = gcoHAL_Commit(pDev->exaInfo.Hal, gcvFALSE);
    if ( status != gcvSTATUS_OK)
    {
        xf86DrvMsg(0, X_ERROR, "gcoHAL_Commit result : %d\n", status);
    }

    return TRUE;
}


/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
void
mrvlFencePoolStall(FakeFencePtr pFakeFence)
{
    int             timeout = 0;  
    
    while ((*pFakeFence->pFenceMarker < pFakeFence->syncMarker) && (++timeout < FAKE_FENCE_POOL_MAX_TIMEOUT))
    {
        usleep(5);    
    }
    
    if (timeout == FAKE_FENCE_POOL_MAX_TIMEOUT)
    {
        xf86DrvMsg(0, X_ERROR, "mrvlFencePoolStall:sync marker timeout, wait %d, real %d\n", 
                                pFakeFence->syncMarker, *pFakeFence->pFenceMarker);     
    }
}
/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
void 
mrvlFencePoolAssignPixmap(FakeFencePtr pFakeFence, PixmapPtr pPixmap)
{
    pFakeFence->pPixmap = pPixmap;    
}
