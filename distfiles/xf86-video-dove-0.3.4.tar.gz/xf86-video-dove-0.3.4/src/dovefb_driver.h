#ifndef __DOVEFB_XV__
#define __DOVEFB_XV__
/* -------------------------------------------------------------------- */
/* our private data, and two functions to allocate/free this            */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

/* all driver need this */
#include "xf86.h"
#include "xf86_OSproc.h"

#if GET_ABI_MAJOR(ABI_VIDEODRV_VERSION) < 6
#include "xf86Resources.h"
#include "xf86RAC.h"
#endif

#include "mipointer.h"
#include "micmap.h"
#include "mibstore.h"

#include "colormapst.h"
#include "xf86cmap.h"
#include "dgaproc.h"

#include "mrvl_crtc.h"
#include "mrvl_debug.h"
#include "xf86Crtc.h"
#include "xf86RandR12.h"

#if MRVL_SUPPORT_EXA
// EXA includes
#include "mrvl_exa.h"
#endif

#if MRVL_USE_OFFSCREEN_HEAP
#include "mrvl_heap.h"
#endif

#include <linux/fb.h>

/* Platform ID*/
#define MRVL_DOVE 1
#define MRVL_MMP2 2

/* frame buffer driver info. */
#define GFX_DEV0            "/dev/fb0"
#define GFX_DEV1            "/dev/fb2"
#define GFX_DEV0_ID         "GFX Layer 0"	
#define GFX_DEV1_ID         "GFX Layer 1"

#define MMP2_GFX            "/dev/fb0"
#define MMP2_GFX_ID         "GFX Layer"	

#define MMP2_VIDEO          "/dev/fb2"
#define MMP2_VIDEO_ID       "Video Layer"

#define MMP2_TV_GFX         "/dev/fb1"
#define MMP2_TV_GFX_ID      "GFX Layer - TV"

#define MMP2_TV_VIDEO       "/dev/fb3"
#define MMP2_TV_VIDEO_ID    "Video Layer - TV"

/* driver-defined output name. */
#define LVDS_OUTPUT_NAME    "lvds"
#define VGA_OUTPUT_NAME     "VGA"
#define HDMI_OUTPUT_NAME    "HDMI"

typedef struct {
	unsigned char*			fbstart;
	unsigned long           memPhysBase;
	unsigned char*			fbmem;
	int				        fboff;
	int				        lineLength;
	int				        rotate;
	Bool				    shadowFB;
	void                    *shadow;
	CloseScreenProcPtr		CloseScreen;
	CreateScreenResourcesProcPtr    CreateScreenResources;
	void				    (*PointerMoved)(int index, int x, int y);
	EntityInfoPtr			pEnt;
	/* DGA info */
	DGAModePtr			    pDGAMode;
	int				        nDGAMode;
	OptionInfoPtr			Options;
	
	/* video colorkey */
	int				        videoKey;	
	xf86CursorInfoPtr		cursor;
	int				        cursor_fg;
	int				        cursor_bg;
	
	Bool				    HWcursor;
	Bool                    UseExa;
    Bool                    UseXv;
    Bool                    UseSolid;
    Bool                    UseCopy;
    Bool                    UseComposite;
    Bool                    UseCommitStall;
    Bool                    UseSoftwareSolid;
    Bool                    UseSoftwareCopy;
    Bool                    UseGPU;
    Bool                    UseDriverBuiltInMode;
    Bool                    EnableDualDisplay;
#ifdef RENDER
    Bool                    RenderAccel;
#endif
	
#if 1 //MRVL_SUPPORT_RANDR
    // Crtc releated fileds  
    xf86CrtcPtr             pCrtc[MRVL_MAX_CRTC_COUNT];
    MRVLCrtcPrivateRec      controller[MRVL_MAX_CRTC_COUNT];
    xf86OutputPtr           pOutput[MRVL_MAX_CRTC_COUNT];
    Rotation                rotation;
    int                     crtc_num;
#endif   
    /* gfx layer file descriptor. */
    int                     gfx_fd[MRVL_MAX_CRTC_COUNT];

    /* xv device file descriptors. */
    int                     vid_fd[MRVL_MAX_CRTC_COUNT];
    int                     vid_num;
    char                   *fbPtr[MRVL_MAX_CRTC_COUNT];
    unsigned int            fbPhyAddr[MRVL_MAX_CRTC_COUNT];
    unsigned int            fbPhySize[MRVL_MAX_CRTC_COUNT];
    char                   *mmio[MRVL_MAX_CRTC_COUNT];
    int                     need_adjust[MRVL_MAX_CRTC_COUNT];
    Bool                    bXvOverlayAdaptor;

#if MRVL_SUPPORT_EXA
    /* Exa info */
    ExaInfoRec              exaInfo;
    int                     exaMode;
#endif

#if MRVL_USE_OFFSCREEN_HEAP
    OsMemHeap               offscreenMemHeap;
#endif

    int                     exaGCSyncMarker;
    int                     exaGCMarkerSynced;

    // Save and restore VT
    struct fb_var_screeninfo  fb_console_var[MRVL_MAX_CRTC_COUNT];
    struct fb_var_screeninfo  xserver_var[MRVL_MAX_CRTC_COUNT];

    // filter temp surface for XV
#if MRVL_SUPPORT_EXA
    PixmapPtr       pFilterPix;
    gcoSURF         pFilterSurf;
    unsigned int    dwFilterPhyAddr;
#endif

#if MRVL_XV_USE_FAKE_FENCE_STALL 
    FakeFencePtr     pXVScreenFence;
#endif

    Bool            bCreateXVFilterSurf;
    Bool            bXvResourceInitialized;

} FBDevRec, *FBDevPtr;

static inline FBDevRec* 
mrvlExaDriverPrivate(PixmapPtr pPixmap)
{
    return xf86Screens[(pPixmap)->drawable.pScreen->myNum]->driverPrivate;
}

static inline ScrnInfoPtr 
mrvlExaGetScrnInfo(PixmapPtr pPixmap)
{
    return xf86Screens[(pPixmap)->drawable.pScreen->myNum];
}

#define MRVLGetPrivate(pScreen)                 FBDevPtr        pDev = xf86Screens[pScreen->myNum]->driverPrivate;
#define MRVLGetScrnInfo(pScreen)                ScrnInfoPtr     pScrn = xf86Screens[pScreen->myNum];
#define MRVLDecPixmapPrivate(x)                 PixmapSurfacePtr   x
#define MRVLGetPixmapPrivate(priv, pPix)        PixmapSurfacePtr   priv = (PixmapSurfacePtr)exaGetPixmapDriverPrivate(pPix);
#define FBDEVPTR(pScrn)                         ((FBDevPtr)((pScrn)->driverPrivate))
#define MRVLGetPrivateByScrn(pScrn)             FBDevPtr              pDev = FBDEVPTR(pScrn);
#define MRVLGetPrivateByPix(pPix)               FBDevPtr              pDev = mrvlExaDriverPrivate(pPix);
#define MRVLGetScreenByPix(pPix)                ScreenPtr             pScreen = pPix->drawable.pScreen;


/* Supported options */
typedef enum {
    OPTION_SHADOW_FB,
    OPTION_ROTATE,
    OPTION_FBDEV,
    OPTION_DEBUG,
    OPTION_VIDEO_KEY,
    OPTION_ENC_FUNC,
    OPTION_HW_CURSOR,
    OPTION_EXA_ACCEL,
    OPTION_XV_ACCEL,
    OPTION_SOLID_ACCEL,
    OPTION_COPY_ACCEL,
    OPTION_COMP_ACCEL,
    OPTION_COMMIT,
    OPTION_SW_SOLID,
    OPTION_SW_COPY, 
    OPTION_USE_GPU,
    OPTION_USE_DRIVER_MODE,
    OPTION_DUAL_DISPLAY,
#ifdef RENDER
    OPTION_RENDER_ACCEL,
    OPTION_SUBPIXEL_ORDER,
#endif
} FBDevOpts;

#endif
