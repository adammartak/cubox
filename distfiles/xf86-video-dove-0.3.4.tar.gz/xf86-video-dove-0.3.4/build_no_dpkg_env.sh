#!/bin/sh

########################################################
# Native Build Xorg Driver in None DPKG Env 
# You could midify the CFLAGS below to modify your driver

echo "aclocal..."
aclocal

echo "libtoolize..."
libtoolize

echo "add-missing..."
automake --add-missing

echo "autoreconf..."
autoreconf
#DOVE=1, MMP2=2
./configure --prefix=/usr CFLAGS="-O0 -Wall -g -DMRVL_SUPPORT_RANDR=1 -DMRVL_SUPPORT_EXA=1 -DDUMP_RAW_VIDEO=1 -DMRVL_USE_OFFSCREEN_HEAP=0 -DMRVL_EXA_MODE=2 -DMRVL_EXA_ENABLE_UP_DOWNLOAD=0 -DMRVL_EXA_FORCE_HW_LOAD=0 -DMRVL_EXA_ALLOC_PIXMAP_FROM_SYSTEM=0 -DMRVL_EXA_PERF_PROFILING=0 -DMRVL_EXA_TRACE_FALLBACK=1 -DMRVL_EXA_XBGR_SUPPORT=1 -DMRVL_XV_SUPPORT_RGB_FORMAT=1 -DMRVL_XV_TEX_VIDEO=1 -DMRVL_XV_OVERLAY_VIDEO=2 -DMRVL_XV_DEFERRED_STALL_GPU=1 -DMRVL_XV_USE_FAKE_FENCE_STALL=1 -DMRVL_RANDR_EDID_MODES=1  -DMRVL_CRTC_SUPPORT_ROTATION=0 -DMRVL_PLATFORM_INFO=2"

make

cp ./src/.libs/dovefb_drv.so ./
