/******************************************************************************
//(C) Copyright 2009 Marvell International Ltd.
//All Rights Reserved
******************************************************************************/

#ifndef DATA_TYPES_H
#define DATA_TYPES_H

typedef unsigned int        MRVL_U32, MRVL_UINT;
typedef unsigned short      MRVL_U16;
typedef unsigned char       MRVL_U8;
typedef unsigned long       MRVL_ULONG, MRVL_ULONG_PTR;

typedef void                MRVL_VOID;
typedef void *              MRVL_VOIDP;


typedef int                 MRVL_S32;
typedef short               MRVL_S16;
typedef char                MRVL_S8;
typedef long                MRVL_LONG;

typedef unsigned char       MRVL_BOOL;

#define MRVL_TRUE               1
#define MRVL_FALSE              0

#endif
