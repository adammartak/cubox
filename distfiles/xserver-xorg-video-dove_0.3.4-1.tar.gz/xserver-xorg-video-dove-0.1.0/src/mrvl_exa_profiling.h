/******************************************************************************
//(C) Copyright 2009 Marvell International Ltd.
//All Rights Reserved
******************************************************************************/
#ifndef MRVL_EXA_PROFILING_H
#define MRVL_EXA_PROFILING_H

#include <sys/time.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

// Global control flags,    mask 0xF
#define EXA_TRACE_ENABLE        (1 << 0)
#define EXA_TRACE_RESET         (1 << 1)
#define EXA_TRACE_PRINT         (1 << 2)
#define EXA_TRACE_EXA           (1 << 3)
// Solid control flags,     mask 0xF0
#define EXA_TRACE_SOLID_PREP    (1 << 4)
#define EXA_TRACE_SOLID_DO      (1 << 5)
#define EXA_TRACE_SOLID_DONE    (1 << 6)
#define EXA_TRACE_RESERVED2     (1 << 7)
// Copy control flags,      mask 0xF00
#define EXA_TRACE_COPY_PREP     (1 << 8)
#define EXA_TRACE_COPY_DO       (1 << 9)
#define EXA_TRACE_COPY_DONE     (1 << 10)
#define EXA_TRACE_RESERVED3     (1 << 11)
// Composite control flags, mask 0xF000
#define EXA_TRACE_COMP_CHECK    (1 << 12)
#define EXA_TRACE_COMP_PREP     (1 << 13)
#define EXA_TRACE_COMP_DO       (1 << 14)
#define EXA_TRACE_COMP_DONE     (1 << 15)
// Sync control flags,      mask 0xF0000
#define EXA_TRACE_MARK          (1 << 16)
#define EXA_TRACE_WAIT_SYNC     (1 << 17)
#define EXA_TRACE_PREP_ACC      (1 << 18)
#define EXA_TRACE_FINI_ACC      (1 << 19)
// Create/destroy flags,    mask 0xF00000
#define EXA_TRACE_CREATE_PIX    (1 << 20)
#define EXA_TRACE_DESTROY_PIX   (1 << 21)
#define EXA_TRACE_MODI_HEADER   (1 << 22)
#define EXA_TRACE_OFFSCREEN     (1 << 23)
// Other control flags,     mask 0xF000000
#define EXA_TRACE_UPLOAD        (1 << 24)
#define EXA_TRACE_DOWNLOAD      (1 << 25)
#define EXA_TRACE_HAL           (1 << 26)
#define EXA_TRACE_CREATE_PIX2   (1 << 27)
//                          mask 0xF0000000
#define EXA_TRACE_DUMP_IMAGE    (1 << 28) 
#define EXA_TRACE_WAIT          (1 << 29)
#define EXA_TRACE_PREWAIT       (1 << 30)
#define EXA_TRACE_RESERVED4     (1 << 31)

#define EXA_PM_MAX_FILE_NAME_LEN    100

typedef struct __PMIndex
{
    unsigned long       g_SolidCount, g_CopyCount, g_CompositeCount, 
                        g_SolidCountF, g_CopyCountF, g_CompositeCountF,                         
                        g_SolidPrepare, g_SolidDo, g_SolidDone,
                        g_CopyPrepare, g_CopyDo, g_CopyDone,
                        g_CompCheck, g_CompPrepare, g_CompDo, g_CompDone,
                        g_HalBlit, g_HalClip, g_HalDes, g_HalMap,
                        g_HalCon, g_HalFlush, g_HalCommit, g_HalGetFmt,
                        g_HalEnableAB, g_HalDisableAB, 
                        g_HalBrush, g_HalDesBrush,
                        g_PreWaitCount, g_PreWaitCommitTime, g_PreWaitCommitCnt;
}
PMIndex, *PMIndexPtr;    

typedef struct __EXAProfilingModel
{
    int                 *pLogConfig;
    
    char                dumpEXAFileName[EXA_PM_MAX_FILE_NAME_LEN];
    unsigned int        dumpEXAFrameIndex;
    
    struct timeval      perfStart;
    struct timeval      perfEnd;
     
    PMIndex             index;                                                
}
EXAProfilingModel, *EXAProfilingModelPtr;

static inline void
perf_start_time(EXAProfilingModelPtr pm)
{
    gettimeofday( &pm->perfStart, NULL );
}

static inline unsigned long
perf_end_time(EXAProfilingModelPtr pm)
{
    gettimeofday( &pm->perfEnd, NULL );

    return 1000000 * ( pm->perfEnd.tv_sec - pm->perfStart.tv_sec ) + pm->perfEnd.tv_usec - pm->perfStart.tv_usec; 
}

static inline void
perf_reset_all_config(EXAProfilingModelPtr pm)
{
    memset(&pm->index, 0, sizeof(PMIndex));
}

#define MRVL_FERF_TRACE_LOG(pm, trace_id, fmt...) \
do \
{\
    if (!((pm)->pLogConfig))\
    {\
        break;\
    }\
    if (!(*((pm)->pLogConfig) & EXA_TRACE_ENABLE))\
    {\
        break;\
    }\
    if (*((pm)->pLogConfig) & EXA_TRACE_RESET)\
    {\
        perf_reset_all_config((pm));\
        *((pm)->pLogConfig) &= ~EXA_TRACE_RESET;\
    }\
    if (*((pm)->pLogConfig) & trace_id) \
    {\
        MRVL_LOG(fmt); \
    }\
}while(0)

#define MRVL_TRACE MRVL_LOG("FILE: %s, FUNC: %s, LINE: %d\n", __FILE__, __FUNCTION__, __LINE__);

#endif
