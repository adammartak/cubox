
//#include "mrvl.h"
#include "dovefb_driver.h"

#include <linux/fb.h>
#include <sys/ioctl.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <linux/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>
#include <unistd.h>

#include <sys/mman.h>
#include <sys/ioctl.h>
#include <sys/kd.h>

#include "mrvl_cursor.h"

#if MRVL_RANDR_EDID_MODES
#include "dovefb.h"
#endif

/* H/W register offset. */
#define DMA_CONTROL0	0x190

#define CRTC_DUMP_RAW_VIDEO         0

#if CRTC_DUMP_RAW_VIDEO
static char *g_dumpEXAFileName = "//crtc.rgb";
static unsigned int g_dumpEXAFrameIndex = 0;
#endif

#if MRVL_CRTC_SUPPORT_ROTATION
static void *
mrvl_crtc_shadow_allocate (xf86CrtcPtr crtc, int width, int height)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    FBDevRec* pDev = FBDEVPTR(pScrn);
    MRVLCrtcPrivatePtr pCrtcPriv = (MRVLCrtcPrivatePtr)crtc->driver_private;
    unsigned long rotate_pitch, clear_pitch;
    //unsigned long rotate_offset;
    //int rotate_size, clear_size;
    int i;

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_shadow_allocate, crtc %d, width %d, height %d, xoff %d, yoff %d, scrn virtual x %d, y %d, config virtual x %d, y %d \n", pCrtcPriv->crtc_id, width, height, crtc->x, crtc->y, pScrn->virtualX, pScrn->virtualY, pCrtcPriv->configVirtualX, pCrtcPriv->configVirtualY);

    rotate_pitch = pScrn->displayWidth * pScrn->bitsPerPixel / 8;
    //rotate_size = rotate_pitch * height;

    clear_pitch = width * pScrn->bitsPerPixel / 8;
    //clear_size = clear_pitch * height;

    /* We could get close to what we want here by just creating a pixmap like
     * normal, but we have to lock it down in framebuffer, and there is no
     * setter for offscreen area locking in EXA currently.  So, we just
     * allocate offscreen memory and fake up a pixmap header for it.
     */    

    // Point to the second frame buffer on base layer.
    pCrtcPriv->crtc_rotate_mem = pDev->fbstart + pScrn->displayWidth * pCrtcPriv->configVirtualY * (pCrtcPriv->crtc_id + 1) * pScrn->bitsPerPixel / 8;
    if (pCrtcPriv->crtc_rotate_mem == 0)
	    return NULL;

    // Need to clear new shadow buffer.
    for (i = 0; i < height; i++)
    {
        memset(((char *)pCrtcPriv->crtc_rotate_mem) + i * rotate_pitch, 0, clear_pitch);
    }

    pCrtcPriv->crtc_roate_phy_off = pScrn->displayWidth * pCrtcPriv->configVirtualY * (pCrtcPriv->crtc_id + 1) * pScrn->bitsPerPixel / 8;
  
    return pCrtcPriv->crtc_rotate_mem;
}


static PixmapPtr
mrvl_crtc_shadow_create(xf86CrtcPtr crtc, void *data, int width, int height)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    unsigned long rotate_pitch;
    PixmapPtr rotate_pixmap;
    int cpp = pScrn->bitsPerPixel / 8;
    MRVLCrtcPrivatePtr pCrtcPriv = (MRVLCrtcPrivatePtr)crtc->driver_private;

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_shadow_create, crtc [%d][%p], width %d, height %d, xoff %d, yoff %d, data %p\n", pCrtcPriv->crtc_id, crtc, width, height, crtc->x, crtc->y, data);
    
    if (!data)
	    data = mrvl_crtc_shadow_allocate(crtc, width, height);

    rotate_pitch = pScrn->displayWidth * cpp;

    rotate_pixmap = GetScratchPixmapHeader(pScrn->pScreen,
					   width, height,
					   pScrn->depth,
					   pScrn->bitsPerPixel,
					   rotate_pitch,
					   data);

    if (rotate_pixmap == NULL) {
	    xf86DrvMsg(pScrn->scrnIndex, X_INFO,
		   "Couldn't allocate shadow pixmap for rotated CRTC\n");
    }

    return rotate_pixmap;
}

static void
mrvl_crtc_shadow_destroy(xf86CrtcPtr crtc, PixmapPtr rotate_pixmap, void *data)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    //MRVLGetDescByScrn(pScrn);
    MRVLCrtcPrivatePtr pCrtcPriv = (MRVLCrtcPrivatePtr)crtc->driver_private;

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_shadow_destroy\n");

    if (rotate_pixmap)
	    FreeScratchPixmapHeader(rotate_pixmap);

#if CRTC_DUMP_RAW_VIDEO
    VIVDumpImage(g_dumpEXAFileName,
                 &g_dumpEXAFrameIndex, 
                 pCrtcPriv->crtc_rotate_mem, 
                 800, 
                 480,
                 16);
#endif

    if (data) {
	    pCrtcPriv->crtc_rotate_mem = NULL;
    }
}
#endif

int mrvl_crtc_config(xf86CrtcPtr crtc, int off)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    MRVLGetPrivateByScrn(pScrn);
    MRVLCrtcPrivatePtr pCrtcPriv = (MRVLCrtcPrivatePtr)crtc->driver_private;
    int fd;
    //struct fb_var_screeninfo var;
    struct fb_fix_screeninfo 	fb_finfo;
    int fb_size;
    char *mmio_regbase = 0;
    volatile unsigned int *ptr = 0;	
    
    /* open device */
    fd = pDev->gfx_fd[pCrtcPriv->crtc_id];

    if (fd < 0) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvl_crtc_config: crtc%d fd isn't valid\n", pCrtcPriv->crtc_id);
        return -2;
    }

    if (ioctl(fd, FBIOGET_FSCREENINFO, &fb_finfo)) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvl_crtc_config: fail to get fscreeninfo for crtc [%p]\n", crtc);
        return -1;
    } else {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvl_crtc_config: crtc [%p] get fscreeninfo successfully\n", crtc);
    }

    fb_size = fb_finfo.smem_len;
    /* map registers. */
    if ((mmio_regbase = (char *) mmap(0, 0x1C4, PROT_READ | PROT_WRITE, MAP_SHARED, fd, fb_size)) == (char *) -1) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "fail to mmap io regs in mrvl_crtc_config\n");
	return -1;
    }

    ptr = (unsigned int*)(mmio_regbase+DMA_CONTROL0);
    if (off) {
	xf86DrvMsg(pScrn->scrnIndex, X_INFO, "turn off crct%d\n", pCrtcPriv->crtc_id);
        *ptr &= ~(0x1 << 8 | 0x1);
    } else {
	xf86DrvMsg(pScrn->scrnIndex, X_INFO, "turn on crtc%d\n", pCrtcPriv->crtc_id);
        *ptr |= 0x1 << 8;
    }

    return 0;
}

void 
mrvl_crtc_dpms(xf86CrtcPtr crtc, int mode)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    MRVLCrtcPrivatePtr pCrtcPriv = (MRVLCrtcPrivatePtr)crtc->driver_private;
    FBDevRec* pDev = FBDEVPTR(pScrn);

    if (3 == mode) {  //off the output
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_dpms, mode %d\n", mode);
        /* set crtc to off status. */
        mrvl_crtc_config(crtc, 1);	
    }

    // Hide h/w cursor when prepare to switch mode.
    if (pDev->HWcursor)
    {
        DovefbHideCursor(pScrn, pCrtcPriv->crtc_id);
    }
}

static Bool
mrvl_crtc_mode_fixup(xf86CrtcPtr crtc, DisplayModePtr mode, DisplayModePtr adjusted_mode)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_mode_fixup, orig: width %d, height %d, ajust: width %d, height %d\n", 
                        mode->HDisplay, 
                        mode->VDisplay, 
                        adjusted_mode->HDisplay, 
                        adjusted_mode->VDisplay);
    return TRUE;
}

static void
mrvl_crtc_mode_prepare(xf86CrtcPtr crtc)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    MRVLCrtcPrivatePtr pCrtcPriv = (MRVLCrtcPrivatePtr)crtc->driver_private;
    FBDevRec* pDev = FBDEVPTR(pScrn);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_mode_prepare\n");
    
    // Hide h/w cursor when prepare to switch mode.
    if (pDev->HWcursor)
    {
        DovefbHideCursor(pScrn, pCrtcPriv->crtc_id);
    }
}

int mrvl_crtc_set_pos(xf86CrtcPtr crtc, int x, int y)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    MRVLGetPrivateByScrn(pScrn);
    MRVLCrtcPrivatePtr pCrtcPriv = (MRVLCrtcPrivatePtr)crtc->driver_private;
    int fd;
    struct fb_var_screeninfo var;
    int err;

    if (!pDev || !pCrtcPriv) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvl_crtc_set_pos: pDev or pCrtcPriv isn't valid.\n");
        return -2;
    }

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvl_crtc_set_pos: set crtc%d position (%d, %d)\n",
        pCrtcPriv->crtc_id, x, y);
    fd = pDev->gfx_fd[pCrtcPriv->crtc_id];

    if(fd < 0) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvl_crtc_set_pos: fd isn't valid\n");
        return -1;
    } else {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvl_crtc_set_pos: Open fb for crtc%d\n", pCrtcPriv->crtc_id);
    }

    /*get "var" screeninfo*/
    err = ioctl(fd, FBIOGET_VSCREENINFO, &var);
    if (err) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvl_crtc_set_pos: fail to get base layer info\n");
        return -1;
    }

    var.xoffset = x;
    var.activate = FB_ACTIVATE_NOW;

    if (crtc->rotation == RR_Rotate_0)
        var.yoffset = y;
    else {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvl_crtc_set_pos: var virtual x %d, y %d, scrn virtual x %d, y %d\n", var.xres_virtual, var.yres_virtual, pScrn->virtualX, pScrn->virtualY);

        var.yres_virtual = pCrtcPriv->configVirtualY * (pCrtcPriv->crtc_num + 1);
        var.xoffset = 0;
        var.yoffset = pCrtcPriv->configVirtualY * (pCrtcPriv->crtc_id + 1);
    }

    if (ioctl(fd, FBIOPUT_VSCREENINFO, &var) == -1) {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvl_crtc_set_pos:FBIOPUT_VSCREENINFO FAILED \n");
        return -1;
    }

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "leaving mrvl_crtc_set_pos: set crtc%d position (%d, %d)\n",
        pCrtcPriv->crtc_id, x, y);

    return 0;
} 

static void
mrvl_crtc_mode_set(xf86CrtcPtr crtc, DisplayModePtr mode, DisplayModePtr adjusted_mode, int x, int y)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    MRVLGetPrivateByScrn(pScrn);
    //MRVLCrtcPrivatePtr pCrtcPriv = (MRVLCrtcPrivatePtr)crtc->driver_private;

#if 1
    /* set crct to on status. */
    mrvl_crtc_config(crtc, 0);
#endif
    xf86DrvMsg(pScrn->scrnIndex, X_INFO,
		       "set mode_set x=%d, y=%d\n", x, y);

    if (pDev && crtc == pDev->pCrtc[0]) {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "LCD0 crtc mode = <%dx%d>, desired mode <%dx%d>\n",
            crtc->mode.HDisplay,
            crtc->mode.VDisplay,
            crtc->desiredMode.HDisplay,
            crtc->desiredMode.VDisplay);
    } else {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "LCD1 crtc mode = <%dx%d>, desired mode <%dx%d>\n",
            crtc->mode.HDisplay,
            crtc->mode.VDisplay,
            crtc->desiredMode.HDisplay,
            crtc->desiredMode.VDisplay);
    }
//    mrvl_crtc_set_pos(crtc, x, y);   
    pDev->rotation = crtc->rotation;
}

static void
mrvl_crtc_mode_commit(xf86CrtcPtr crtc)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    FBDevRec* pDev = FBDEVPTR(pScrn);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_mode_commit\n");

    // Reload h/w cursor after mode commit.
    if (pDev->HWcursor && crtc->scrn->pScreen != NULL)
    {
        xf86_reload_cursors(crtc->scrn->pScreen);
    }
}

static void
mrvl_crtc_gamma_set(xf86CrtcPtr crtc, uint16_t *red, uint16_t *green, uint16_t *blue, int size)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_gamma_set\n");
}

static Bool
mrvl_crtc_lock(xf86CrtcPtr crtc)
{
    ScrnInfoPtr pScrn = crtc->scrn;

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_lock\n");    
    
    return TRUE;
}

static void 
mrvl_crtc_unlock(xf86CrtcPtr crtc)
{
    ScrnInfoPtr pScrn = crtc->scrn;  

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_unlock\n");
}

static void
mrvl_crtc_set_cursor_colors(xf86CrtcPtr crtc, int bg, int fg)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    MRVLCrtcPrivatePtr pCrtcPriv = (MRVLCrtcPrivatePtr)crtc->driver_private;
    FBDevRec* pDev = FBDEVPTR(pScrn);

    //xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_set_cursor_colors, %d\n", pCrtcPriv->crtc_id);

    if (pDev->HWcursor)
    {
        DovefbSetCursorColors(pScrn, bg, fg, pCrtcPriv->crtc_id);
    }
}

static void
mrvl_crtc_set_cursor_position(xf86CrtcPtr crtc, int x, int y)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    MRVLCrtcPrivatePtr pCrtcPriv = (MRVLCrtcPrivatePtr)crtc->driver_private;
    FBDevRec* pDev = FBDEVPTR(pScrn);

    //xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_set_cursor_position, crtc [%d], x %d, y %d\n", pCrtcPriv->crtc_id, x, y);

    if (pDev->HWcursor)
    {
        DovefbSetCursorPosition(pScrn, x, y, pCrtcPriv->crtc_id);
    }
}

static void
mrvl_crtc_show_cursor(xf86CrtcPtr crtc)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    MRVLCrtcPrivatePtr pCrtcPriv = (MRVLCrtcPrivatePtr)crtc->driver_private;
    FBDevRec* pDev = FBDEVPTR(pScrn);

    //xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_show_cursor, crtc [%d]\n", pCrtcPriv->crtc_id);

    if (pDev->HWcursor)
    {
        DovefbShowCursor(pScrn, pCrtcPriv->crtc_id);
    }
}

static void 
mrvl_crtc_hide_cursor(xf86CrtcPtr crtc)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    MRVLCrtcPrivatePtr pCrtcPriv = (MRVLCrtcPrivatePtr)crtc->driver_private;
    FBDevRec* pDev = FBDEVPTR(pScrn);

    //xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_hide_cursor, crtc [%d]\n", pCrtcPriv->crtc_id);

    if (pDev->HWcursor)
    {
        DovefbHideCursor(pScrn, pCrtcPriv->crtc_id);
    }
}

static void 
mrvl_crtc_load_cursor_argb(xf86CrtcPtr crtc, CARD32 *image)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    MRVLCrtcPrivatePtr pCrtcPriv = (MRVLCrtcPrivatePtr)crtc->driver_private;
    FBDevRec* pDev = FBDEVPTR(pScrn);

    //xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_load_cursor_argb, crtc [%d][%p]\n", pCrtcPriv->crtc_id, crtc);

    if (pDev->HWcursor)
    {
        DovefbLoadCursorARGB(pScrn, image, pCrtcPriv->crtc_id);
    }

#if CRTC_DUMP_RAW_VIDEO
    VIVDumpImage(g_dumpEXAFileName,
                 &g_dumpEXAFrameIndex, 
                 image, 
                 64, 
                 64,
                 32);
#endif

}

static void
mrvl_crtc_set_origin(xf86CrtcPtr crtc, int x, int y)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_set_origin\n");
    mrvl_crtc_set_pos(crtc, x, y);   
} 

static void mrvl_crtc_save(xf86CrtcPtr         crtc)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_save\n");
}

static void mrvl_crtc_restore(xf86CrtcPtr      crtc)
{
    ScrnInfoPtr pScrn = crtc->scrn;
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_crtc_restore\n");
}

static xf86CrtcFuncsRec mrvl_crtc_funcs = {
    .dpms = mrvl_crtc_dpms,
    .save = mrvl_crtc_save, /* XXX */
    .restore = mrvl_crtc_restore, /* XXX */
    .mode_fixup = mrvl_crtc_mode_fixup,
    .prepare = mrvl_crtc_mode_prepare,
    .mode_set = mrvl_crtc_mode_set,
    .commit = mrvl_crtc_mode_commit,
    .gamma_set = mrvl_crtc_gamma_set,
    .lock = mrvl_crtc_lock,
    .unlock = mrvl_crtc_unlock,
#if MRVL_CRTC_SUPPORT_ROTATION == 0
    .shadow_create = NULL,
    .shadow_allocate = NULL,
    .shadow_destroy = NULL,
#else
    .shadow_create = mrvl_crtc_shadow_create,
    .shadow_allocate = mrvl_crtc_shadow_allocate,
    .shadow_destroy = mrvl_crtc_shadow_destroy,
#endif
    .set_cursor_colors = mrvl_crtc_set_cursor_colors,
    .set_cursor_position = mrvl_crtc_set_cursor_position,
    .show_cursor = mrvl_crtc_show_cursor,
    .hide_cursor = mrvl_crtc_hide_cursor,
    .load_cursor_argb = mrvl_crtc_load_cursor_argb,
    .destroy = NULL, /* XXX */
#if XF86_CRTC_VERSION >= 2
    .set_origin = mrvl_crtc_set_origin,
#endif
};


Bool mrvlCrtcInit(ScrnInfoPtr pScrn)
{
    FBDevRec* pDev = FBDEVPTR(pScrn);
    int i, fd, err;
    struct fb_var_screeninfo var;
    int crtc_num = 0;
#if MRVL_RANDR_EDID_MODES
    struct _sEdidInfo edid_info;
#endif

    crtc_num = 0;
    for( i = 0; i < MRVL_MAX_CRTC_COUNT; i++) {
#if MRVL_PLATFORM_INFO==MRVL_DOVE
        pDev->gfx_fd[i] = open( (i ? GFX_DEV1:GFX_DEV0), O_RDWR);
#elif MRVL_PLATFORM_INFO==MRVL_MMP2
        pDev->gfx_fd[i] = open( (i ? MMP2_TV_GFX:MMP2_GFX), O_RDWR);
#endif
        pDev->pCrtc[i] = 0;
    
        if(pDev->gfx_fd[i] >= 0) 
            crtc_num++;
    }

    pDev->crtc_num = crtc_num;

    if (crtc_num == 0) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvlCrtcInit: Can not find any fb device.\n");
        return FALSE;
    } else {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvlCrtcInit: Found %d fb devices\n", crtc_num);
    }

    for( i=0; i < crtc_num; i++) {

        fd = pDev->gfx_fd[i];
    
        if(fd < 0) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvlCrtcInit: fd is not valid.\n" );
            break;
        }

        /*get "var" screeninfo*/
        err = ioctl(fd, FBIOGET_VSCREENINFO, &var);
        if (err) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvlCrtcInit: Can not get fb vscreen info\n");
            return FALSE;
        }
#if MRVL_PLATFORM_INFO==MRVL_DOVE
        var.xres_virtual = pScrn->virtualX;
#if MRVL_CRTC_SUPPORT_ROTATION == 0
        var.yres_virtual = pScrn->virtualY;
#else
        var.yres_virtual = pScrn->virtualY * (crtc_num + 1);
#endif
        var.bits_per_pixel = pScrn->bitsPerPixel;
#endif
        var.activate = FB_ACTIVATE_NOW;

        if (ioctl(fd, FBIOPUT_VSCREENINFO, &var) == -1) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvlCrtcInit: Can not put fb vscreen info\n");
            return FALSE;
        }

        /*get "var" screeninfo*/
        err = ioctl(fd, FBIOGET_VSCREENINFO, &var);
        if (err) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvlCrtcInit: Can not get fb vscreen info\n");
            return FALSE;
        }

        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvlCrtcInit: crtc [%d], lcd virtual x %d, y %d\n",
            i, var.xres_virtual, var.yres_virtual);

        // Reserve initial virtual X and Y for randr shadow buffer.
        pDev->controller[i].configVirtualX = pScrn->virtualX;
        pDev->controller[i].configVirtualY = pScrn->virtualY;

#if MRVL_RANDR_EDID_MODES
        ioctl(fd, DOVEFB_IOCTL_GET_EDID_INFO, &edid_info);
        pDev->controller[i].output_connected = edid_info.connect;
#endif

        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvlCrtcInit: create crtc%d.\n", i);
	/* Create crtc resource. */
        pDev->pCrtc[i] = xf86CrtcCreate(pScrn, &mrvl_crtc_funcs);

        if (!pDev->pCrtc[i])
        {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Can not create crtc LCD%d\n", i);
            return FALSE;    
        }
    
        pDev->pCrtc[i]->driver_private    = (void *)&pDev->controller[i];
        pDev->controller[i].crtc_id       = i;
        pDev->controller[i].crtc_num      = crtc_num;
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvlCrtcInit: crtc%d has been initialized.\n", i);
    }

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvlCrtcInit: completed.\n");

    return TRUE;
}
