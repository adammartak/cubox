
uint32_t    mrvl_allocate_memory(ScrnInfoPtr pScrn,
                		       void **mem_struct,
                		       int size,
                		       int align);
void        mrvl_free_memory(ScrnInfoPtr pScrn, void *mem_struct);