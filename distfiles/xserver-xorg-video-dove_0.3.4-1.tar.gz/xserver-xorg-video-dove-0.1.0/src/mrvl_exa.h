/******************************************************************************
//(C) Copyright 2009 Marvell International Ltd.
//All Rights Reserved
******************************************************************************/
#ifndef MRVL_EXA_HEADER
#define MRVL_EXA_HEADER

#include <unistd.h>

#include "list.h"
#include "exa.h"
#include "gc_hal_base.h"
#include "gc_hal_raster.h"
#include "gc_hal_enum.h"
#include "gc_hal.h"
#include "mrvl_heap.h"
#include "mrvl_debug.h"

#if MRVL_EXA_PERF_PROFILING
#include "mrvl_exa_profiling.h"
#endif

#define ROP_BRUSH                     0xF0
#define ROP_SRC                       0xCC
#define ROP_DST                       0xAA
#define ROP_BRUSH_CONVERSE            0x0F 
#define ROP_SRC_CONVERSE              0x33
#define ROP_DST_CONVERSE              0x55
#define ROP_WHITE                     0xFF
#define ROP_BLACK                     0x00
#define ROP_DST_AND_SRC               0x88
#define ROP_DST_OR_SRC                0xEE
#define ROP_DST_XOR_SRC               0x66

#define ROP_NOT_SRC                   (~ROP_SRC)
#define ROP_NOT_SRC_OR_DST            (~ROP_SRC | ROP_DST)
#define ROP_NOT_SRC_OR_NOT_DST        (~ROP_SRC | ~ROP_DST)
#define ROP_SRC_OR_NOT_DST                (ROP_SRC | ~ROP_DST)
#define ROP_NOT_DST                   (~ROP_DST) 
#define ROP_NOT_SRC_XOR_DST           (~ROP_SRC ^ ROP_DST)
#define ROP_NOT_SRC_AND_NOT_DST       (~ROP_SRC & ~ROP_DST) 
#define ROP_NOT_SRC_AND_DST           (~ROP_SRC & ROP_DST)
#define ROP_SRC_AND_NOT_DST           (ROP_SRC  & ~ROP_DST)

#define ROP_BRUSH_AND_DST             0xA0
#define ROP_BRUSH_OR_DST              0xFA
#define ROP_BRUSH_XOR_DST             0x5A
#define ROP_BRUSH_AND_SRC             0xC0
#define ROP_BRUSH_OR_SRC              0xFC
#define ROP_BRUSH_XOR_SRC             0x3C

#define ROP_BRUSH_OR_SRC_OR_DST       0xFE
#define ROP_BRUSH_OR_SRC_AND_DST      0xF8
#define ROP_BRUSH_OR_SRC_XOR_DST      0x56
#define ROP_BRUSH_AND_SRC_OR_DST      0xEA
#define ROP_BRUSH_AND_SRC_AND_DST     0x80
#define ROP_BRUSH_AND_SRC_XOR_DST     0x6A
#define ROP_BRUSH_XOR_SRC_OR_DST      0xBE
#define ROP_BRUSH_XOR_SRC_AND_DST     0x28
#define ROP_BRUSH_XOR_SRC_XOR_DST     0x96


#define ROP_BRUSH_OR_DST_AND_SRC      0xC8
#define ROP_BRUSH_OR_DST_XOR_SRC      0x36
#define ROP_BRUSH_AND_DST_OR_SRC      0xEC
#define ROP_BRUSH_AND_DST_XOR_SRC     0x0C
#define ROP_BRUSH_XOR_DST_OR_SRC      0xDE
#define ROP_BRUSH_XOR_DST_AND_SRC     0x48

#define ROP_SRC_OR_DST_AND_BRUSH      0xE0
#define ROP_SRC_OR_DST_XOR_BRUSH      0x1E
#define ROP_SRC_AND_DST_XOR_BRUSH     0x78
#define ROP_SRC_XOR_DST_OR_BRUSH      0xF6
#define ROP_SRC_XOR_DST_AND_BRUSH     0x60

#if MRVL_EXA_TRACE_FALLBACK

#define MRVL_FALLBACK(fmt...) \
do \
{\
    MRVL_LOG(fmt); \
    goto fallback; \
}while(0)

#else

#define MRVL_FALLBACK(fmt...) \
do \
{\
    goto fallback; \
}while(0)

#endif

#define VIVANTE_MAX_WIDTH     (1<<11)
#define VIVANTE_MAX_HEIGHT    (1<<11)

#define MRVL_SURF_WIDTH_ALIGNMENT    8

#define MEM_PAGE_ALIGN_DOWN(a, size)            ((a) - (a) % (size))
#define MEM_PAGE_ALIGN_UP(a, size)              ( ((a) + ((size) - 1)) - ((a) + ((size) - 1)) % (size) )

#define EXA_PIXMAP_PINNED_TYPE          1
#define EXA_PIXMAP_OVERSIZE_TYPE        2 
#define EXA_PIXMAP_UNSUPPORTED_BPP      4
#define EXA_PIXMAP_CAN_ACCEL_TYPE       8

#define MEM_UNKNOWN_SEGMENT             0
#define MEM_VIDEO_SEGMENT               1
#define MEM_SYSTEM_SEGMENT              2
#define MEM_LCD_FRAME_BUFFER            3

#define LCD_FRAME_NONE                  0
#define LCD_FRAME_FRONT_BUFFER          (1 << 0)
#define LCD_FRAME_SHADOW_BUFFER         (1 << 1)

#define FAKE_FENCE_POOL_MAX_WIDTH    128
#define FAKE_FENCE_POOL_MAX_HEIGHT   128
#define FAKE_FENCE_POOL_MAX_TIMEOUT  1000

#define MRVL_EXA_MIN_PIXEL_FENCE_COUNT      500

typedef struct __FakeFence
{    
    unsigned int        *pFenceMarker;
    unsigned int        dwFenceMarkerAddr;
    unsigned int        syncMarker;
    unsigned int        xDir;
    unsigned int        yDir; 
    PixmapPtr           pPixmap;
    
    struct list_head    list_entry;
}
FakeFence, *FakeFencePtr;

typedef struct __FakeFencePool
{
    gcoSURF             fenceSurf;
    unsigned int        physicalAddress;
    unsigned int       *virtualAddress;
    unsigned int        allocIndex;
    Bool                bInit;
    unsigned int        dwAlignedWidth;
    unsigned int        dwAlignedHeight;
    int                 iAlignedStride;
    
    struct list_head    busyList;
    struct list_head    freeList;
}
FakeFencePool, *FakeFencePoolPtr;

typedef struct __BlendOp
{
	gceSURF_BLEND_FACTOR_MODE srcFactorMode;
	gceSURF_BLEND_FACTOR_MODE dstFactorMode;
}
BlendOp, *BlendOpPtr;

typedef struct __PixmapSurface
{
    unsigned int     dwSurfaceType;
    
    PixmapPtr        pPixmap;
    gcoSURF          pSurf;

    unsigned int     dwPhyAddr;
    unsigned char    *pVirtAddr;
    
    unsigned int     dwFrameBufferType; 
    
    int              iWidth;
    int              iHeight;
    int              iDepth;
    
    gceSURF_FORMAT   format;
    
    unsigned int     dwAlignedWidth;
    unsigned int     dwAlignedHeight;
    int              iAlignedStride;
    
    Bool             bDriverAlloc;    
    unsigned int     dwMemorySegment;
    unsigned int     dwType;

    Bool             bOffscreen;
    
    FakeFencePtr     pFakeFence;  

#if MRVL_EXA_XBGR_SUPPORT
    Bool             bRBWrapped;
#endif
}
PixmapSurface, *PixmapSurfacePtr;

typedef struct __ExaOperation 
{
    struct {         
        Pixel           pm;
        PixmapPtr	    pPix;
        Pixel           fgColor;                             
    } solid;
    
    struct {
        Pixel           pm;                        
        PixmapPtr       pSrc;
        PixmapPtr       pDst; 
        gctUINT8        fg_rop;
        gctUINT8        bg_rop;           
    } copy;
    
    struct {
        int		        op;            
        PicturePtr      pSrcPict; 
        PicturePtr      pMaskPict;
        PicturePtr      pDstPict;
        PixmapPtr       pSrc;
        PixmapPtr       pMask;
        PixmapPtr       pDst;            
    } composite;

    Bool                bNeedFence;       
}
ExaOperation, *ExaOperationPtr;

typedef struct __ExaInfoRec
{
    ExaDriverPtr            ExaDriver;
    
    gcoOS                   Os;
    gcoHAL                  Hal;
    gco2D                   Engine2D;

    unsigned long           videoMemSize;
    unsigned long           videoMemPhysicalAddr;
    void *                  videoMemVirtualAddr;
    
    ExaOperation            op;
    FakeFencePool           fakeFencePool;   
    
#if MRVL_EXA_PERF_PROFILING    
    EXAProfilingModel       pm;
#endif

    PixmapPtr               alphaPixmap;
    PixmapPtr               maskPixmap;
    PixmapPtr               repeatPixmap;
}
ExaInfoRec, *ExaInfoPtr;

#if MRVL_EXA_PERF_PROFILING
static inline Bool
mrvlInitializeProfilingModel(ScreenPtr pScreen, EXAProfilingModel *pm, char *dumpFilename, int initValue)
{
    int logConfigFD;
    int initLogValue = initValue;
    int retValue;

    xf86DrvMsg(pScreen->myNum, X_INFO, "PM: Initialize profiling model .....\n");

    logConfigFD = open("/tmp/xlogcfg", O_RDWR | O_CREAT, S_IRWXU | S_IRWXG | S_IRWXO);
    if (logConfigFD)
    {
         retValue = write(logConfigFD, &initLogValue, sizeof(int));
         pm->pLogConfig = (int *) mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, logConfigFD, 0);
         xf86DrvMsg(pScreen->myNum, X_INFO, "PM: Map /tmp/xlogcfg , value 0x%X\n", *pm->pLogConfig);
         close(logConfigFD);
    } 
    else
    {
        pm->pLogConfig = NULL;

        xf86DrvMsg(pScreen->myNum, X_ERROR, "PM: Map /tmp/xlogcfg fails\n");

        return FALSE; 
    }         

    pm->dumpEXAFrameIndex = 0;

    if (strlen(dumpFilename) < EXA_PM_MAX_FILE_NAME_LEN)
        strcpy(pm->dumpEXAFileName, dumpFilename);
    else
        strcpy(pm->dumpEXAFileName, "/dump.rgb");

    xf86DrvMsg(pScreen->myNum, X_INFO, "PM: dump file name is %s\n", pm->dumpEXAFileName);

    return TRUE;
}
#endif

/********************* APIs for fence pool *********************************/
Bool
mrvlFencePoolInit(gcoHAL pHal, FakeFencePoolPtr pFakeFencePool);
void 
mrvlFencePoolDeinit(gcoHAL pHal, FakeFencePoolPtr pFakeFencePool);
FakeFencePtr 
mrvlFencePoolAlloc(FakeFencePoolPtr pFakeFencePool);
void
mrvlFencePoolFree(FakeFencePoolPtr pFakeFencePool, FakeFencePtr pFakeFence);
Bool
mrvlFencePoolCommit(ScreenPtr pScreen, FakeFencePtr pFakeFence);
Bool
mrvlFencePoolKickOff(ScreenPtr pScreen, FakeFencePtr pFakeFence);
void
mrvlFencePoolStall(FakeFencePtr pFakeFence);
void 
mrvlFencePoolAssignPixmap(FakeFencePtr pFakeFence, PixmapPtr pPixmap);
PixmapPtr
mrvlCreateTempPixmap(ScreenPtr pScreen, int width, int height, int bpp);
void
mrvlDestroyTempPixmap(ScreenPtr pScreen, PixmapPtr pPixmap);

/* exporte exa functions */
Bool    
mrvlPrepareAccess(PixmapPtr pPix, int index);
void    
mrvlFinishAccess(PixmapPtr pPix, int index);
Bool 
mrvlExaInit(ScreenPtr pScreen);
Bool
mrvlExaShutdown(ScreenPtr pScreen);
Bool 
mrvlExaInitHal(ScreenPtr pScreen);
Bool 
mrvlExaShutdownHal(ScreenPtr pScreen);

#include "mrvl_exa_utils.h"

#endif
