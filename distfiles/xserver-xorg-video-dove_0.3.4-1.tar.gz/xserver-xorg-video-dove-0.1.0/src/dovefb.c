/*
 * Authors:  Alan Hourihane, <alanh@fairlite.demon.co.uk>
 *	     Michel Dänzer, <michel@tungstengraphics.com>
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <string.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

/* all driver need this */
#include "xf86.h"
#include "xf86_OSproc.h"

#include "mipointer.h"
#include "mibstore.h"
#include "micmap.h"
#include "colormapst.h"
#include "xf86cmap.h"
#include "shadow.h"
#include "dgaproc.h"

/* for visuals */
#include "fb.h"
#ifdef USE_AFB
#include "afb.h"
#endif

#if GET_ABI_MAJOR(ABI_VIDEODRV_VERSION) < 6
#include "xf86Resources.h"
#include "xf86RAC.h"
#endif

#include "fbdevhw.h"

#include "xf86xv.h"

#include "dovefb_driver.h"
#ifdef XSERVER_LIBPCIACCESS
#include <pciaccess.h>
#endif

static Bool debug = 0;
Bool debug_opt = 0;
/* ------< added by Green >--------- */
#include <linux/fb.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <errno.h>

extern void DovefbXVInitVideo(ScreenPtr pScreen);
extern Bool DovefbCursorInit(ScreenPtr pScreen);
extern void DovefbDestroyFilterSurface(ScreenPtr pScreen);

int enc_func;
/* -------------------------------- */

#define TRACE_ENTER(str) \
    do { if (debug) ErrorF("fbdev: " str " %d\n",pScrn->scrnIndex); } while (0)
#define TRACE_EXIT(str) \
    do { if (debug) ErrorF("fbdev: " str " done\n"); } while (0)
#define TRACE(str) \
    do { if (debug) ErrorF("fbdev trace: " str "\n"); } while (0)

/* -------------------------------------------------------------------- */
/* prototypes                                                           */

static const OptionInfoRec * FBDevAvailableOptions(int chipid, int busid);
static void	FBDevIdentify(int flags);
static Bool	FBDevProbe(DriverPtr drv, int flags);
#ifdef XSERVER_LIBPCIACCESS
static Bool	FBDevPciProbe(DriverPtr drv, int entity_num,
     struct pci_device *dev, intptr_t match_data);
#endif
static Bool	FBDevPreInit(ScrnInfoPtr pScrn, int flags);
static Bool	FBDevScreenInit(int Index, ScreenPtr pScreen, int argc,
				char **argv);
static Bool	FBDevCloseScreen(int scrnIndex, ScreenPtr pScreen);
static void *	FBDevWindowLinear(ScreenPtr pScreen, CARD32 row, CARD32 offset, int mode,
				  CARD32 *size, void *closure);
static void	FBDevPointerMoved(int index, int x, int y);
static Bool	FBDevDGAInit(ScrnInfoPtr pScrn, ScreenPtr pScreen);
static Bool	FBDevDriverFunc(ScrnInfoPtr pScrn, xorgDriverFuncOp op,
				pointer ptr);


enum { FBDEV_ROTATE_NONE=0, FBDEV_ROTATE_CW=270, FBDEV_ROTATE_UD=180, FBDEV_ROTATE_CCW=90 };


/* -------------------------------------------------------------------- */

/*
 * This is intentionally screen-independent.  It indicates the binding
 * choice made in the first PreInit.
 */
static int pix24bpp = 0;

#define FBDEV_VERSION		4000
#define FBDEV_NAME		"dovefb"
#define FBDEV_DRIVER_NAME	"dovefb"
#define FBDEV_MAJOR_VERSION	0
#define FBDEV_MINOR_VERSION	3

#ifdef XSERVER_LIBPCIACCESS
static const struct pci_id_match fbdev_device_match[] = {
    {
	PCI_MATCH_ANY, PCI_MATCH_ANY, PCI_MATCH_ANY, PCI_MATCH_ANY,
	0x00030000, 0x00ffffff, 0
    },

    { 0, 0, 0 },
};
#endif

_X_EXPORT DriverRec FBDEV = {
	FBDEV_VERSION,
	FBDEV_DRIVER_NAME,
#if 0
	"driver for linux framebuffer devices",
#endif
	FBDevIdentify,
	FBDevProbe,
	FBDevAvailableOptions,
	NULL,
	0,
	FBDevDriverFunc,

#ifdef XSERVER_LIBPCIACCESS
    fbdev_device_match,
    FBDevPciProbe
#endif
};

/* Supported "chipsets" */
static SymTabRec FBDevChipsets[] = {
    { 0, "88AP510" },
#ifdef USE_AFB
    { 0, "afb" },
#endif
    {-1, NULL }
};

static const OptionInfoRec FBDevOptions[] = {
    { OPTION_SHADOW_FB,      "ShadowFB",              OPTV_BOOLEAN, {0}, FALSE },
    { OPTION_ROTATE,         "Rotate",                OPTV_STRING,  {0}, FALSE },
    { OPTION_FBDEV,          "fbdev",                 OPTV_STRING,  {0}, FALSE },
    { OPTION_DEBUG,          "debug",                 OPTV_BOOLEAN, {0}, FALSE },
    { OPTION_VIDEO_KEY,	     "VideoKey",              OPTV_INTEGER, {0}, FALSE }, // add for video colorkey.
    { OPTION_ENC_FUNC,       "EncFunc",	              OPTV_INTEGER, {0}, FALSE }, // add for video colorkey.
    { OPTION_HW_CURSOR,	     "HWcursor",              OPTV_BOOLEAN, {0}, FALSE }, // add for hw cursor.
    { OPTION_EXA_ACCEL,      "ExaAccel",              OPTV_BOOLEAN, {0}, FALSE },
    { OPTION_XV_ACCEL,       "XvAccel",               OPTV_BOOLEAN, {0}, FALSE },
    { OPTION_SOLID_ACCEL,    "Solid",                 OPTV_BOOLEAN, {0}, FALSE },
    { OPTION_COPY_ACCEL,     "Copy",                  OPTV_BOOLEAN, {0}, FALSE },
    { OPTION_COMP_ACCEL,     "Composite",             OPTV_BOOLEAN, {0}, FALSE },
    { OPTION_COMMIT,         "Commit",                OPTV_BOOLEAN, {0}, FALSE },
    { OPTION_SW_SOLID,       "SWSolid",               OPTV_BOOLEAN, {0}, FALSE },
    { OPTION_SW_COPY,        "SWCopy",                OPTV_BOOLEAN, {0}, FALSE },
    { OPTION_USE_GPU,        "UseGPU",                OPTV_BOOLEAN, {0}, FALSE },
#ifdef RENDER
    { OPTION_RENDER_ACCEL,    "RenderAccel",          OPTV_BOOLEAN, {0}, FALSE },
    { OPTION_SUBPIXEL_ORDER,  "SubPixelOrder",        OPTV_ANYSTR,  {0}, FALSE },
#endif
    { OPTION_USE_DRIVER_MODE, "UseDriverBuiltInMode", OPTV_BOOLEAN, {0}, FALSE },
    { OPTION_DUAL_DISPLAY,    "EnableDualDisplay",    OPTV_BOOLEAN, {0}, TRUE  },
    { -1,                     NULL,                   OPTV_NONE,    {0}, FALSE }
};

/* -------------------------------------------------------------------- */

static const char *afbSymbols[] = {
	"afbScreenInit",
	"afbCreateDefColormap",
	NULL
};

static const char *fbSymbols[] = {
	"fbScreenInit",
	"fbPictureInit",
	NULL
};

#if 0
static const char *exaSymbols[] = {
    "exaDriverInit",
    "exaDriverFini",
    "exaGetPixmapOffset",
    "exaGetPixmapPitch",
    "exaGetPixmapSize",
    "exaWaitSync",
    "exaGetVersion",
    "exaDriverAlloc",
    NULL
};

static const char *shadowSymbols[] = {
	"shadowAdd",
	"shadowInit",
	"shadowSetup",
	"shadowUpdatePacked",
	"shadowUpdatePackedWeak",
	"shadowUpdateRotatePacked",
	"shadowUpdateRotatePackedWeak",
	NULL
};

static const char *fbdevHWSymbols[] = {
	"fbdevHWInit",
	"fbdevHWProbe",
	"fbdevHWSetVideoModes",
	"fbdevHWUseBuildinMode",

	"fbdevHWGetDepth",
	"fbdevHWGetLineLength",
	"fbdevHWGetName",
	"fbdevHWGetType",
	"fbdevHWGetVidmem",
	"fbdevHWLinearOffset",
	"fbdevHWLoadPalette",
	"fbdevHWMapVidmem",
	"fbdevHWUnmapVidmem",

	/* colormap */
	"fbdevHWLoadPalette",
	"fbdevHWLoadPaletteWeak",

	/* ScrnInfo hooks */
	"fbdevHWAdjustFrameWeak",
	"fbdevHWEnterVTWeak",
	"fbdevHWLeaveVTWeak",
	"fbdevHWModeInit",
	"fbdevHWRestore",
	"fbdevHWSave",
	"fbdevHWSaveScreen",
	"fbdevHWSaveScreenWeak",
	"fbdevHWSwitchModeWeak",
	"fbdevHWValidModeWeak",

	"fbdevHWDPMSSet",
	"fbdevHWDPMSSetWeak",

	NULL
};
#endif

#ifdef XFree86LOADER

MODULESETUPPROTO(FBDevSetup);

static XF86ModuleVersionInfo FBDevVersRec =
{
	"fbdev",
	MODULEVENDORSTRING,
	MODINFOSTRING1,
	MODINFOSTRING2,
	XORG_VERSION_CURRENT,
	FBDEV_MAJOR_VERSION, FBDEV_MINOR_VERSION, 0,
	ABI_CLASS_VIDEODRV,
	ABI_VIDEODRV_VERSION,
	NULL,
	{0,0,0,0}
};

_X_EXPORT XF86ModuleData dovefbModuleData = { &FBDevVersRec, FBDevSetup, NULL };

pointer
FBDevSetup(pointer module, pointer opts, int *errmaj, int *errmin)
{
	static Bool setupDone = FALSE;

	if (!setupDone) {
		setupDone = TRUE;
		xf86AddDriver(&FBDEV, module, HaveDriverFuncs);
		
		return (pointer)TRUE;
	} else {
		if (errmaj) *errmaj = LDR_ONCEONLY;
		return NULL;
	}
}

#endif /* XFree86LOADER */

static Bool
FBDevGetRec(ScrnInfoPtr pScrn)
{
	if (pScrn->driverPrivate != NULL)
		return TRUE;
	
	pScrn->driverPrivate = xnfcalloc(sizeof(FBDevRec), 1);
	return TRUE;
}

static void
FBDevFreeRec(ScrnInfoPtr pScrn)
{
	if (pScrn->driverPrivate == NULL)
		return;
	xfree(pScrn->driverPrivate);
	pScrn->driverPrivate = NULL;
}

static const OptionInfoRec *
FBDevAvailableOptions(int chipid, int busid)
{
	return FBDevOptions;
}

static void
FBDevIdentify(int flags)
{
	xf86PrintChipsets(FBDEV_NAME, "Support Marvell LCD Controller", FBDevChipsets);
}

ModeStatus
mrvl_scn_validMode(int scrnIndex, DisplayModePtr mode, Bool verbose, int flags)
{
    if (mode->Flags & V_DBLSCAN) 
    {
	    return MODE_CLOCK_RANGE;
    }

    return MODE_OK;
}

Bool
mrvl_scn_switchMode(int scrnIndex, DisplayModePtr mode, int flags)
{
    ScrnInfoPtr    pScrn       = xf86Screens[scrnIndex];
    Bool  ret;

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Preparing to switch single mode\n");

    ret = xf86SetSingleMode (pScrn, mode, RR_Rotate_0);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "switch mode OK\n");

    return ret;
}

extern int mrvl_crtc_set_pos(xf86CrtcPtr crtc, int x, int y);

void
mrvl_scn_adjustFrame(int scrnIndex, int x, int y, int flags)
{
    ScrnInfoPtr    pScrn      = xf86Screens[scrnIndex];
    xf86CrtcConfigPtr	config = XF86_CRTC_CONFIG_PTR(pScrn);
    xf86OutputPtr  output = config->output[config->compat_output];
    xf86CrtcPtr	crtc = output->crtc;

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Preparing to adjust frame\n");

    if (crtc && crtc->enabled) 
    {	    
	    crtc->x = output->initial_x + x;
	    crtc->y = output->initial_y + y;

        mrvl_crtc_set_pos(crtc, crtc->x, crtc->y);
    }

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Adjust frame OK\n");
}

extern int mrvl_output_config(xf86OutputPtr output, struct fb_var_screeninfo *var);
extern void mrvl_crtc_dpms(xf86CrtcPtr crtc, int mode);

static Bool mrvl_save_fb(int index, struct fb_var_screeninfo *var)
{
    int fd;

    if (index >= 2) return FALSE;

    if (index == 1) {
        fd = open("/dev/fb2", O_RDWR);
    } else {
   	    fd = open("/dev/fb0", O_RDWR);
    }
    
    if(fd <= 0) 
    {    
        xf86DrvMsg(0, X_ERROR, " mrvl_save_fb: Can not open /dev/fb%d\n", index ? 0 : 2);       
        return FALSE;
    }

    if (0 != ioctl(fd,FBIOGET_VSCREENINFO,(void*)var))
		xf86DrvMsg(0, X_ERROR,
			   "mrvl_save_fb: FBIOGET_VSCREENINFO: %s\n", strerror(errno));

    close(fd);

    return TRUE;
}

static Bool mrvl_restore_fb(int index, struct fb_var_screeninfo *var)
{
    int fd;

    if (index >= 2) return FALSE;

    if (index == 1) {
        fd = open("/dev/fb2", O_RDWR);
    } else {
   	    fd = open("/dev/fb0", O_RDWR);
    }
    
    if(fd <= 0) 
    {    
        xf86DrvMsg(0, X_ERROR, " mrvl_restore_fb: Can not open /dev/fb%d\n", index ? 0 : 2);       
        return FALSE;
    }

    xf86DrvMsg(0, X_INFO, "VT: mrvl_restore_fb: restore crtc[%d] to %dx%d\n", index, var->xres, var->yres);
    if (0 != ioctl(fd,FBIOPUT_VSCREENINFO,(void*)var))
		xf86DrvMsg(0, X_ERROR,
			   "mrvl_restore_fb: FBIOPUT_VSCREENINFO: %s\n", strerror(errno));

    close(fd);

    return TRUE;
}

static Bool mrvlSaveFBScreen(ScrnInfoPtr pScrn)
{
    xf86CrtcConfigPtr config = XF86_CRTC_CONFIG_PTR(pScrn);
    MRVLGetPrivateByScrn(pScrn);
    int i;

    for (i = 0; i < config->num_crtc; i++) 
    {
        if (!mrvl_save_fb(i, &pDev->fb_console_var[i]))
            continue;
    }

    return TRUE;
}

static Bool mrvlRestoreFBScreen(ScrnInfoPtr pScrn)
{
    xf86CrtcConfigPtr config = XF86_CRTC_CONFIG_PTR(pScrn);
    MRVLGetPrivateByScrn(pScrn);
    int i;

    for (i = 0; i < config->num_crtc; i++) 
    {
        if (!mrvl_restore_fb(i, &pDev->fb_console_var[i]))
            continue;
    }

    return TRUE;
}

static Bool mrvlSaveServerScreen(ScrnInfoPtr pScrn)
{
    xf86CrtcConfigPtr config = XF86_CRTC_CONFIG_PTR(pScrn);
    MRVLGetPrivateByScrn(pScrn);
    int i;

    for (i = 0; i < config->num_crtc; i++) 
    {
        if (!mrvl_save_fb(i, &pDev->xserver_var[i]))
            continue;
    }

    return TRUE;
}

static Bool mrvlRestoreServerScreen(ScrnInfoPtr pScrn)
{
    xf86CrtcConfigPtr config = XF86_CRTC_CONFIG_PTR(pScrn);
    MRVLGetPrivateByScrn(pScrn);
    int i;

    for (i = 0; i < config->num_crtc; i++) 
    {
        if (!mrvl_restore_fb(i, &pDev->xserver_var[i]))
            continue;
    }

    return TRUE;
}

Bool
mrvl_scn_entervt(int scrnIndex, int flags)
{
    ScrnInfoPtr    pScrn = xf86Screens[scrnIndex];
    MRVLGetPrivateByScrn(pScrn);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Preparing to enter VT\n");

    /* Clear the framebuffer */
    memset(pDev->fbstart + pScrn->fbOffset, 0,
           pScrn->virtualY * pScrn->displayWidth * pScrn->bitsPerPixel / 8);

    if (!xf86SetDesiredModes(pScrn))
	return FALSE;

    /* Save resolution for fb_console */
    mrvlSaveFBScreen(pScrn);

    /* Restore resolution for xserver */
    mrvlRestoreServerScreen(pScrn);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Enter VT successfully\n");

    return TRUE;
}

// 
void
mrvl_scn_leavevt(int scrnIndex, int flags)
{
    int i;
    ScrnInfoPtr    pScrn = xf86Screens[scrnIndex];
    xf86CrtcConfigPtr config = XF86_CRTC_CONFIG_PTR(pScrn);
    MRVLGetPrivateByScrn(pScrn);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Preparing to leave VT\n");

    for (i = 0; i < config->num_crtc; i++) 
    {
	    xf86CrtcPtr crtc = config->crtc[i];

        if (i == 1)
        {
            //mrvl_crtc_dpms(crtc, 3);
        }

#ifndef HAVE_FREE_SHADOW
	    if (crtc->rotatedPixmap || crtc->rotatedData) {
	        crtc->funcs->shadow_destroy(crtc, crtc->rotatedPixmap,
					    crtc->rotatedData);
	        crtc->rotatedPixmap = NULL;
	        crtc->rotatedData = NULL;
	    }
#endif
    }

#ifdef HAVE_FREE_SHADOW
    xf86RotateFreeShadow(pScrn);
#endif

    xf86_hide_cursors (pScrn);

    /* Clear the framebuffer */
    memset(pDev->fbstart + pScrn->fbOffset, 0,
           pScrn->virtualY * pScrn->displayWidth * pScrn->bitsPerPixel / 8);

    /* Save resolution for server */
    mrvlSaveServerScreen(pScrn);

    /* Restore resolution for fb_console */
    mrvlRestoreFBScreen(pScrn);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Leaving now\n");
}

#ifdef XSERVER_LIBPCIACCESS
static Bool FBDevPciProbe(DriverPtr drv, int entity_num,
			  struct pci_device *dev, intptr_t match_data)
{
    ScrnInfoPtr pScrn = NULL;

    if (!xf86LoadDrvSubModule(drv, "fbdevhw"))
	return FALSE;	   

    pScrn = (ScrnInfoPtr)xf86ConfigPciEntity(NULL, 0, entity_num, NULL, NULL,
				NULL, NULL, NULL, NULL);
    if (pScrn) {
	char *device;
	GDevPtr devSection = xf86GetDevFromEntity(pScrn->entityList[0],
						  pScrn->entityInstanceList[0]);

	device = xf86FindOptionValue(devSection->options, "fbdev");
	if (fbdevHWProbe(NULL, device, NULL)) {
	    pScrn->driverVersion = FBDEV_VERSION;
	    pScrn->driverName    = FBDEV_DRIVER_NAME;
	    pScrn->name          = FBDEV_NAME;
	    pScrn->Probe         = FBDevProbe;
	    pScrn->PreInit       = FBDevPreInit;
	    pScrn->ScreenInit    = FBDevScreenInit;
	    pScrn->SwitchMode    = fbdevHWSwitchModeWeak();
	    pScrn->AdjustFrame   = fbdevHWAdjustFrameWeak();
	    pScrn->EnterVT       = fbdevHWEnterVTWeak();
	    pScrn->LeaveVT       = fbdevHWLeaveVTWeak();
	    pScrn->ValidMode     = fbdevHWValidModeWeak();

	    xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
		       "claimed PCI slot %d@%d:%d:%d\n", 
		       dev->bus, dev->domain, dev->dev, dev->func);
	    xf86DrvMsg(pScrn->scrnIndex, X_INFO,
		       "using %s\n", device ? device : "default device");
	}
	else {
	    pScrn = NULL;
	}
    }

    return (pScrn != NULL);
}
#endif


static Bool
FBDevProbe(DriverPtr drv, int flags)
{
	int i;
	ScrnInfoPtr pScrn = NULL;
    GDevPtr *devSections;
	int numDevSections;
	//int bus,device,func;
	char *dev;
	Bool foundScreen = FALSE;

	TRACE("probe start");    

	/* For now, just bail out for PROBE_DETECT. */
	if (flags & PROBE_DETECT)
		return FALSE;

	if ((numDevSections = xf86MatchDevice(FBDEV_DRIVER_NAME, &devSections)) <= 0) 
	    return FALSE;
	
	if (!xf86LoadDrvSubModule(drv, "fbdevhw"))
	    return FALSE;	   
	
	for (i = 0; i < numDevSections; i++) {
#ifndef XSERVER_LIBPCIACCESS
	    Bool isPci = FALSE;
#endif

	    dev = xf86FindOptionValue(devSections[i]->options,"fbdev");
	    if (devSections[i]->busID) {
#ifndef XSERVER_LIBPCIACCESS
	        if (xf86ParsePciBusString(devSections[i]->busID,&bus,&device,
					  &func)) {
		    if (!xf86CheckPciSlot(bus,device,func))
		        continue;
		    isPci = TRUE;
		}
#endif
	    }

	    if (fbdevHWProbe(NULL,dev,NULL)) {
		pScrn = NULL;
#ifndef XSERVER_LIBPCIACCESS
		if (isPci) {
		    /* XXX what about when there's no busID set? */
		    int entity;
		    
		    entity = xf86ClaimPciSlot(bus,device,func,drv,
					      0,devSections[i],
					      TRUE);
		    pScrn = xf86ConfigPciEntity(pScrn,0,entity,
						      NULL,RES_SHARED_VGA,
						      NULL,NULL,NULL,NULL);
		    /* xf86DrvMsg() can't be called without setting these */
		    pScrn->driverName    = FBDEV_DRIVER_NAME;
		    pScrn->name          = FBDEV_NAME;
		    xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
			       "claimed PCI slot %d:%d:%d\n",bus,device,func);

		} else
#endif
		{
		   int entity;

		    entity = xf86ClaimFbSlot(drv, 0,
					      devSections[i], TRUE);
		    pScrn = xf86ConfigFbEntity(pScrn,0,entity,
					       NULL,NULL,NULL,NULL);
		}

		if (pScrn) {
		    foundScreen = TRUE;
		    
		    pScrn->driverVersion = FBDEV_VERSION;
		    pScrn->driverName    = FBDEV_DRIVER_NAME;
		    pScrn->name          = FBDEV_NAME;
		    pScrn->Probe         = FBDevProbe;
		    pScrn->PreInit       = FBDevPreInit;
		    pScrn->ScreenInit    = FBDevScreenInit;
		    pScrn->SwitchMode    = mrvl_scn_switchMode;
		    pScrn->AdjustFrame   = mrvl_scn_adjustFrame;
		    pScrn->EnterVT       = mrvl_scn_entervt;
		    pScrn->LeaveVT       = mrvl_scn_leavevt;
		    pScrn->ValidMode     = mrvl_scn_validMode;
		    
		    xf86DrvMsg(pScrn->scrnIndex, X_INFO,
			       "using %s\n", dev ? dev : "default device");
		}
	    }
	}
	xfree(devSections);
	TRACE("probe done");
#ifdef MRVL_SOURCE_VERSION
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "source version <%s>\n", MRVL_SOURCE_VERSION);
#endif

	return foundScreen;
}

#if MRVL_SUPPORT_RANDR

static Bool
MRVLCRTCResize(ScrnInfoPtr pScrn, int width, int height)
{    
    ScreenPtr   pScreen = pScrn->pScreen;
    MRVLGetPrivate(pScreen);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "MRVLCRTCResize: width %d, height %d display pitch %d, screen width %d, screen height %d, on scr pix: %p, width %d, height %d, pitch %d\n", width, height, pScrn->displayWidth, pScrn->pScreen->width, pScrn->pScreen->height, pScreen->GetScreenPixmap(pScreen), pScreen->GetScreenPixmap(pScreen)->drawable.width, pScreen->GetScreenPixmap(pScreen)->drawable.height, pScreen->GetScreenPixmap(pScreen)->devKind);
        
    pScrn->virtualX = width;
    pScrn->virtualY = height;

    //pScreen->GetScreenPixmap(pScreen)->drawable.width = width;
    //pScreen->GetScreenPixmap(pScreen)->drawable.height = height;

#if MRVL_SUPPORT_EXA
    if (pDev->UseExa)
    {
        mrvlDestroyTempPixmap(pScreen, pDev->exaInfo.alphaPixmap);
        mrvlDestroyTempPixmap(pScreen, pDev->exaInfo.maskPixmap);
        mrvlDestroyTempPixmap(pScreen, pDev->exaInfo.repeatPixmap);

        pDev->exaInfo.alphaPixmap   = mrvlCreateTempPixmap(pScreen, 
                                                     width, 
                                                     height, 
                                                     32);
        pDev->exaInfo.maskPixmap    = mrvlCreateTempPixmap(pScreen, 
                                                     width, 
                                                     height, 
                                                     32);    
        pDev->exaInfo.repeatPixmap  = mrvlCreateTempPixmap(pScreen, 
                                                     width, 
                                                     height, 
                                                     32);
    }
#endif

    return TRUE;
}

static const xf86CrtcConfigFuncsRec MRVLCRTCResizeFuncs = {
    MRVLCRTCResize
};

#endif

static Bool
FBDevPreInit(ScrnInfoPtr pScrn, int flags)
{
    FBDevPtr fPtr;
    int default_depth, fbbpp;
    const char *mod = NULL, *s;
    const char **syms = NULL;
    int type;
    Gamma gamma = {0.0, 0.0, 0.0};
#if MRVL_SUPPORT_RANDR
    xf86CrtcConfigPtr   xf86_config;
    VIVSetDebugMode(VIV_ENABLE_ALL_OUTPUT);
    VIVSetDebugOption(VIV_TRACE);
#endif    
 
    if (flags & PROBE_DETECT) return FALSE;

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Enter into PreInit\n");

    /* Check the number of entities, and fail if it isn't one. */
    if (pScrn->numEntities != 1)
        return FALSE;

    pScrn->monitor = pScrn->confScreen->monitor;

    FBDevGetRec(pScrn);
    fPtr = FBDEVPTR(pScrn);

    fPtr->pEnt = xf86GetEntityInfo(pScrn->entityList[0]);

#ifndef XSERVER_LIBPCIACCESS
    pScrn->racMemFlags = RAC_FB | RAC_COLORMAP | RAC_CURSOR | RAC_VIEWPORT;
    /* XXX Is this right?  Can probably remove RAC_FB */
    pScrn->racIoFlags = RAC_FB | RAC_COLORMAP | RAC_CURSOR | RAC_VIEWPORT;

    if (fPtr->pEnt->location.type == BUS_PCI &&
        xf86RegisterResources(fPtr->pEnt->index,NULL,ResExclusive)) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "xf86RegisterResources() found resource conflicts\n");
	    return FALSE;
    }
#endif

    /* Save fb console's settings. Because fb console 
     * only works with first fb driver, "/dev/fb0", we
     * apply same settings to secondary fb driver */
    MRVLGetPrivateByScrn(pScrn);
    mrvl_save_fb(0, &pDev->fb_console_var[0]);
    mrvl_save_fb(0, &pDev->fb_console_var[1]);

#if MRVL_SUPPORT_RANDR
    xf86CrtcConfigInit(pScrn, &MRVLCRTCResizeFuncs);
    
    xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
#endif    


    /* Added by Green Wan, temporarily fix fb set mode problem. */
    {
        struct fb_var_screeninfo set_var;
        int fb_fd = 0;
        char *dev = 0, *filename = "/dev/fb0";

        dev  = xf86FindOptionValue(fPtr->pEnt->device->options,"fbdev");
        filename = dev ? dev:filename;

        /* set preinit data to fb driver. */
        fb_fd = open(filename, O_RDWR, 0);

        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "ioctl FBIOGET_VSCREENINFO\n");
        if (-1 == ioctl(fb_fd, FBIOGET_VSCREENINFO,(void*)(&set_var))) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "ioctl FBIOGET_VSCREENINFO: %s\n",
                strerror(errno));
            return FALSE;
        }

        /* To get bitsPerPixel and depth from xorg.conf. */
        xf86SetDepthBpp( pScrn, 16, 16, 16,
            Support24bppFb | Support32bppFb | SupportConvert32to24 | SupportConvert24to32 );

        /* initialize fixing data. */
        switch(pScrn->depth) {
        case 32:
        case 24:
            set_var.red.length = 8;
            set_var.green.length = 8;
            set_var.blue.length = 8;
            set_var.red.offset = 16;
            set_var.green.offset = 8;
            set_var.blue.offset = 0;
		
            if (pScrn->bitsPerPixel == 24) {
                set_var.transp.length = 0;
                set_var.transp.offset = 0;
            } else if (pScrn->bitsPerPixel == 32) {
                set_var.transp.length = 8;
                set_var.transp.offset = 24;
            }
            break;
        case 16:
            set_var.red.offset = 11;
            set_var.red.length = 5;
            set_var.green.offset = 5;
            set_var.green.length = 6;
            set_var.blue.offset = 0;
            set_var.blue.length = 5;
            set_var.transp.length = 0;
            set_var.transp.offset = 0;
        default:
            break;
	}

        set_var.bits_per_pixel = pScrn->bitsPerPixel;

        /* put preinit data back to fb driver. */
        if (-1 == ioctl(fb_fd, FBIOPUT_VSCREENINFO,(void*)(&set_var))) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "ioctl FBIOPUT_VSCREENINFO: %s\n",
            strerror(errno));
		return FALSE;
        }

	close(fb_fd);
    }

    /* open device */
    if (!fbdevHWInit(pScrn,NULL,xf86FindOptionValue(fPtr->pEnt->device->options,"fbdev")))
        return FALSE;
	
    default_depth = fbdevHWGetDepth(pScrn,&fbbpp);

    if (!xf86SetDepthBpp(pScrn, default_depth, default_depth, fbbpp,
        Support24bppFb | Support32bppFb | SupportConvert32to24 | SupportConvert24to32))
        return FALSE;

    xf86PrintDepthBpp(pScrn);

    /* Get the depth24 pixmap format */
    if (pScrn->depth == 24 && pix24bpp == 0)
        pix24bpp = xf86GetBppFromDepth(pScrn, 24);
	
    /*
     * Fix me: We found gentoo and debian xorg server has different behavior.
     * Set RGB color length.
     */
    if ((pScrn->depth > 8) && (pScrn->depth <= 24) ) {
        rgb zeros = { 0, 0, 0 };
        if (!xf86SetWeight(pScrn, zeros, zeros))
            return FALSE;
    }
	
    /* visual init */
    if (!xf86SetDefaultVisual(pScrn, -1))
        return FALSE;

    /* We don't currently support DirectColor at > 8bpp */
    if (pScrn->depth > 8 && pScrn->defaultVisual != TrueColor) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "requested default visual"
            " (%s) is not supported at depth %d\n",
            xf86GetVisualName(pScrn->defaultVisual), pScrn->depth);
        return FALSE;
    }

    if (!xf86SetGamma(pScrn, gamma)) {
        return FALSE;
    }

    pScrn->progClock = TRUE;
    pScrn->rgbBits   = 8;
    pScrn->chipset   = "fbdev";
    pScrn->videoRam  = fbdevHWGetVidmem(pScrn);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "hardware: %s (video memory:"
        " %dkB)\n", fbdevHWGetName(pScrn), pScrn->videoRam/1024);

    /* handle options */
    xf86CollectOptions(pScrn, NULL);
    if (!(fPtr->Options = xalloc(sizeof(FBDevOptions))))
        return FALSE;
    memcpy(fPtr->Options, FBDevOptions, sizeof(FBDevOptions));
    xf86ProcessOptions(pScrn->scrnIndex, fPtr->pEnt->device->options, fPtr->Options);

    /* Get video colorkey value */
    if (xf86GetOptValInteger(fPtr->Options, OPTION_VIDEO_KEY, &(fPtr->videoKey))) {
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "video key set to 0x%x\n", fPtr->videoKey);
    } else {
        fPtr->videoKey = 0x01;
    }

    if (xf86GetOptValInteger(fPtr->Options, OPTION_ENC_FUNC, &(enc_func))) {
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "enhance function is mode <%d>\n", enc_func);
    } else {
        enc_func = 0x0;
    }

    fPtr->HWcursor = xf86ReturnOptValBool(fPtr->Options, OPTION_HW_CURSOR, FALSE);

    /* use shadow framebuffer by default */
    // added by stephen kou to force to disale shadowFB.
    fPtr->shadowFB = xf86ReturnOptValBool(fPtr->Options, OPTION_SHADOW_FB, FALSE);

    if (fPtr->shadowFB) {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "shadow fb is enabled\n");
    } else {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "shadow fb is disabled\n");
    }

    // For debug only.
    fPtr->UseCopy = xf86ReturnOptValBool(fPtr->Options, OPTION_COPY_ACCEL, TRUE);
    fPtr->UseSolid = xf86ReturnOptValBool(fPtr->Options, OPTION_SOLID_ACCEL, TRUE);
    fPtr->UseComposite = xf86ReturnOptValBool(fPtr->Options, OPTION_COMP_ACCEL, TRUE);
    fPtr->UseCommitStall = xf86ReturnOptValBool(fPtr->Options, OPTION_COMMIT, FALSE);
    fPtr->UseSoftwareSolid = xf86ReturnOptValBool(fPtr->Options, OPTION_SW_SOLID, FALSE);
    fPtr->UseSoftwareCopy = xf86ReturnOptValBool(fPtr->Options, OPTION_SW_COPY, FALSE);
#if MRVL_XV_TEX_VIDEO == 1
    fPtr->UseGPU = xf86ReturnOptValBool(fPtr->Options, OPTION_USE_GPU, TRUE);
#else
    fPtr->UseGPU = xf86ReturnOptValBool(fPtr->Options, OPTION_USE_GPU, FALSE);
#endif

    fPtr->UseDriverBuiltInMode = xf86ReturnOptValBool(fPtr->Options, OPTION_USE_DRIVER_MODE, TRUE);
    fPtr->EnableDualDisplay = xf86ReturnOptValBool(fPtr->Options, OPTION_DUAL_DISPLAY, TRUE);
#ifdef RENDER
    fPtr->RenderAccel = xf86ReturnOptValBool(fPtr->Options, OPTION_RENDER_ACCEL, TRUE);
#endif

    debug_opt = debug = xf86ReturnOptValBool(fPtr->Options, OPTION_DEBUG, FALSE);

    if (debug_opt)
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "debug is enabled.\n");
    else
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "debug is disabled.\n");
    /* rotation */
    fPtr->rotate = FBDEV_ROTATE_NONE;
    if ((s = xf86GetOptValString(fPtr->Options, OPTION_ROTATE))) {
        if(!xf86NameCmp(s, "CW")) {
	    fPtr->shadowFB = TRUE;
	    fPtr->rotate = FBDEV_ROTATE_CW;
	    xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
		       "rotating screen clockwise\n");
        } else if(!xf86NameCmp(s, "CCW")) {
            fPtr->shadowFB = TRUE;
            fPtr->rotate = FBDEV_ROTATE_CCW;
            xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
            "rotating screen counter-clockwise\n");
        } else if(!xf86NameCmp(s, "UD")) {
            fPtr->shadowFB = TRUE;
            fPtr->rotate = FBDEV_ROTATE_UD;
            xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
                "rotating screen upside-down\n");
        } else {
            xf86DrvMsg(pScrn->scrnIndex, X_CONFIG,
                "\"%s\" is not a valid value for Option \"Rotate\"\n", s);
                xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                "valid options are \"CW\", \"CCW\" and \"UD\"\n");
        }
    }

    /* select video modes */
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "checking modes against framebuffer device...\n");
    fbdevHWSetVideoModes(pScrn);
	
    /* FIXME: workaround non-xorg.conf issue */
    if(pScrn->virtualX == 0 || pScrn->virtualY == 0)
        pScrn->virtualX = pScrn->virtualY = 2048;

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "checking modes against monitor...\n");
    {
        DisplayModePtr mode, first = mode = pScrn->modes;
		
        if (mode != NULL)
            do {
                mode->status = xf86CheckModeForMonitor(mode, pScrn->monitor);
                mode = mode->next;
            } while (mode != NULL && mode != first);

        xf86PruneDriverModes(pScrn);
    }

    pScrn->currentMode = pScrn->modes;

    /* First approximation, may be refined in ScreenInit */
    pScrn->displayWidth = pScrn->virtualX;

    xf86PrintModes(pScrn);
#if MRVL_SUPPORT_RANDR      
    
    if (!mrvlCrtcInit(pScrn))
    {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Crtc initialization failure.\n");
        return FALSE;
    }

    if (!mrvlOutputInit(pScrn))
    {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Output initialization failure.\n");
        return FALSE;
    }
    {
        int i;
        xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
        for (i = 0; i < xf86_config->num_output; i++) {
            xf86OutputPtr output = xf86_config->output[i];
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "*** output <%s>, x=%d, y=%d\n",
                output->name, (output->crtc != NULL) ? output->crtc->x : -1,
                (output->crtc != NULL) ? output->crtc->y : -1);
        }
    }

    /* If xorg.conf doesn't exist, we need to tell Xorg the range of default virtual resolution.
       Otherwise, xf86InitialConfiguration can't probe valid modes. */
    xf86CrtcSetSizeRange(pScrn, 300, 200, pScrn->virtualX, pScrn->virtualY);

    if (!xf86InitialConfiguration (pScrn, FALSE))
    {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "No valid modes.\n");
        return FALSE;
    }


    //unmark it for debugging.
    //{
    //    int i;
    //    xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
    //    for (i = 0; i < xf86_config->num_output; i++) {
    //        xf86OutputPtr output = xf86_config->output[i];
    //        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "*** After init, output <%s>, x=%d, y=%d\n",
    //            output->name, output->crtc ? output->crtc->x : -1,
    //            output->crtc ? output->crtc->y : -1);
    //    }
    //}

    if (!xf86RandR12PreInit(pScrn))
    {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "RandR initialization failure\n");
        return FALSE;
    }

    //unmark it for debugging.
    //{
    //    int i;
    //    xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
    //    for (i = 0; i < xf86_config->num_output; i++) {
    //        xf86OutputPtr output = xf86_config->output[i];
    //        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "*** after xrandr init, output <%s>, x=%d, y=%d\n",
    //            output->name, output->crtc ? output->crtc->x : -1,
    //            output->crtc ? output->crtc->y : -1);
    //    }
    //}

    if (pScrn->modes == NULL)
    {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "No modes.\n");
        return FALSE;
    }

    fPtr->rotation = RR_Rotate_0;

#endif   

    /* Set display resolution */
    xf86SetDpi(pScrn, 0, 0);

    /* Load bpp-specific modules */
    switch ((type = fbdevHWGetType(pScrn))) {
    case FBDEVHW_PLANES:
        mod = "afb";
        syms = afbSymbols;
        break;
    case FBDEVHW_PACKED_PIXELS:
        switch (pScrn->bitsPerPixel) {
        case 8:
        case 16:
        case 24:
        case 32:
            mod = "fb";
            syms = fbSymbols;
            break;
        default:
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "unsupported number of bits per pixel: %d",
                pScrn->bitsPerPixel);
            return FALSE;
        }
        break;
    case FBDEVHW_INTERLEAVED_PLANES:
        /* Not supported yet, don't know what to do with this */
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "interleaved planes are not yet supported by the "
            "fbdev driver\n");
        return FALSE;
    case FBDEVHW_TEXT:
        /* This should never happen ...
         * we should check for this much much earlier ...
         */
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "text mode is not supported by the fbdev driver\n");
        return FALSE;
    case FBDEVHW_VGA_PLANES:
        /* Not supported yet */
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "EGA/VGA planes are not yet supported by the fbdev "
            "driver\n");
        return FALSE;
    default:
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "unrecognised fbdev hardware type (%d)\n", type);
        return FALSE;
    }

    if (mod && xf86LoadSubModule(pScrn, mod) == NULL) {
        FBDevFreeRec(pScrn);
        return FALSE;
    }

    /* Load shadow if needed */
    if (fPtr->shadowFB) {
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "using shadow"
            " framebuffer\n");
        if (!xf86LoadSubModule(pScrn, "shadow")) {
            FBDevFreeRec(pScrn);
            return FALSE;
        }
    }

    // Parse options for EXA and XV	
    fPtr->UseXv  = xf86ReturnOptValBool(fPtr->Options, OPTION_XV_ACCEL, TRUE);

#if MRVL_SUPPORT_EXA	
    fPtr->UseExa = xf86ReturnOptValBool(fPtr->Options, OPTION_EXA_ACCEL, FALSE);
    /* Load EXA acceleration if needed */
    if (fPtr->UseExa) {  
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Loading exa Symbols\n");

        if (!xf86LoadSubModule(pScrn, "exa")) {
            FBDevFreeRec(pScrn);
            return FALSE;
        }
    }
#endif

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Leave PreInit \n");
    return TRUE;
}

static Bool
FBDevCreateScreenResources(ScreenPtr pScreen)
{
    PixmapPtr pPixmap;
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    FBDevPtr fPtr = FBDEVPTR(pScrn);
    Bool ret;

    pScreen->CreateScreenResources = fPtr->CreateScreenResources;
    ret = pScreen->CreateScreenResources(pScreen);
    pScreen->CreateScreenResources = FBDevCreateScreenResources;

    if (!ret)
	return FALSE;

    pPixmap = pScreen->GetScreenPixmap(pScreen);

    /*xf86DrvMsg(pScrn->scrnIndex, X_INFO, "MRVLCreateScreenResources: pixmap[%p], width: %d, height %d, virtual X %d, virtual Y %d\n", 
                pPixmap, 
                pPixmap->drawable.width, 
                pPixmap->drawable.height, 
                pScrn->virtualX, 
                pScrn->virtualY);*/

    if (fPtr->shadowFB)
    {
        if (!shadowAdd(pScreen, pPixmap, fPtr->rotate ?
		       shadowUpdateRotatePackedWeak() : shadowUpdatePackedWeak(),
		       FBDevWindowLinear, fPtr->rotate, NULL)) 
        {
	        return FALSE;
        }
    }

    return TRUE;
}

static Bool
FBDevShadowInit(ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    FBDevPtr fPtr = FBDEVPTR(pScrn);
    
    if (!shadowSetup(pScreen)) {
	    return FALSE;
    }

    fPtr->CreateScreenResources = pScreen->CreateScreenResources;
    pScreen->CreateScreenResources = FBDevCreateScreenResources;

    return TRUE;
}


static Bool
FBDevScreenInit(int scrnIndex, ScreenPtr pScreen, int argc, char **argv)
{
	ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
	FBDevPtr    fPtr = FBDEVPTR(pScrn);
	VisualPtr   visual;
	int         init_picture = 0;
	int         ret, flags;
	int         type;
#ifdef RENDER
    int         subPixelOrder = SubPixelHorizontalRGB;
    char *      s;
#endif
#if MRVL_USE_OFFSCREEN_HEAP
    xf86CrtcConfigPtr xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
#endif

	xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Enter into FBDevScreenInit\n");

#if DEBUG
	ErrorF("\tbitsPerPixel=%d, depth=%d, defaultVisual=%s\n"
	       "\tmask: %x,%x,%x, offset: %d,%d,%d\n",
	       pScrn->bitsPerPixel,
	       pScrn->depth,
	       xf86GetVisualName(pScrn->defaultVisual),
	       pScrn->mask.red,pScrn->mask.green,pScrn->mask.blue,
	       pScrn->offset.red,pScrn->offset.green,pScrn->offset.blue);
#endif

	if (NULL == (fPtr->fbmem = fbdevHWMapVidmem(pScrn))) {
	        xf86DrvMsg(scrnIndex,X_ERROR,"mapping of video memory"
			   " failed\n");
		return FALSE;
	}
	
	fPtr->fboff = fbdevHWLinearOffset(pScrn);
	fPtr->memPhysBase = (unsigned long)pScrn->memPhysBase;
	
	fbdevHWSave(pScrn);

	if (!fbdevHWModeInit(pScrn, pScrn->currentMode)) {
		xf86DrvMsg(scrnIndex,X_ERROR,"mode initialization failed\n");
		return FALSE;
	}
	fbdevHWSaveScreen(pScreen, SCREEN_SAVER_ON);
	fbdevHWAdjustFrame(scrnIndex,0,0,0);

	/* mi layer */
	miClearVisualTypes();
	if (pScrn->bitsPerPixel > 8) {
		if (!miSetVisualTypes(pScrn->depth, TrueColorMask, pScrn->rgbBits, TrueColor)) {
			xf86DrvMsg(scrnIndex,X_ERROR,"visual type setup failed"
				   " for %d bits per pixel [1]\n",
				   pScrn->bitsPerPixel);
			return FALSE;
		}
	} else {
		if (!miSetVisualTypes(pScrn->depth,
				      miGetDefaultVisualMask(pScrn->depth),
				      pScrn->rgbBits, pScrn->defaultVisual)) {
			xf86DrvMsg(scrnIndex,X_ERROR,"visual type setup failed"
				   " for %d bits per pixel [2]\n",
				   pScrn->bitsPerPixel);
			return FALSE;
		}
	}
	if (!miSetPixmapDepths()) {
	  xf86DrvMsg(scrnIndex,X_ERROR,"pixmap depth setup failed\n");
	  return FALSE;
	}

	if(fPtr->rotate==FBDEV_ROTATE_CW || fPtr->rotate==FBDEV_ROTATE_CCW)
	{
	  int tmp = pScrn->virtualX;
	  pScrn->virtualX = pScrn->displayWidth = pScrn->virtualY;
	  pScrn->virtualY = tmp;
	} else if (!fPtr->shadowFB) {
		/* FIXME: this doesn't work for all cases, e.g. when each scanline
			has a padding which is independent from the depth (controlfb) */
		pScrn->displayWidth = fbdevHWGetLineLength(pScrn) /
				      (pScrn->bitsPerPixel / 8);

		if (pScrn->displayWidth != pScrn->virtualX) {
			xf86DrvMsg(scrnIndex, X_INFO,
				   "Pitch updated to %d after ModeInit\n",
				   pScrn->displayWidth);
		}
	}

	if(fPtr->rotate && !fPtr->PointerMoved) {
		fPtr->PointerMoved = pScrn->PointerMoved;
		pScrn->PointerMoved = FBDevPointerMoved;
	}

	fPtr->fbstart = fPtr->fbmem + fPtr->fboff;
	
	xf86DrvMsg(pScrn->scrnIndex, X_INFO,
			   "frame buffer linear address: %p, physical address : %lX\n", fPtr->fbstart, fPtr->memPhysBase);

	if (fPtr->shadowFB) {
	    fPtr->shadow = xcalloc(1, pScrn->virtualX * pScrn->virtualY *
				   pScrn->bitsPerPixel);

	    if (!fPtr->shadow) {
		xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
			   "Failed to allocate shadow framebuffer\n");
		return FALSE;
	    }
	}

	switch ((type = fbdevHWGetType(pScrn)))
	{
#ifdef USE_AFB
	case FBDEVHW_PLANES:
		if (fPtr->rotate)
		{
		  xf86DrvMsg(scrnIndex, X_ERROR,
			     "internal error: rotate not supported for afb\n");
		  ret = FALSE;
		  break;
		}
		if (fPtr->shadowFB)
		{
		  xf86DrvMsg(scrnIndex, X_ERROR,
			     "internal error: shadow framebuffer not supported"
			     " for afb\n");
		  ret = FALSE;
		  break;
		}
		ret = afbScreenInit
			(pScreen, fPtr->fbstart, pScrn->virtualX, pScrn->virtualY,
			 pScrn->xDpi, pScrn->yDpi, pScrn->displayWidth);
		break;
#endif
	case FBDEVHW_PACKED_PIXELS:
		switch (pScrn->bitsPerPixel) {
		case 8:
		case 16:
		case 24:
		case 32:
			ret = fbScreenInit(pScreen, fPtr->shadowFB ? fPtr->shadow
					   : fPtr->fbstart, pScrn->virtualX,
					   pScrn->virtualY, pScrn->xDpi,
					   pScrn->yDpi, pScrn->displayWidth,
					   pScrn->bitsPerPixel);
			init_picture = 1;
			break;
	 	default:
			xf86DrvMsg(scrnIndex, X_ERROR,
				   "internal error: invalid number of bits per"
				   " pixel (%d) encountered in"
				   " FBDevScreenInit()\n", pScrn->bitsPerPixel);
			ret = FALSE;
			break;
		}
		break;
	case FBDEVHW_INTERLEAVED_PLANES:
		/* This should never happen ...
		* we should check for this much much earlier ... */
		xf86DrvMsg(scrnIndex, X_ERROR,
		           "internal error: interleaved planes are not yet "
			   "supported by the fbdev driver\n");
		ret = FALSE;
		break;
	case FBDEVHW_TEXT:
		/* This should never happen ...
		* we should check for this much much earlier ... */
		xf86DrvMsg(scrnIndex, X_ERROR,
		           "internal error: text mode is not supported by the "
			   "fbdev driver\n");
		ret = FALSE;
		break;
	case FBDEVHW_VGA_PLANES:
		/* Not supported yet */
		xf86DrvMsg(scrnIndex, X_ERROR,
		           "internal error: EGA/VGA Planes are not yet "
			   "supported by the fbdev driver\n");
		ret = FALSE;
		break;
	default:
		xf86DrvMsg(scrnIndex, X_ERROR,
		           "internal error: unrecognised hardware type (%d) "
			   "encountered in FBDevScreenInit()\n", type);
		ret = FALSE;
		break;
	}
	if (!ret)
		return FALSE;

	if (pScrn->bitsPerPixel > 8) {
		/* Fixup RGB ordering */
		visual = pScreen->visuals + pScreen->numVisuals;
		while (--visual >= pScreen->visuals) {
			if ((visual->class | DynamicClass) == DirectColor) {
				visual->offsetRed   = pScrn->offset.red;
				visual->offsetGreen = pScrn->offset.green;
				visual->offsetBlue  = pScrn->offset.blue;
				visual->redMask     = pScrn->mask.red;
				visual->greenMask   = pScrn->mask.green;
				visual->blueMask    = pScrn->mask.blue;
			}
		}
	}

	/* must be after RGB ordering fixed */
	if (init_picture && !fbPictureInit(pScreen, NULL, 0))
    {
		xf86DrvMsg(pScrn->scrnIndex, X_WARNING,
			   "Render extension initialisation failed\n");
    }
    else
    {
        xf86DrvMsg(pScrn->scrnIndex, X_WARNING,
			   "Render extension initialisation successful\n");
    }

#ifdef RENDER
    if ((s = xf86GetOptValString(fPtr->Options, OPTION_SUBPIXEL_ORDER))) 
    {
	    if (strcmp(s, "RGB") == 0) subPixelOrder = SubPixelHorizontalRGB;
	    else if (strcmp(s, "BGR") == 0) subPixelOrder = SubPixelHorizontalBGR;
	    else if (strcmp(s, "NONE") == 0) subPixelOrder = SubPixelNone;	  

        xf86DrvMsg(pScrn->scrnIndex, X_INFO,
			   "Render extension subpixel order is %s\n", s);  
    }
    else
    {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO,
			   "Render extension subpixel order is RGB\n");
    }

    PictureSetSubpixelOrder (pScreen, subPixelOrder);
    
#endif

    pScrn->vtSema = TRUE;

	if (fPtr->shadowFB && !FBDevShadowInit(pScreen)) {
	    xf86DrvMsg(scrnIndex, X_ERROR,
		       "shadow framebuffer initialization failed\n");
	    return FALSE;
	}

	if (!fPtr->rotate)
	  FBDevDGAInit(pScrn, pScreen);
	else {
	  xf86DrvMsg(scrnIndex, X_INFO, "display rotated; disabling DGA\n");
	  xf86DrvMsg(scrnIndex, X_INFO, "using driver rotation; disabling "
			                "XRandR\n");
	  xf86DisableRandR();
	  if (pScrn->bitsPerPixel == 24)
	    xf86DrvMsg(scrnIndex, X_WARNING, "rotation might be broken at 24 "
                                             "bits per pixel\n");
	}

	xf86SetBlackWhitePixels(pScreen);
	miInitializeBackingStore(pScreen);
	xf86SetBackingStore(pScreen);

	/* software cursor */
	miDCInitialize(pScreen, xf86GetPointerScreenFuncs());

	/* colormap */
	switch ((type = fbdevHWGetType(pScrn)))
	{
	/* XXX It would be simpler to use miCreateDefColormap() in all cases. */
#ifdef USE_AFB
	case FBDEVHW_PLANES:
		if (!afbCreateDefColormap(pScreen)) {
			xf86DrvMsg(scrnIndex, X_ERROR,
                                   "internal error: afbCreateDefColormap "
				   "failed in FBDevScreenInit()\n");
			return FALSE;
		}
		break;
#endif
	case FBDEVHW_PACKED_PIXELS:
		if (!miCreateDefColormap(pScreen)) {
			xf86DrvMsg(scrnIndex, X_ERROR,
                                   "internal error: miCreateDefColormap failed "
				   "in FBDevScreenInit()\n");
			return FALSE;
		}
		break;
	case FBDEVHW_INTERLEAVED_PLANES:
		xf86DrvMsg(scrnIndex, X_ERROR,
		           "internal error: interleaved planes are not yet "
			   "supported by the fbdev driver\n");
		return FALSE;
	case FBDEVHW_TEXT:
		xf86DrvMsg(scrnIndex, X_ERROR,
		           "internal error: text mode is not supported by "
			   "the fbdev driver\n");
		return FALSE;
	case FBDEVHW_VGA_PLANES:
		xf86DrvMsg(scrnIndex, X_ERROR,
		           "internal error: EGA/VGA planes are not yet "
			   "supported by the fbdev driver\n");
		return FALSE;
	default:
		xf86DrvMsg(scrnIndex, X_ERROR,
		           "internal error: unrecognised fbdev hardware type "
			   "(%d) encountered in FBDevScreenInit()\n", type);
		return FALSE;
	}
	flags = CMAP_PALETTED_TRUECOLOR;

	if(!xf86HandleColormaps(pScreen, 256, 8, fbdevHWLoadPaletteWeak(), 
				NULL, flags))
		return FALSE;

	xf86DPMSInit(pScreen, fbdevHWDPMSSetWeak(), 0);

	pScreen->SaveScreen = fbdevHWSaveScreenWeak();

	/* Wrap the current CloseScreen function */
	fPtr->CloseScreen = pScreen->CloseScreen;
	pScreen->CloseScreen = FBDevCloseScreen;

#if MRVL_SUPPORT_EXA		
    if (fPtr->UseExa)
    {
        xf86DrvMsg(scrnIndex, X_INFO,
		           "Start to initialize vivnate hal module\n");
        fPtr->UseGPU = TRUE;
    }

#if MRVL_XV_TEX_VIDEO == 1
    fPtr->UseGPU = TRUE;
#endif
		       
    if (fPtr->UseGPU)  
    {  
	    // Set up hal layer for Exa and Xv.
        if( ! mrvlExaInitHal(pScreen) )
        {       
            xf86DrvMsg(scrnIndex, X_ERROR,
		               "Failed to initialize vivnate hal module\n");
            return FALSE;
        }
        xf86DrvMsg(scrnIndex, X_INFO,
		           "Initialize vivnate hal module successfully\n");
    }  
#endif

#if MRVL_USE_OFFSCREEN_HEAP

    unsigned long secureSize = pScrn->virtualY * pScrn->displayWidth * pScrn->bitsPerPixel * (xf86_config->num_crtc + 1) / 8;
    // Initialize memory heap for Exa and Xv
    OsMemHeapInitialize(&fPtr->offscreenMemHeap, 
                        (unsigned long)(fPtr->fbstart + secureSize),
                        (unsigned int)fPtr->memPhysBase + secureSize,
                        pScrn->videoRam - secureSize);

    if (pScrn->videoRam - secureSize <= 0 )
    {
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "Warning: Please check LCD offscreen memory space\n");                        
    }
    else
    {
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "Use our own offscreen memory heap, secure size %lX, video size %X, heap size %lX\n", secureSize, pScrn->videoRam, pScrn->videoRam - secureSize); 
    }
#endif

#if MRVL_SUPPORT_EXA
    fPtr->exaMode = MRVL_EXA_MODE;

    // EXA interface initialization.
    if (fPtr->UseExa) 
    {                
        if ( !mrvlExaInit(pScreen) )
            return FALSE;
            
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "EXA is load successfully \n");            
    }
    else
#endif
    {
        xf86DrvMsg(pScrn->scrnIndex, X_CONFIG, "EXA is disabled \n");  
    }  

    // Xv interface initialization.
    if (fPtr->UseXv)
	{
	    XF86VideoAdaptorPtr *ptr;

	    int n = xf86XVListGenericAdaptors(pScrn,&ptr);
	    if (n) {
		    xf86XVScreenInit(pScreen,ptr,n);
	    }
	
    	/* ------------< Added by Green >------------ */
    	/* Initialize Xv support. */
    	DovefbXVInitVideo (pScreen);
    	
    	xf86DrvMsg(scrnIndex, X_INFO, "Xv acceleration is loaded successfully\n");
    }
    else
    {
        xf86DrvMsg(scrnIndex, X_INFO, "Xv acceleration is disabled\n");
    }

	/* Initialize hw cursor. */	
	if (xf86ReturnOptValBool(fPtr->Options, OPTION_HW_CURSOR, FALSE)) {
		if (FALSE == DovefbCursorInit(pScreen)) {
    			xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Can not initialize h/w cursor\n");
			return FALSE;
		}
	  	xf86DrvMsg(scrnIndex, X_INFO, "HW cursor init okay.\n");
	}		
	
	/* ----------------------------------------- */
#if MRVL_SUPPORT_RANDR    
    // set the modes with desired rotation , etc.
    fprintf(stderr, "xf86SetDesiredModes()\n");
    if (!xf86SetDesiredModes(pScrn))
    {
        fprintf(stderr, "Fail to set desired modes\n");
        return FALSE;
    }
    
    if (!xf86CrtcScreenInit(pScreen))
    {
        fprintf(stderr, "Fail to initialize crtc\n");
        return FALSE;
    }

    //pScrn->modes = xf86CVTMode(1024, 768, 60.0, FALSE, FALSE);
#endif      

   xf86DrvMsg(scrnIndex, X_INFO, "Leave FBDevScreenInit().\n");

	return TRUE;
}

static Bool
FBDevCloseScreen(int scrnIndex, ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[scrnIndex];
    FBDevPtr fPtr = FBDEVPTR(pScrn);
	
    xf86DrvMsg(scrnIndex, X_INFO, "FBDevCloseScreen.\n");
    fbdevHWRestore(pScrn);
    fbdevHWUnmapVidmem(pScrn);
    if (fPtr->shadow) {
        xfree(fPtr->shadow);
        fPtr->shadow = NULL;
    }

    if (fPtr->pDGAMode) {
        xfree(fPtr->pDGAMode);
        fPtr->pDGAMode = NULL;
        fPtr->nDGAMode = 0;
    }

    pScrn->vtSema = FALSE;

#if MRVL_USE_OFFSCREEN_HEAP
    // Destroy memory heap
    OsMemHeapDestroy(&fPtr->offscreenMemHeap);
#endif

    if ( fPtr->bCreateXVFilterSurf) {
        DovefbDestroyFilterSurface(pScreen);
    }

#if MRVL_XV_USE_FAKE_FENCE_STALL
    if (fPtr->UseXv && (fPtr->pXVScreenFence != NULL))
    {
        // Need to wait GPU ready.
        mrvlFencePoolStall(fPtr->pXVScreenFence);
        mrvlFencePoolFree(&fPtr->exaInfo.fakeFencePool, fPtr->pXVScreenFence);
        mrvlFencePoolDeinit(fPtr->exaInfo.Hal, &fPtr->exaInfo.fakeFencePool);
        
        fPtr->bXvResourceInitialized = FALSE;
    }
#endif

#if MRVL_SUPPORT_EXA
    if (fPtr->UseExa) {
        mrvlExaShutdown(pScreen);
    }
    
    // Destory hal layer for access to vivante library
    if (fPtr->UseGPU) {
        mrvlExaShutdownHal(pScreen);
    }
#endif

    if (fPtr->shadowFB) {
        pScreen->CreateScreenResources = fPtr->CreateScreenResources;
    }

    pScreen->CloseScreen = fPtr->CloseScreen;

    /* Restore resolution for fb console */
    mrvlRestoreFBScreen(pScrn);

    return (*pScreen->CloseScreen)(scrnIndex, pScreen);
}



/***********************************************************************
 * Shadow stuff
 ***********************************************************************/

static void *
FBDevWindowLinear(ScreenPtr pScreen, CARD32 row, CARD32 offset, int mode,
    CARD32 *size, void *closure)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    FBDevPtr fPtr = FBDEVPTR(pScrn);

    if (!pScrn->vtSema)
      return NULL;

    if (fPtr->lineLength)
      *size = fPtr->lineLength;
    else
      *size = fPtr->lineLength = fbdevHWGetLineLength(pScrn);

    return ((CARD8 *)fPtr->fbstart + row * fPtr->lineLength + offset);
}

static void
FBDevPointerMoved(int index, int x, int y)
{
    ScrnInfoPtr pScrn = xf86Screens[index];
    FBDevPtr fPtr = FBDEVPTR(pScrn);
    int newX, newY;

    switch (fPtr->rotate)
    {
    case FBDEV_ROTATE_CW:
	/* 90 degrees CW rotation. */
	newX = pScrn->pScreen->height - y - 1;
	newY = x;
	break;

    case FBDEV_ROTATE_CCW:
	/* 90 degrees CCW rotation. */
	newX = y;
	newY = pScrn->pScreen->width - x - 1;
	break;

    case FBDEV_ROTATE_UD:
	/* 180 degrees UD rotation. */
	newX = pScrn->pScreen->width - x - 1;
	newY = pScrn->pScreen->height - y - 1;
	break;

    default:
	/* No rotation. */
	newX = x;
	newY = y;
	break;
    }

    /* Pass adjusted pointer coordinates to wrapped PointerMoved function. */
    (*fPtr->PointerMoved)(index, newX, newY);
}


/***********************************************************************
 * DGA stuff
 ***********************************************************************/
static Bool FBDevDGAOpenFramebuffer(ScrnInfoPtr pScrn, char **DeviceName,
				   unsigned char **ApertureBase,
				   int *ApertureSize, int *ApertureOffset,
				   int *flags);
static Bool FBDevDGASetMode(ScrnInfoPtr pScrn, DGAModePtr pDGAMode);
static void FBDevDGASetViewport(ScrnInfoPtr pScrn, int x, int y, int flags);

static Bool
FBDevDGAOpenFramebuffer(ScrnInfoPtr pScrn, char **DeviceName,
		       unsigned char **ApertureBase, int *ApertureSize,
		       int *ApertureOffset, int *flags)
{
    *DeviceName = NULL;		/* No special device */
    *ApertureBase = (unsigned char *)(pScrn->memPhysBase);
    *ApertureSize = pScrn->videoRam;
    *ApertureOffset = pScrn->fbOffset;
    *flags = 0;

    return TRUE;
}

static Bool
FBDevDGASetMode(ScrnInfoPtr pScrn, DGAModePtr pDGAMode)
{
    DisplayModePtr pMode;
    int scrnIdx = pScrn->pScreen->myNum;
    int frameX0, frameY0;

    if (pDGAMode) {
	pMode = pDGAMode->mode;
	frameX0 = frameY0 = 0;
    }
    else {
	if (!(pMode = pScrn->currentMode))
	    return TRUE;

	frameX0 = pScrn->frameX0;
	frameY0 = pScrn->frameY0;
    }

    if (!(*pScrn->SwitchMode)(scrnIdx, pMode, 0))
	return FALSE;
    (*pScrn->AdjustFrame)(scrnIdx, frameX0, frameY0, 0);

    return TRUE;
}

static void
FBDevDGASetViewport(ScrnInfoPtr pScrn, int x, int y, int flags)
{
    (*pScrn->AdjustFrame)(pScrn->pScreen->myNum, x, y, flags);
}

static int
FBDevDGAGetViewport(ScrnInfoPtr pScrn)
{
    return (0);
}

static DGAFunctionRec FBDevDGAFunctions =
{
    FBDevDGAOpenFramebuffer,
    NULL,       /* CloseFramebuffer */
    FBDevDGASetMode,
    FBDevDGASetViewport,
    FBDevDGAGetViewport,
    NULL,       /* Sync */
    NULL,       /* FillRect */
    NULL,       /* BlitRect */
    NULL,       /* BlitTransRect */
};

static void
FBDevDGAAddModes(ScrnInfoPtr pScrn)
{
    FBDevPtr fPtr = FBDEVPTR(pScrn);
    DisplayModePtr pMode = pScrn->modes;
    DGAModePtr pDGAMode;

    do {
	pDGAMode = xrealloc(fPtr->pDGAMode,
			    (fPtr->nDGAMode + 1) * sizeof(DGAModeRec));
	if (!pDGAMode)
	    break;

	fPtr->pDGAMode = pDGAMode;
	pDGAMode += fPtr->nDGAMode;
	(void)memset(pDGAMode, 0, sizeof(DGAModeRec));

	++fPtr->nDGAMode;
	pDGAMode->mode = pMode;
	pDGAMode->flags = DGA_CONCURRENT_ACCESS | DGA_PIXMAP_AVAILABLE;
	pDGAMode->byteOrder = pScrn->imageByteOrder;
	pDGAMode->depth = pScrn->depth;
	pDGAMode->bitsPerPixel = pScrn->bitsPerPixel;
	pDGAMode->red_mask = pScrn->mask.red;
	pDGAMode->green_mask = pScrn->mask.green;
	pDGAMode->blue_mask = pScrn->mask.blue;
	pDGAMode->visualClass = pScrn->bitsPerPixel > 8 ?
	    TrueColor : PseudoColor;
	pDGAMode->xViewportStep = 1;
	pDGAMode->yViewportStep = 1;
	pDGAMode->viewportWidth = pMode->HDisplay;
	pDGAMode->viewportHeight = pMode->VDisplay;

	if (fPtr->lineLength)
	  pDGAMode->bytesPerScanline = fPtr->lineLength;
	else
	  pDGAMode->bytesPerScanline = fPtr->lineLength = fbdevHWGetLineLength(pScrn);

	pDGAMode->imageWidth = pMode->HDisplay;
	pDGAMode->imageHeight =  pMode->VDisplay;
	pDGAMode->pixmapWidth = pDGAMode->imageWidth;
	pDGAMode->pixmapHeight = pDGAMode->imageHeight;
	pDGAMode->maxViewportX = pScrn->virtualX -
				    pDGAMode->viewportWidth;
	pDGAMode->maxViewportY = pScrn->virtualY -
				    pDGAMode->viewportHeight;

	pDGAMode->address = fPtr->fbstart;

	pMode = pMode->next;
    } while (pMode != pScrn->modes);
}

static Bool
FBDevDGAInit(ScrnInfoPtr pScrn, ScreenPtr pScreen)
{
    FBDevPtr fPtr = FBDEVPTR(pScrn);

    if (pScrn->depth < 8)
	return FALSE;

    if (!fPtr->nDGAMode)
	FBDevDGAAddModes(pScrn);

    return (DGAInit(pScreen, &FBDevDGAFunctions,
	    fPtr->pDGAMode, fPtr->nDGAMode));
}

static Bool
FBDevDriverFunc(ScrnInfoPtr pScrn, xorgDriverFuncOp op, pointer ptr)
{
    xorgHWFlags *flag;
    
    switch (op) {
	case GET_REQUIRED_HW_INTERFACES:
	    flag = (CARD32*)ptr;
	    (*flag) = 0;
	    return TRUE;
	default:
	    return FALSE;
    }
}
