#ifndef __MRVL_UTILS_H__
#define __MRVL_UTILS_H__

#define TRACE_REPEAT    0

#pragma pack (1)
typedef struct __X8B8G8R8_FMT
{
    unsigned int    r : 8;
    unsigned int    g : 8;
    unsigned int    b : 8;
    unsigned int    x : 8;
}
X8B8G8R8_FMT, *PX8B8G8R8_FMT;
#pragma pack()

Bool    mrvlAlphaBlendBlt(int op, 
                        gco2D Engine2D, 
                        gcoSURF srcSurf, 
                        gcoSURF dstSurf, 
                        gcoSURF alphaSurf,
                        gcoSURF maskSurf,
                        gcsRECT *srcRect, 
                        gcsRECT *dstRect,
                        Bool    bDstMask
                        );
BlendOp *mrvlGetBlendOperation();
int     mrvlGetBlendOperationSize();
Bool    mrvlGeneralRepeatBlt(int repeatMode,
                    gco2D Engine2D, 
                    int srcWidth, 
                    int srcHeight, 
                    gcoSURF srcSurf, 
                    gcoSURF dstSurf, 
                    gcsRECT *dstRect);
void    mrvlWrapRBChannel(gcoSURF pSurface, unsigned int *pAddress);
void    mrvlMemcpyBox (PixmapPtr pPixmap, 
                    BoxPtr pbox, 
                    CARD8 *src, 
                    int src_pitch,
	                CARD8 *dst, 
                    int dst_pitch, 
                    Bool bSrcOff, 
                    Bool bDstOff);
void    mrvlMemcpy(PixmapPtr pSrc, 
                    PixmapPtr pDst, 
                    BoxPtr pSrcBox, 
                    BoxPtr pDstBox, 
                    CARD8 *src, 
                    int src_pitch, 
                    CARD8 *dst, 
                    int dst_pitch);
Bool    mrvlGeneralImageTransfer(gco2D      Engine2D,
                            unsigned int    src_paddr,
                            int             src_pitch,
                            unsigned int    dst_paddr,
                            int             dst_pitch,
                            gcsRECT         *pSrcRect,
                            gcsRECT         *pDstRect,
                            gceSURF_FORMAT  srcFormat,
                            gceSURF_FORMAT  dstFormat,
                            Bool            bCheckSrc,
                            Bool            bCheckDst,
                            unsigned int    pitchAlignment,
                            unsigned int    offsetAlignment);
Bool    mrvlImageTransferToScreen(PixmapPtr pDst, 
                            int x, 
                            int y, 
                            int w, 
                            int h, 
                            char *src_vaddr, 
                            int src_pitch, 
                            int syncType);
Bool    mrvlImageTransferFromScreen(PixmapPtr pSrc, 
                            int x, 
                            int y, 
                            int w, 
                            int h, 
                            char *dst_vaddr, 
                            int dst_pitch, 
                            int syncType);
Bool    mrvlGeneralRotationBlit(gco2D           engine2D,
                            gcoSURF             srcSurface,
                            gcoSURF             destSurface,                           
                            gcoSURF             filterDstSurface,
                            gcsRECT_PTR         srcRect,
                            gcsRECT_PTR         dstRect,
                            gceSURF_ROTATION    rotationDegree
                            );

void
mrvlMarkPixmapDirty (DrawablePtr drawable, int x1, int y1, int x2, int y2);

#endif
