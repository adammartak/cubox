#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>

#include <sys/mman.h>
#include <sys/ioctl.h>
#include <sys/kd.h>
#include <sys/stat.h>
#include <linux/fb.h>

#include "xf86.h"
#include "xf86Cursor.h"
#include "cursorstr.h"

//#include "vivante.h"
#include "dovefb_driver.h"
#include "mrvl_cursor.h"

//#define DEBUG_ARGB_HWC
#define LOG_FIRST_FRAME
#define LOG_FILENAME "/tmp/argb_hwc.raw"

#define TURN_DBG_MSG_ON  0
#define HWC32_SUPPORT	0x1
#define FIX_HWC32_ALPHA	0x2 /* current ARGB mode can't display correct while blending factor = 0*/
#define FIX_NPOS	0x8 /* Hw can't accept negative position. Enable this for SW Workaround. */

#define LCD_SPU_ADV_REG	0x084
#define SRAM_PARA1	0x1A4
#define DMA_CONTROL0	0x190
#define HWC_POSITION	0x10C
#define HWC_SIZE	0x110
#define FG_COLOR	0x128
#define BG_COLOR	0x12C
#define SRAM_WDATA	0x19C
#define SRAM_RDATA	0x158
#define SRAM_CTRL	0x198
#define IRQ_ISR		0x1C4

#if MRVL_SUPPORT_RANDR
static unsigned char *mmio_regbase[MRVL_MAX_CRTC_COUNT] = {0, };
#else
static unsigned char *mmio_regbase = 0;
#endif

#ifdef DEBUG_ARGB_HWC
static int caught = 0;
#endif

static int g_cursorWidth, g_cursorHeight;
extern int enc_func;
static unsigned char *g_cursor_data, *g_clipped_cur;
#if MRVL_SUPPORT_RANDR
static void
DovefbWriteCursor2HW(int crtc_id, int width, int height, unsigned char *image);
#else
static void
DovefbWriteCursor2HW(int width, int height, unsigned char *image);
#endif
/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
#if MRVL_SUPPORT_RANDR

static Bool 
MMap2LCDController(int crtc_id)
{
#if TURN_DBG_MSG_ON
    xf86DrvMsg(0, X_ERROR, "CURSOR: check resource\n");
#endif

    if (mmio_regbase[crtc_id] == 0)
        return FALSE;

    return TRUE;
}
#else
static Bool 
MMap2LCDController(void)
{
	int i;
#if TURN_DBG_MSG_ON
	xf86DrvMsg(0, X_ERROR, "CURSOR: check resource\n");
#endif
	if( 0 == gfx_dev_fd ) {
		for(i = 0; i < 6; i++) {
			sprintf( gfx_dev_name, "/dev/fb%d", i );

			gfx_dev_fd = open( gfx_dev_name, O_RDWR );
			if (ioctl(gfx_dev_fd, FBIOGET_FSCREENINFO, &fb_finfo)) {
				xf86DrvMsg(0, X_ERROR, "CURSOR: Can't get FSCREENINFO: %s\n", strerror(errno));
				return FALSE;
			}

			if ( 0 != strstr( fb_finfo.id, "GFX Layer" ))
				break;
			gfx_dev_fd = close(gfx_dev_fd);
		}
		
		if (0 == gfx_dev_fd)
			return FALSE;
#if TURN_DBG_MSG_ON
		xf86DrvMsg(0, X_ERROR, "CURSOR: Open fb<%s>, id=%s\n", gfx_dev_name, fb_finfo.id );
#endif
		fb_size = fb_finfo.smem_len;
		if ((frame_buffer = (unsigned char *) mmap(0, fb_size, PROT_READ | PROT_WRITE, MAP_SHARED, gfx_dev_fd, 0)) == (unsigned char *) -1) {
			xf86DrvMsg(0, X_ERROR, "CURSOR: Can't mmap %s\n", gfx_dev_name );
			return FALSE;
		}
	
		/* mmap to reg base. */
		if ((mmio_regbase = (unsigned char *) mmap(0, 0x1C4, PROT_READ | PROT_WRITE, MAP_SHARED, gfx_dev_fd, fb_size)) == (unsigned char *) -1) {
			xf86DrvMsg(0, X_ERROR, "CURSOR: Can't mmap %s regs\n", gfx_dev_name );
			return FALSE;
		}
		
		if ( 0 == gfx_dev_fd ) {
			xf86DrvMsg(0, X_ERROR, "CURSOR: Open overlay device failed.\n" );
			return FALSE;
		}
	}

	return TRUE;
}
#endif
/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
#if MRVL_SUPPORT_RANDR
static int 
SetRegValue(int crtc_id, 
            unsigned int offset,
	        unsigned int value, 
            unsigned int mask, 
            unsigned int shift)
{
	unsigned int x, x_bk;
	unsigned int lcd_base;

	if (!mmio_regbase[crtc_id]) {
		xf86DrvMsg(0, X_ERROR, "CURSOR: mmio_regbase doesn't exist.\n");
		if (FALSE == MMap2LCDController(crtc_id))
			return -1;
	}

	lcd_base = (unsigned int)mmio_regbase[crtc_id];

	/* 1. setup dumb mode. */
	x = x_bk = *((volatile unsigned int*)(lcd_base + offset));
	//x = x_bk = *((unsigned int*)(lcd_base + offset));
	
	/* clear */
	x &= ~mask;
	
	/* set value */
	x |= ((value << shift) & mask) ;

	//fprintf(stderr, "reg 0x%x = 0x%08x\n", offset, x);
	if (x_bk != x)
		*((volatile unsigned int*)(lcd_base + offset)) = x;
		//*((unsigned int*)(lcd_base + offset)) = x;
	
	return 0;
}
#else
static int 
SetRegValue(unsigned int offset,
	        unsigned int value, 
            unsigned int mask, 
            unsigned int shift)
{
	unsigned int x, x_bk;
	unsigned int lcd_base;

	if (!mmio_regbase) {
		xf86DrvMsg(0, X_ERROR, "CURSOR: mmio_regbase doesn't exist.\n");
		if (FALSE == MMap2LCDController())
			return -1;
	}

	lcd_base = (unsigned int)mmio_regbase;

	/* 1. setup dumb mode. */
	//x = x_bk = *((volatile unsigned int*)(lcd_base + offset));
	x = x_bk = *((unsigned int*)(lcd_base + offset));
	
	/* clear */
	x &= ~mask;
	
	/* set value */
	x |= ((value << shift) & mask) ;

	//fprintf(stderr, "reg 0x%x = 0x%08x\n", offset, x);
	if (x_bk != x)
		//*((volatile unsigned int*)(lcd_base + offset)) = x;
		*((unsigned int*)(lcd_base + offset)) = x;
	
	return 0;
}
#endif

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
#if MRVL_SUPPORT_RANDR
static unsigned int 
DovefbWaitSync(crtc_id)
{
	/* test hwc H/W event */
	volatile unsigned int* pReg;
	unsigned int i;

	if (!mmio_regbase[crtc_id]) {
		return -2;
	}


	pReg = (volatile unsigned int*)(mmio_regbase[crtc_id] + IRQ_ISR);
	//*pReg &= (~0x00400000);
	for(i = 0; i < 10000; i++) {
		if (*pReg & 0x00400000) {
			return 0;
		}
	}

	xf86DrvMsg(0, X_ERROR, "CURSOR: can't wait vsync.\n");

	return -1;
}
#else
static unsigned int 
DovefbWaitSync(void)
{
	/* test hwc H/W event */
	volatile unsigned int* pReg;
	unsigned int i;

	if (!mmio_regbase) {
		return -2;
	}


	pReg = (volatile unsigned int*)(mmio_regbase + IRQ_ISR);
	//*pReg &= (~0x00400000);
	for(i = 0; i < 10000; i++) {
		if (*pReg & 0x00400000) {
			return 0;
		}
	}

	xf86DrvMsg(0, X_ERROR, "CURSOR: can't wait vsync.\n");

	return -1;
}
#endif

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
/* Set cursor foreground and background colors */
#if MRVL_SUPPORT_RANDR
void 
DovefbSetCursorColors(ScrnInfoPtr pScrn, int bg, int fg, int crtc_id)
{
	FBDevPtr info = FBDEVPTR(pScrn);

	//xf86DrvMsg(0, X_ERROR, "CURSOR: set cursor colors, fg = 0x%x, bg = 0x%x\n", fg, bg);
	
	fg &= 0x00ffffff;
	//bg &= 0x00ffffff;
    bg = 0x00ffffff;

	/* wait for sync */
	DovefbWaitSync(crtc_id);

	/* set fg color1. */
	SetRegValue(crtc_id, FG_COLOR, fg, 0xFFFFFFFF, 0);

	/* set bf color2. */
	SetRegValue(crtc_id, BG_COLOR, bg, 0xFFFFFFFF, 0);

	/* save cursor color. */
	info->cursor_fg = fg;
	info->cursor_bg = bg;
}
#else
void 
DovefbSetCursorColors(ScrnInfoPtr pScrn, int bg, int fg)
{
	FBDevPtr info = FBDEVPTR(pScrn);

	//xf86DrvMsg(0, X_ERROR, "CURSOR: set cursor colors, fg = 0x%x, bg = 0x%x\n", fg, bg);
	
	fg &= 0x00ffffff;
	//bg &= 0x00ffffff;
    bg = 0x00ffffff;

	if (fg == info->cursor_fg && bg == info->cursor_bg)
		return;

	/* wait for sync */
	DovefbWaitSync();

	/* set fg color1. */
	SetRegValue(FG_COLOR, fg, 0xFFFFFFFF, 0);

	/* set bf color2. */
	SetRegValue(BG_COLOR, bg, 0xFFFFFFFF, 0);

	/* save cursor color. */
	info->cursor_fg = fg;
	info->cursor_bg = bg;
}
#endif
/*******************************************************************************
* xxx:
*DovefbSetCursorColors
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
/* Hide hardware cursor. */
#if MRVL_SUPPORT_RANDR
void 
DovefbHideCursor(ScrnInfoPtr pScrn, int crtc_id)
{
#if TURN_DBG_MSG_ON
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "CURSOR: hide crtc%d cursor\n", crtc_id);
#endif
    /* disable cursor */
    SetRegValue(crtc_id, DMA_CONTROL0, 0x0, 0x01000000, 24);

    if (enc_func & HWC32_SUPPORT)
        SetRegValue(crtc_id, LCD_SPU_ADV_REG, 0x0, 0x0000e000, 13);
}
#else
void 
DovefbHideCursor(ScrnInfoPtr pScrn)
{
#if TURN_DBG_MSG_ON
    xf86DrvMsg(0, X_ERROR, "CURSOR: hide cursor\n");
#endif
    /* disable cursor */
    SetRegValue(DMA_CONTROL0, 0x0, 0x01000000, 24);
    if (enc_func & HWC32_SUPPORT) 
        SetRegValue(LCD_SPU_ADV_REG, 0x0, 0x0000e000, 13);
}
#endif
/*******************************************************************************
* xxx:
*DovefbSetCursorColors
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
static int hwc_init_count = 0;
#define HWC_INIT_COUNT 5
/* Show hardware cursor. */
#if MRVL_SUPPORT_RANDR
void DovefbShowCursor(ScrnInfoPtr pScrn, int crtc_id)
{
#if TURN_DBG_MSG_ON
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "CURSOR: show crtc%d cursor\n", crtc_id);
#endif
    /* enable cursor */
    if (hwc_init_count >= HWC_INIT_COUNT)
        SetRegValue(crtc_id, DMA_CONTROL0, 0x1, 0x07000000, 24);

    if ((hwc_init_count >= HWC_INIT_COUNT) && (enc_func & HWC32_SUPPORT))
        SetRegValue(crtc_id, LCD_SPU_ADV_REG, 0x7, 0x0000e000, 13);
}
#else
void DovefbShowCursor(ScrnInfoPtr pScrn)
{
#if TURN_DBG_MSG_ON
    xf86DrvMsg(0, X_ERROR, "CURSOR: show cursor\n");
#endif
    /* enable cursor */
    if (hwc_init_count >= HWC_INIT_COUNT)
        SetRegValue(DMA_CONTROL0, 0x1, 0x07000000, 24);

    if ((hwc_init_count >= HWC_INIT_COUNT) && (enc_func & HWC32_SUPPORT))
        SetRegValue(LCD_SPU_ADV_REG, 0x7, 0x0000e000, 13);
}
#endif

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
/* Set cursor position to (x,y) with offset into cursor bitmap at
 *  * (xorigin,yorigin)
 *   */
#if MRVL_SUPPORT_RANDR
static int fix_nega_pos_mode = 0;
static int clip_w = 0, clip_h = 0, trim_w, trim_h;
unsigned char* copy_lines(unsigned char *dst,
                       unsigned char *src,
                       int clip_w, int clip_h,
                       int trim_w, int trim_h)
{
    int i;

    for (i = 0; i < clip_h; i++) {
        memcpy(dst + (i * clip_w * 4),                                 /* dst */
               src + ((((i + trim_h) * g_cursorWidth) + trim_w) * 4),  /* src */
               clip_w * 4);
    }

    return dst;
}

void fix_npos(ScrnInfoPtr pScrn, int x, int y, int crtc_id)
{
	unsigned int value;
	int org_x, org_y;

        org_x = x;
        org_y = y;

        if (y < 0)	y = 0;
        if (x < 0)	x = 0;

        if ((org_x < 0) || (org_y < 0)) {
            /* remove all pixels in clipped-out area. */

            /* 1. calc (W, H) after clip. */
            clip_w = (org_x < 0) ? (g_cursorWidth  + org_x) : g_cursorWidth;
            clip_h = (org_y < 0) ? (g_cursorHeight + org_y) : g_cursorHeight;

            /* 2. calc (W, H) will be trimmed. */
            trim_w = g_cursorWidth  - clip_w;
            trim_h = g_cursorHeight - clip_h;

            /* 3. copy to new buffer line by line. */
            copy_lines(g_clipped_cur, g_cursor_data, clip_w, clip_h, trim_w, trim_h);

            /* 4. reprogram hwc size. */
            SetRegValue(crtc_id, HWC_SIZE, ((clip_h << 16) | clip_w), 0xFFFFFFFF, 0);

            /* 5. Program clipped cursor into hw. */
            DovefbWriteCursor2HW(crtc_id, clip_w, clip_h, g_clipped_cur);

            fix_nega_pos_mode = 1;
        } else if (fix_nega_pos_mode) {
            /* 1. reprogram hwc size. */
            SetRegValue(crtc_id, HWC_SIZE, ((g_cursorHeight << 16) | g_cursorWidth), 0xFFFFFFFF, 0);

            /* 2. Program clipped cursor into hw. */
            DovefbWriteCursor2HW(crtc_id, g_cursorHeight, g_cursorWidth, g_cursor_data);

            fix_nega_pos_mode = 0;
        }

	/* set cursor position cursor */
	value = (y << 16) | x;
	SetRegValue(crtc_id, HWC_POSITION, value, 0xFFFFFFFF, 0);
}
void 
DovefbSetCursorPosition(ScrnInfoPtr pScrn, int x, int y, int crtc_id)
{
	unsigned int value;

#if TURN_DBG_MSG_ON
	xf86DrvMsg(pScrn->scrnIndex, X_INFO, "CURSOR: set crtc%d cursor position, x=%d, y=%d\n", crtc_id, x, y);
#endif

	DovefbHideCursor(pScrn, crtc_id);

	/* Workaround HW can't accept negative position. */
        if ((enc_func & HWC32_SUPPORT) && (enc_func & FIX_NPOS)) {
            fix_npos(pScrn, x, y, crtc_id);
        } else {
            /* set cursor position cursor */
            value = (y << 16) | x;
            SetRegValue(crtc_id, HWC_POSITION, value, 0xFFFFFFFF, 0);
        }

	DovefbShowCursor(pScrn, crtc_id);	
}
#else
void 
DovefbSetCursorPosition(ScrnInfoPtr pScrn, int x, int y)
{
	unsigned int value;

#if TURN_DBG_MSG_ON	
	xf86DrvMsg(0, X_ERROR, "CURSOR: set cursor position, x=%d, y=%d\n", x, y);
#endif

	/* wait for sync */
	//DovefbWaitSync();

	DovefbHideCursor(pScrn);	
	/* set cursor position cursor */
	value = (y << 16) | x;
	SetRegValue(HWC_POSITION, value, 0xFFFFFFFF, 0);

	DovefbShowCursor(pScrn);	
}
#endif

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
/* Copy cursor image from `image' to video memory.  DovefbSetCursorPosition
 *  * will be called after this, so we can ignore xorigin and yorigin.
 *   */
#if MRVL_SUPPORT_RANDR
static void
DovefbWriteCursor2HW(int crtc_id, int width, int height, unsigned char *image)
{
	int i;
	unsigned int *pData;;
	int data_len;
	int hwc32_len;
	unsigned int data_tmp;
	unsigned int x;
	unsigned int write_data;
	unsigned int addr = 0;
	int cursor_width = width;
	int cursor_height = height;
	int j = 0;
#ifdef DEBUG_ARGB_HWC
	int logfd;
#endif


	if (!mmio_regbase[crtc_id]) {
		if (FALSE == MMap2LCDController(crtc_id))
			return;
	}

	/* checking SRAM power whether enabled. If not, we enable it. */
	x = *((volatile unsigned int*)(mmio_regbase[crtc_id]+SRAM_PARA1));
	if (x & (0x1 << 7)) {
		xf86DrvMsg(0, X_WARNING, "HWC: hwc has been powered down. Power on it\n");
		SetRegValue(crtc_id, SRAM_PARA1, 1, (0x1 << 15)|(0x1 <<7), 15);
	}

	pData = (unsigned int*)image;
	data_len = ((cursor_width * cursor_height * 2) + 31) >> 5;
	hwc32_len = cursor_width * cursor_height;

#if TURN_DBG_MSG_ON
	xf86DrvMsg(0, X_INFO, "CURSOR: crtc%d, data_len = %d\n", crtc_id, data_len);
#endif

	addr = 0;
	/* 2. prepare cursor data */
	if (!(enc_func & HWC32_SUPPORT)) {
                /* program 2bit mode hwc SRAM. */
		for (i = 0; i < data_len;) {
       			j = 0;

			/* Prepare data */
			write_data = *pData;

			SetRegValue(crtc_id, SRAM_WDATA, write_data, 0xffffffff, 0);

			/* write hwc sram */
			data_tmp = (0x2 << 14) |
				   (0xf << 8 ) |
				   addr;

			SetRegValue(crtc_id, SRAM_CTRL, data_tmp, 0xffffffff, 0);

			i++;
			pData++;
			addr++;
		}
	} else {
                /* program 32bit mode hwc SRAM. */
		pData = (unsigned int*)image;
		addr = 0;
		x = 0x55555555;

#ifdef DEBUG_ARGB_HWC
                if (caught == 0) {
                    mode_t mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;

                    xf86DrvMsg(0, X_INFO, "debug hwc: Open log file.WxH=(%dx%d)\n", cursor_width, cursor_height);
                    logfd = open(LOG_FILENAME, (O_CREAT | O_RDWR), mode);

                    if (logfd < 0)
                         xf86DrvMsg(0, X_INFO, "debug hwc: Can't Open log file(%s).\n", LOG_FILENAME);
                }
#endif

  		/* enable hwc32 for read/write SRAM. */
		SetRegValue(crtc_id, LCD_SPU_ADV_REG, 0x7, 0x0000e000, 13);

		/* prepare hwc 32 data */
		for (i = 0; i < hwc32_len;) {
			j = 0;

			/* Prepare data */
			write_data = *pData;

#ifdef DEBUG_ARGB_HWC
                        if ((caught == 0) & (logfd >= 0)) {
                            size_t count;
                            xf86DrvMsg(0, X_INFO, "debug hwc: write hwc32 to log file.\n");
                            count = write(logfd, (void*)&write_data, 4);
                            xf86DrvMsg(0, X_INFO, "debug hwc: write %d bytes to log file successfully.\n", count);
                        }
#endif
			/* collect 2bit hwc mask buffer. */
			if ((enc_func & FIX_HWC32_ALPHA) && ((0xff000000 & write_data) == 0)) {
				x &= ~(0x3 << ((addr%16)*2));
			}

			/* write one per 16 times */
			if ((addr != 0) && ((addr%16) == 15)) {
				/* prepare data. */
				SetRegValue(crtc_id, SRAM_WDATA, x, 0xffffffff, 0);

				/* write 2bit hwc sram */
				data_tmp = (0x2 << 14) |
					   (0xf <<  8) |
					   (addr / 16);

				/* enable write action. */
				SetRegValue(crtc_id, SRAM_CTRL, data_tmp, 0xffffffff, 0);

				/* reset reg value for next program. */
				x = 0x55555555;
			}

			SetRegValue(crtc_id, SRAM_WDATA, write_data, 0xffffffff, 0);

			/* write 32bit hwc sram */
			data_tmp = (0x2 << 14) |
				   (0xc << 8 ) |
				   (0x300 & addr) << 4 |
				   (0x0ff & addr);

			/* enable write. */
			SetRegValue(crtc_id, SRAM_CTRL, data_tmp, 0xffffffff, 0);

			i++;
			pData++;
			addr++;
		} /* for() */
#ifdef DEBUG_ARGB_HWC
                if ((caught == 0) && (logfd >= 0)) {
                    close(logfd);
                    logfd = -1;
                }
#ifdef LOG_FIRST_FRAME
                caught = 1;
#endif
#endif
	} /* if (enc_func & HWC32_SUPPORT) */

        if (hwc_init_count < HWC_INIT_COUNT)
		hwc_init_count++;
}
#else
static void
DovefbWriteCursor2HW(int width, int height, unsigned char *image)
{
	int i;
	unsigned int *pData;;
	int data_len;
	unsigned int data_tmp;
	unsigned int readback_data;
	unsigned int write_data;
	unsigned int addr = 0;
	int cursor_width = width;
	int cursor_height = height;

	if (!mmio_regbase) {
        if (FALSE == MMap2LCDController(crtc_id))
		    return;
	}

	pData = (unsigned int*)image;

	data_len = ((cursor_width * cursor_height * 2) + 31) >> 5;

#if TURN_DBG_MSG_ON
	xf86DrvMsg(0, X_ERROR, "CURSOR: data_len = %d\n", data_len);
#endif

	/* 2. prepare cursor data */
	for (i = 0; i < data_len;) {
		/* Prepare data */
		write_data = *pData;
		SetRegValue(SRAM_WDATA, write_data, 0xffffffff, 0);

		/* write hwc sram */
		data_tmp = (0x2 << 14) |
			   (0xf << 8 ) |
				addr;
		////usleep(200);	
		SetRegValue(SRAM_CTRL, data_tmp, 0xffffffff, 0);
		
		////usleep(200);	
		/* readback check */
		data_tmp = (0x0 << 14) |
			   (0xf << 8 ) |
				addr;
		SetRegValue(SRAM_CTRL, data_tmp, 0xffffffff, 0);
		////usleep(200);	
		readback_data = *((volatile unsigned int*)(mmio_regbase+SRAM_RDATA));
		//readback_data = *((unsigned int*)(mmio_regbase+SRAM_RDATA));
		if (readback_data == write_data) {
			i++;
			pData++;
			addr++;
		} else {
			xf86DrvMsg(0, X_ERROR, "CURSOR: addr=%d, rewrite 0x%08x again, readback data = 0x%08x\n", addr, write_data, readback_data);
		}
	}
}
#endif

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
#if MRVL_SUPPORT_RANDR
static void
DovefbLoadCursorImage(ScrnInfoPtr pScrn, unsigned char *image, int crtc_id)
{
    /* wait for sync and disable cursor. */
    DovefbWaitSync(crtc_id);

    DovefbHideCursor(pScrn, crtc_id);

    /*
     * If enable HWC32 and fixing negative position feature, we save
     * cursor image for possible manipulation.
     */
    if ((enc_func & HWC32_SUPPORT) && (enc_func & FIX_NPOS)) {
        /* backup cursor image. */
        memcpy(g_cursor_data, image, g_cursorWidth * g_cursorHeight * 4);
    }


    if (fix_nega_pos_mode && (enc_func & HWC32_SUPPORT) && (enc_func & FIX_NPOS)) {
            /* clip out unused pixel. */
            copy_lines(g_clipped_cur, g_cursor_data, clip_w, clip_h, trim_w, trim_h);
	
            /* reprogram hwc size. */
            SetRegValue(crtc_id, HWC_SIZE, ((clip_h << 16) | clip_w), 0xFFFFFFFF, 0);

            /* write cursor data into hw. */
            DovefbWriteCursor2HW(crtc_id, clip_w, clip_h, g_clipped_cur);
    } else {
        SetRegValue(crtc_id, HWC_SIZE, ((g_cursorHeight << 16) | g_cursorWidth), 0xFFFFFFFF, 0);

        /* write cursor data into hw. */
        DovefbWriteCursor2HW(crtc_id, g_cursorWidth, g_cursorHeight, image);
    }

    /* Display new cursor. */
    DovefbShowCursor(pScrn, crtc_id);
}
#else
static void 
DovefbLoadCursorImage(ScrnInfoPtr pScrn, unsigned char *image)
{
	/* wait for sync and disable cursor. */
	DovefbWaitSync();

	DovefbHideCursor(pScrn);

	/* write cursor data into hw. */
	DovefbWriteCursor2HW(g_cursorWidth, g_cursorHeight, image);

	/* Display new cursor. */
	DovefbShowCursor(pScrn);
}
#endif
/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
/* Determine if hardware cursor is in use. */
#if MRVL_SUPPORT_RANDR == 0
static Bool 
DovefbUseHWCursor(ScreenPtr pScreen, CursorPtr pCurs)
{
	if (pCurs) {
		g_cursorWidth = pCurs->bits->width;
		g_cursorHeight = pCurs->bits->height;
	}	
#if TURN_DBG_MSG_ON
	xf86DrvMsg(0, X_ERROR, "CURSOR: use hw cursor, width=%d, height=%d\n", g_cursorWidth, g_cursorHeight);
#endif
	/* wait for sync */
	DovefbWaitSync();

	/* set size */
	SetRegValue(HWC_SIZE, ((g_cursorHeight << 16) | g_cursorWidth), 0xFFFFFFFF, 0);

	return TRUE;	
}
#endif
/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
#if MRVL_SUPPORT_RANDR == 0
static unsigned char *
DovefbRealizeCursor(xf86CursorInfoPtr infoPtr, CursorPtr pCurs)
{
	CursorBitsPtr bits = pCurs->bits;
	unsigned char  * ram;
	unsigned char  * bk_ram;
	unsigned short * usram;
	unsigned int * uiram;
	unsigned char  * psource = bits->source;
	unsigned char  * pmask = bits->mask;
	//int x, y, srcwidth, i, j, k;
	//unsigned int MaxCursor;
	//int src_w_bytes;
	//unsigned int uiResult;
	//unsigned short usResult;
	unsigned int total_bits;
	unsigned int total_bytes;
	unsigned int src_total_bits;


	total_bits = bits->width * bits->height * 2; // Use 2 bits mode.
	src_total_bits = ((bits->width+7) & (~0x7)) * bits->height * 2;
	total_bytes = ((src_total_bits + 7) & (~0x7)) / 8;

	ram   = (unsigned char *) xcalloc(1, total_bytes);
	usram = (unsigned short *)ram;
	uiram = (unsigned int *)ram;

	{
		unsigned int ibit, shift_bits;
		unsigned char  ucBitMask = 0x01;

		for (ibit = 0; ibit < src_total_bits; ibit++) {
			// find bit's location
			shift_bits = ibit%8;
			ucBitMask = 0x1 << shift_bits;
			
			if ((ibit%32) < 8) {
				usram[(ibit/16)] |= (( (psource[(ibit/32)*4] & (ucBitMask)) & 0xFFFF) << (shift_bits+0));
			
				if ((psource[(ibit/32)*4] & (ucBitMask)) && (pmask[(ibit/32)*4]   & (ucBitMask))) 
					usram[(ibit/16)] |= 0x0;
				else	
					usram[(ibit/16)] |= (( (pmask[(ibit/32)*4]   & (ucBitMask)) & 0xFFFF) << (shift_bits+1));
			} else if (((ibit%32) >= 8) && ((ibit%32) < 16)){
				usram[(ibit/16)+1] |= (( (psource[(ibit/32)*4+1] & (ucBitMask)) & 0xFFFF) << (shift_bits+0));
				if ((psource[(ibit/32)*4+1] & (ucBitMask)) && (pmask[(ibit/32)*4+1]   & (ucBitMask))) 
					usram[(ibit/16)+1] |= 0x0;
				else	
					usram[(ibit/16)+1] |= (( (pmask[(ibit/32)*4+1]   & (ucBitMask)) & 0xFFFF) << (shift_bits+1));
			}
		}
		
		/* remove padding. if bits->width is not divided by 8. */
		if((bits->width % 8) != 0) {
			unsigned int result_data;
			unsigned int source_data;
			unsigned int bitMask = 0x00000001;
			unsigned int *bk_uiram;
			unsigned int bitWidth = bits->width*2;

			bk_ram   = (unsigned char *) xcalloc(1, total_bytes);
			bk_uiram = (unsigned int *)bk_ram;
		
			/* collect bits */
			for(ibit = 0; ibit < total_bits; ibit++) {
				source_data = uiram[ibit/bitWidth];
				result_data = bk_uiram[ibit/32];
			
				if((ibit%bitWidth) >= (ibit%32))
					result_data |= ((source_data & (bitMask << (ibit%bitWidth))) >> ((ibit%bitWidth) - (ibit%32)));
				else {
					result_data |= ((source_data & (bitMask << (ibit%bitWidth))) << ((ibit%32) - (ibit%bitWidth)));
				}

				/* store data back */
				bk_uiram[ibit/32] = result_data; 
			}
			
			xfree(ram);
			ram = bk_ram;
			uiram = (unsigned int*)ram;
		}
	}			

	return ram;
}
#endif
/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
#if MRVL_SUPPORT_RANDR == 0

#ifdef ARGB_CURSOR
Bool 
DovefbHWCursorARGB (ScreenPtr pScreen, CursorPtr pCurs)
{
	if (pCurs) {
		g_cursorWidth = pCurs->bits->width;
		g_cursorHeight = pCurs->bits->height;
	}	
#if TURN_DBG_MSG_ON
	xf86DrvMsg(0, X_ERROR, "CURSOR: use hw ARGB cursor, width=%d, height=%d\n", g_cursorWidth, g_cursorHeight);
#endif
	/* wait for sync */
	DovefbWaitSync();

	/* set size */
	SetRegValue(HWC_SIZE, ((g_cursorHeight << 16) | g_cursorWidth), 0xFFFFFFFF, 0);

	return TRUE;	
}
#endif

#endif // RANDR
/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
#if MRVL_SUPPORT_RANDR

#ifdef ARGB_CURSOR
void
DovefbLoadCursorARGB (ScrnInfoPtr pScrn, CARD32 *image, int crtc_id)
{
	unsigned char *dstPtr;
	unsigned int i, total_pixels, data_len;
	unsigned int pcase;
	unsigned int *dstData;

	if (enc_func & HWC32_SUPPORT) {
		DovefbLoadCursorImage(pScrn, (unsigned char*)image, crtc_id);
	} else {
		/* Initialization. */
		total_pixels = g_cursorWidth * g_cursorHeight;
		data_len = (2*total_pixels) >> 3;

		dstPtr = (unsigned char*)malloc( data_len );

		memset((void*)dstPtr, (int)0x00, (size_t)data_len );
	
		dstData = (unsigned int*)dstPtr;
		for( i = 0; i < total_pixels; i++ ) {
			pcase = 0;
			/* collect pixel data. */
			if( ( (image[i]) & 0xff000000) < MRVL_CURSOR_ALPHA )
				/* alpha is too small. */
				/* we display this pixel in transparent. */
				pcase = 0x0;
			else if ( ((image[i]) & 0x00e0e0e0) > 0 ) {
				/* alpha is big enough. */
				/* color value is big enough, we display white pixel. */
				pcase = 0x2;
			} else {
				pcase = 0x1;
			}

			dstData[i/16] |= pcase << (i%16)*2;
		} /* for() */
	
		/* write cursor data to hw. */
		DovefbLoadCursorImage(pScrn, dstPtr, crtc_id);

		/* free resource. */
		free(dstPtr);
	} /* enc_func & 0x1 */
}
#endif

#else 

#ifdef ARGB_CURSOR
void 
DovefbLoadCursorARGB (ScrnInfoPtr pScrn, CursorPtr pCurs)
{
	unsigned int *image = (unsigned int *)pCurs->bits->argb;
	unsigned char *dstPtr;
	unsigned int i, total_pixels;
	unsigned int pcase;
	unsigned int *dstData;

	/* Initialization. */
	total_pixels = pCurs->bits->height*pCurs->bits->width;
	dstPtr = (unsigned char*)malloc( (2*total_pixels) >> 3 );
	memset(dstPtr, 0x00, (2*total_pixels) >> 3 );

	dstData = (unsigned int*)dstPtr;
	for( i = 0; i < total_pixels; i++ ) {
		pcase = 0;
		/* collect pixel data. */
		if( ( (image[i]) & 0xff000000) < MRVL_CURSOR_ALPHA )
			/* alpha is too small. */
			/* we display this pixel in transparent. */
			pcase = 0x0;
		else if ( ((image[i]) & 0x00e0e0e0) > 0 ) {
			/* alpha is big enough. */
			/* color value is big enough, we display white pixel. */
			pcase = 0x2;
		} else {
			pcase = 0x1;
		}

		dstData[i/16] |= pcase << (i%16)*2;
	}

	/* write cursor data to hw. */
	DovefbLoadCursorImage(pScrn, dstPtr);

	/* free resource. */
	free(dstPtr);
}
#endif

#endif

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
#if MRVL_SUPPORT_RANDR
Bool DovefbCursorInit(ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    MRVLGetPrivateByScrn(pScrn);
    int i;

    if (enc_func & HWC32_SUPPORT) {
        xf86DrvMsg(0, X_INFO, "HWC32: hwc32 size is 32x32.\n");
        g_cursorWidth = 32;
        g_cursorHeight = 32;

        if (enc_func & FIX_NPOS) {
            g_cursor_data = malloc(g_cursorWidth*g_cursorHeight*4);
            g_clipped_cur = malloc(g_cursorWidth*g_cursorHeight*4);
        }
    } else {
        g_cursorWidth = 64;
        g_cursorHeight = 64;
    }


    for (i = 0; i < MRVL_MAX_CRTC_COUNT; i++)
    {
        // initialize crtc 
        if (pDev->pCrtc[i]) 
        {
            mmio_regbase[i] = (unsigned char *)pDev->mmio[i];
            if (!mmio_regbase[i])
            {
                xf86DrvMsg(0, X_ERROR, "Fail to map memory for crtc %d\n", i);
                continue;
            }
        
            /* set default bg and fg */
            DovefbSetCursorColors(pScrn, 0xFFFFFF, 0x0, i);

            /* set size */
            SetRegValue(i, HWC_SIZE, ((g_cursorHeight << 16) | g_cursorWidth), 0xFFFFFFFF, 0);
        }
    }

    if (enc_func & HWC32_SUPPORT) {
        return xf86_cursors_init (pScreen, g_cursorWidth, g_cursorHeight,
			      (HARDWARE_CURSOR_INVERT_MASK |
			       HARDWARE_CURSOR_SWAP_SOURCE_AND_MASK |
			       HARDWARE_CURSOR_AND_SOURCE_WITH_MASK |
			       HARDWARE_CURSOR_SOURCE_MASK_INTERLEAVE_32 |
			       HARDWARE_CURSOR_ARGB));
    } else {
        return xf86_cursors_init (pScreen, g_cursorWidth, g_cursorHeight,
			      (HARDWARE_CURSOR_TRUECOLOR_AT_8BPP |
			       HARDWARE_CURSOR_BIT_ORDER_MSBFIRST |
			       HARDWARE_CURSOR_INVERT_MASK |
			       HARDWARE_CURSOR_SWAP_SOURCE_AND_MASK |
			       HARDWARE_CURSOR_AND_SOURCE_WITH_MASK |
			       HARDWARE_CURSOR_SOURCE_MASK_INTERLEAVE_64 |
			       HARDWARE_CURSOR_UPDATE_UNHIDDEN |
			       HARDWARE_CURSOR_ARGB));
    }
}

#else

/* Initialize hardware cursor support. */
Bool DovefbCursorInit(ScreenPtr pScreen)
{
	ScrnInfoPtr pScrn   = xf86Screens[pScreen->myNum];
	FBDevPtr info = FBDEVPTR(pScrn);
    
	xf86CursorInfoPtr  cursor;

	if (!(cursor = info->cursor = xf86CreateCursorInfoRec())) return FALSE;

	/* Get io regs base address. */
	if (FALSE == MMap2LCDController()) return FALSE;

	if (enc_func & HWC32_SUPPORT) {
		g_cursorWidth = 32;
		g_cursorHeight = 32;
	} else {
		g_cursorWidth = 64;
		g_cursorHeight = 64;
	}

	cursor->MaxWidth          = g_cursorWidth;
	cursor->MaxHeight         = g_cursorHeight;
	if (enc_func & HWC32_SUPPORT) {
		cursor->Flags     = HARDWARE_CURSOR_SHOW_TRANSPARENT |
				HARDWARE_CURSOR_AND_SOURCE_WITH_MASK |
				HARDWARE_CURSOR_SWAP_SOURCE_AND_MASK;
	} else {
		cursor->Flags     = HARDWARE_CURSOR_TRUECOLOR_AT_8BPP |
                                HARDWARE_CURSOR_SWAP_SOURCE_AND_MASK;
	}
	cursor->SetCursorColors   = DovefbSetCursorColors;
	cursor->SetCursorPosition = DovefbSetCursorPosition;
	cursor->LoadCursorImage   = DovefbLoadCursorImage;
	cursor->HideCursor        = DovefbHideCursor;
	cursor->ShowCursor        = DovefbShowCursor;
	cursor->UseHWCursor       = DovefbUseHWCursor;
	if (!(enc_func & HWC32_SUPPORT)) {
		cursor->RealizeCursor	  = DovefbRealizeCursor;
#ifdef ARGB_CURSOR
	cursor->UseHWCursorARGB   = DovefbHWCursorARGB;
	cursor->LoadCursorARGB    = DovefbLoadCursorARGB;
#endif


	return xf86InitCursor(pScreen, cursor);
}

#endif

