#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <string.h>
#include <stdlib.h>

/* all driver need this */
#include "xf86.h"
#include "xf86_OSproc.h"
#include "mipointer.h"
#include "mibstore.h"
#include "micmap.h"
#include "colormapst.h"
#include "xf86cmap.h"
#include <xorg/shadow.h>
#include "dgaproc.h"

/* for visuals */
#include "fb.h"
#ifdef USE_AFB
#include "afb.h"
#endif

#if GET_ABI_MAJOR(ABI_VIDEODRV_VERSION) < 6
#include "xf86Resources.h"
#include "xf86RAC.h"
#endif

#include "fbdevhw.h"
#include "xf86xv.h"
#include "xf86xvpriv.h"
#include "./X11/extensions/Xv.h"
#include "./fourcc.h"
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>
#include <unistd.h>

#include <sys/mman.h>
#include <sys/ioctl.h>
#include <sys/kd.h>
#include <sys/types.h>
#include <linux/fb.h>
#include <video/dovefb.h>
//#include "vivante.h"
#include "dovefb_driver.h"


/* H/W register offset. */
#define DMA_CONTROL0    0x190
#define DMA_CONTROL1    0x194
#define COLORKEY_Y  0x130
#define COLORKEY_U  0x134
#define COLORKEY_V  0x138
#define CONTRAST_REG    0x1AC
#define SATURATION_REG  0x1B0
#define HUE_REG     0x1B4
#define BRIGHTNESS_REG  0x1AC
#define COLORKEY_ENA    0x084

#define CHANGE_XV_ADAPTOR_SEQ	0x4
extern Bool debug_opt;
extern int enc_func;

/* dovefb proprietary data structure */
struct _sViewPortInfo gTestViewPortInfo = {
    .srcWidth   =   0,  // video source size
    .srcHeight  =   0,
    .zoomXSize  =   0,  // size after zooming
    .zoomYSize  =   0,
    .ycPitch    =   0,  // for testing..... fixed me.
    .uvPitch    =   0

};

struct _sViewPortOffset gViewPortOffset = {
    .xOffset    =   0,  //position on screen
    .yOffset    =   0,
};

/* Only for Add internal surface structure variabl */
struct _sVideoBufferAddr gVideoBufferAddr = {
    .frameID = 0,
    .startAddr = 0
};

DOVEFBVideoMode gVidMode = 0;

#define MAKE_ATOM(a) MakeAtom(a, sizeof(a) - 1, TRUE)
#define ClipValue(v,min,max) ((v) < (min) ? (min) : (v) > (max) ? (max) : (v))

static Atom xv_active_lcd;
static Atom xv_deinterlace;
static Atom xv_use_gpu;
static Atom xv_colorkey;
static Atom xv_autopaint_colorkey;
static Atom xv_ckey_mode; /* 0x0 ~ 0x7 */
static Atom xv_ckey_y1;
static Atom xv_ckey_y2;
static Atom xv_ckey_y;
static Atom xv_ckey_y_alpha;
static Atom xv_ckey_u1;
static Atom xv_ckey_u2;
static Atom xv_ckey_u;
static Atom xv_ckey_u_alpha;
static Atom xv_ckey_v1;
static Atom xv_ckey_v2;
static Atom xv_ckey_v;
static Atom xv_ckey_v_alpha;
static Atom xv_config_path; /* 0=video, 1=gfx, 2=configurable. */
static Atom xv_config_alpha;/* 0xFF = no graphic, 0x0 = no video */

static Atom xv_hue;
static Atom xv_brightness;
static Atom xv_contrast;
static Atom xv_saturation;

static XF86VideoEncodingRec OverlayEncoding[] =
{
   { 0, "XV_IMAGE", 2048, 2048, {1, 1} },
};

static XF86VideoFormatRec OverlayFormats[] =
{
    {8, TrueColor},
    {8, DirectColor},
    {8, PseudoColor},
    {12, TrueColor},
    {16, TrueColor},
    {24, TrueColor},
    {32, TrueColor}
};

#define MRVL_XV_ADAPTOR_NUM     32

#if MRVL_XV_SUPPORT_RGB_FORMAT

#define NUM_IMAGES       7

#define FOURCC_RGBA32   0x41424752

#define XVIMAGE_RGBA32(byte_order)   \
        { \
                FOURCC_RGBA32, \
                XvRGB, \
                byte_order, \
                { 'R', 'G', 'B', 'A', \
                  0x00,0x00,0x00,0x10,0x80,0x00,0x00,0xAA,0x00,0x38,0x9B,0x71}, \
                32, \
                XvPacked, \
                1, \
                24, 0x00FF0000, 0x0000FF00, 0x000000FF, \
                0, 0, 0, 0, 0, 0, 0, 0, 0, \
                {'A', 'R', 'G', 'B', \
                  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}, \
                XvTopToBottom \
        }

#define FOURCC_RGB24    0x00000000

#define XVIMAGE_RGB24   \
        { \
                FOURCC_RGB24, \
                XvRGB, \
                LSBFirst, \
                { 'R', 'G', 'B', 0x01, \
                  0x00,0x00,0x00,0x10,0x80,0x00,0x00,0xAA,0x00,0x38,0x9B,0x71}, \
                24, \
                XvPacked, \
                1, \
                24, 0x00FF0000, 0x0000FF00, 0x000000FF, \
                0, 0, 0, 0, 0, 0, 0, 0, 0, \
                { 'R', 'G', 'B', \
                  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}, \
                XvTopToBottom \
        }


#define FOURCC_RGB565    0x32424752

#define XVIMAGE_RGB565(byte_order)   \
        { \
                FOURCC_RGB565, \
                XvRGB, \
                byte_order, \
                { 'R', 'G', 'B', 0x00, \
                  0x00,0x00,0x00,0x10,0x80,0x00,0x00,0xAA,0x00,0x38,0x9B,0x71}, \
                16, \
                XvPacked, \
                1, \
                16, 0x0000F800, 0x000007E0, 0x0000001F, \
                0, 0, 0, 0, 0, 0, 0, 0, 0, \
                {'R', 'G', 'B', \
                  0, 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}, \
                XvTopToBottom \
        }

static XF86ImageRec OverlayImages[NUM_IMAGES] =
{
#if X_BYTE_ORDER == X_BIG_ENDIAN
    XVIMAGE_RGB565(MSBFirst),
    XVIMAGE_RGBA32(MSBFirst),
#else
    XVIMAGE_RGB565(LSBFirst),
    XVIMAGE_RGBA32(LSBFirst),
#endif
    XVIMAGE_RGB24,
    XVIMAGE_UYVY,       // need to swap UV, (422 Packed)
    XVIMAGE_YUY2,       // YVYU fromat, need to swap (422 Packed )
    XVIMAGE_YV12,       // VYUY format, don't need to swap (411 Planar)
    XVIMAGE_I420        // UYVY fromat, need to swap (420 Planar)
};

#else

#define NUM_IMAGES       4

static XF86ImageRec OverlayImages[NUM_IMAGES] =
{
    XVIMAGE_UYVY,       // need to swap UV, (422 Packed)
    XVIMAGE_YUY2,       // YVYU fromat, need to swap (422 Packed )
    XVIMAGE_YV12,       // VYUY format, don't need to swap (411 Planar)
    XVIMAGE_I420        // UYVY fromat, need to swap (420 Planar)
};

#endif

typedef struct __XV_COLORKEY_REG
{
    unsigned int orig_colorkey_y;
    unsigned int orig_colorkey_u;
    unsigned int orig_colorkey_v;
    unsigned int orig_dma1;
    unsigned int orig_reg84;
    Bool         valid;
}
XV_COLORKEY_REG;

typedef struct {
    RegionRec     clip;

    /* traditional methods. */
    unsigned int colorkey;
    unsigned int autopaint_colorkey;
    unsigned int hue;
    unsigned int brightness;
    unsigned int contrast;
    unsigned int saturation;

    /* dovefb settings */
    unsigned int    ckey_mode; /* 0x0 ~ 0x7 */
    unsigned int    ckey_y1;
    unsigned int    ckey_y2;
    unsigned int    ckey_y;
    unsigned int    ckey_y_alpha;
    unsigned int    ckey_u1;
    unsigned int    ckey_u2;
    unsigned int    ckey_u;
    unsigned int    ckey_u_alpha;
    unsigned int    ckey_v1;
    unsigned int    ckey_v2;
    unsigned int    ckey_v;
    unsigned int    ckey_v_alpha;
    unsigned int    config_path; /* 0=video, 1=gfx, 2=configurable. */
    unsigned int    config_alpha;/* 0xFF = no graphic, 0x0 = no video */

    unsigned int    bDeinterlace;
    unsigned int    UseGPU;

    xf86CrtcPtr     desired_crtc;
    Bool            textured;

    XV_COLORKEY_REG  ckey_saving[MRVL_MAX_CRTC_COUNT];

} DovefbPortPrivRec, *DovefbPortPrivPtr;

static XF86AttributeRec OverlayAttributes[] =
{
    {XvSettable | XvGettable,    0,             1, "XV_ACTIVE_LCD"},
    {XvSettable | XvGettable,    0,    0xFFFFFFFF, "XV_COLORKEY"},
    {XvSettable | XvGettable,    0,             1, "XV_AUTOPAINT_COLORKEY"},
/* The following attributes make movie player Totem behave abnormal, disable them - Lea */
#if 0
    {XvSettable | XvGettable,    0,           100, "XV_HUE"},
    {XvSettable | XvGettable,    0,           100, "XV_BRIGHTNESS"},
    {XvSettable | XvGettable,    0,           100, "XV_CONTRAST"},
    {XvSettable | XvGettable,    0,           100, "XV_SATURATION"},
    {XvSettable | XvGettable,    0,             7, "XV_COLORKEY_MODE"},
    {XvSettable | XvGettable,    0,           255, "XV_COLORKEY_Y1"},
    {XvSettable | XvGettable,    0,           255, "XV_COLORKEY_Y2"},
    {XvSettable | XvGettable,    0,           255, "XV_COLORKEY_Y"},
    {XvSettable | XvGettable,    0,           255, "XV_Y_ALPHA"},
    {XvSettable | XvGettable,    0,           255, "XV_COLORKEY_U1"},
    {XvSettable | XvGettable,    0,           255, "XV_COLORKEY_U2"},
    {XvSettable | XvGettable,    0,           255, "XV_COLORKEY_U"},
    {XvSettable | XvGettable,    0,           255, "XV_U_ALPHA"},
    {XvSettable | XvGettable,    0,           255, "XV_COLORKEY_V1"},
    {XvSettable | XvGettable,    0,           255, "XV_COLORKEY_V2"},
    {XvSettable | XvGettable,    0,           255, "XV_COLORKEY_V"},
    {XvSettable | XvGettable,    0,           255, "XV_V_ALPHA"},
    {XvSettable | XvGettable,    0,             2, "XV_CONFIG_PATH"},
    {XvSettable | XvGettable,    0,           255, "XV_CONFIG_ALPHA"},
#endif
};

static XF86AttributeRec MixedOverlayAttributes[] =
{
    {XvSettable | XvGettable,    0,             1, "XV_ACTIVE_LCD"},
    {XvSettable | XvGettable,    0,    0xFFFFFFFF, "XV_COLORKEY"},
    {XvSettable | XvGettable,    0,             1, "XV_AUTOPAINT_COLORKEY"},
    {XvSettable | XvGettable,    0,             1, "XV_USE_GPU"},
    {XvSettable | XvGettable,    0,             1, "XV_DEINTERLACE"},
};

static XF86AttributeRec OverlayTexturedAttributes[] =
{
    {XvSettable | XvGettable,    0,             1, "XV_ACTIVE_LCD"},
    {XvSettable | XvGettable,    0,             1, "XV_DEINTERLACE"},
};

#if MRVL_XV_DEFERRED_STALL_GPU
static unsigned int     g_imagePhyAddr[2] = {0, 0};
#endif

static Bool
mrvlGeneralTransferImage(gco2D          Engine2D,
                        unsigned int    src_paddr,
                        int             src_pitch,
                        unsigned int    dst_paddr,
                        int             dst_pitch,
                        gcsRECT         *pSrcRect,
                        gcsRECT         *pDstRect,
                        gceSURF_FORMAT  srcFormat,
                        gceSURF_FORMAT  dstFormat,
                        Bool            bCheckSrc,
                        Bool            bCheckDst,
                        unsigned int    pitchAlignment,
                        unsigned int    offsetAlignment);

static Bool
mrvl_crtc_clip_video(ScrnInfoPtr pScrn,
		       xf86CrtcPtr *crtc_ret,
		       xf86CrtcPtr desired_crtc,
		       BoxPtr      dst,
		       INT32       *xa,
		       INT32       *xb,
		       INT32       *ya,
		       INT32       *yb,
		       RegionPtr   reg,
		       INT32       width,
		       INT32       height)
{
    return xf86_crtc_clip_video_helper(pScrn, crtc_ret, desired_crtc,
				       dst, xa, xb, ya, yb,
				       reg, width, height);
}

static void DovefbResetVideo(ScrnInfoPtr pScrn)
{
    /* reset settings. */
    xv_active_lcd = MAKE_ATOM("XV_ACTIVE_LCD"); /* 0x0 ~ 0xFFFFFFFF */
    xv_colorkey = MAKE_ATOM("XV_COLORKEY"); /* 0x0 ~ 0xFFFFFFFF */
    xv_autopaint_colorkey = MAKE_ATOM("XV_AUTOPAINT_COLORKEY"); /* 0 or 1 */
    xv_deinterlace = MAKE_ATOM("XV_DEINTERLACE");
    xv_use_gpu = MAKE_ATOM("XV_USE_GPU");

    xv_hue = MAKE_ATOM("XV_HUE"); /* 0 ~ 100. */
    xv_brightness = MAKE_ATOM("XV_BRIGHTNESS"); /* 0 ~ 100. */
    xv_contrast = MAKE_ATOM("XV_CONTRAST"); /* 0 ~ 100. */
    xv_saturation = MAKE_ATOM("XV_SATURATION"); /* 0 ~ 100. */

    xv_ckey_mode = MAKE_ATOM("XV_COLORKEY_MODE"); /* 0x0 ~ 0x7 */
    xv_ckey_y1 = MAKE_ATOM("XV_COLORKEY_Y1");
    xv_ckey_y2 = MAKE_ATOM("XV_COLORKEY_Y2");
    xv_ckey_y = MAKE_ATOM("XV_COLORKEY_Y");
    xv_ckey_y_alpha = MAKE_ATOM("XV_Y_ALPHA");
    xv_ckey_u1 = MAKE_ATOM("XV_COLORKEY_U1");
    xv_ckey_u2 = MAKE_ATOM("XV_COLORKEY_U2");
    xv_ckey_u = MAKE_ATOM("XV_COLORKEY_U");
    xv_ckey_u_alpha = MAKE_ATOM("XV_U_ALPHA");
    xv_ckey_v1 = MAKE_ATOM("XV_COLORKEY_V1");
    xv_ckey_v2 = MAKE_ATOM("XV_COLORKEY_V2");
    xv_ckey_v = MAKE_ATOM("XV_COLORKEY_V");
    xv_ckey_v_alpha = MAKE_ATOM("XV_V_ALPHA");
    xv_config_path = MAKE_ATOM("XV_CONFIG_PATH"); /* 0=video, 1=gfx, 2=configurable. */
    xv_config_alpha = MAKE_ATOM("XV_CONFIG_ALPHA");/* 0xFF = no graphic, 0x0 = no video */
}

static void DovefbResetOrigCKSettings(DovefbPortPrivPtr pPriv, int crtc_id)
{
    if (crtc_id < MRVL_MAX_CRTC_COUNT)
    {
        pPriv->ckey_saving[crtc_id].orig_colorkey_y = 0;
        pPriv->ckey_saving[crtc_id].orig_colorkey_u = 0;
        pPriv->ckey_saving[crtc_id].orig_colorkey_v = 0;
        pPriv->ckey_saving[crtc_id].orig_dma1       = 0;
        pPriv->ckey_saving[crtc_id].orig_reg84      = 0;
        pPriv->ckey_saving[crtc_id].valid           = FALSE;
    }
}

static void DovefbSaveOrigCKSettings(DovefbPortPrivPtr pPriv, int crtc_id, const char* mmio)
{
    if (mmio && crtc_id < MRVL_MAX_CRTC_COUNT) {
        pPriv->ckey_saving[crtc_id].orig_colorkey_y = *((unsigned int*)(mmio+COLORKEY_Y));
        pPriv->ckey_saving[crtc_id].orig_colorkey_u = *((unsigned int*)(mmio+COLORKEY_U));
        pPriv->ckey_saving[crtc_id].orig_colorkey_v = *((unsigned int*)(mmio+COLORKEY_V));
        pPriv->ckey_saving[crtc_id].orig_dma1       = *((unsigned int*)(mmio+DMA_CONTROL1));
        pPriv->ckey_saving[crtc_id].orig_reg84      = *((unsigned int*)(mmio+COLORKEY_ENA));
        pPriv->ckey_saving[crtc_id].valid           = TRUE;
    }
}

static void DovefbRestoreOrigCKSettings(DovefbPortPrivPtr pPriv, int crtc_id, const char* mmio)
{
    if (mmio &&
        crtc_id < MRVL_MAX_CRTC_COUNT &&
        pPriv->ckey_saving[crtc_id].valid)
    {
        *((unsigned int*)(mmio+COLORKEY_Y))     = pPriv->ckey_saving[crtc_id].orig_colorkey_y;
        *((unsigned int*)(mmio+COLORKEY_U))     = pPriv->ckey_saving[crtc_id].orig_colorkey_u;
        *((unsigned int*)(mmio+COLORKEY_V))     = pPriv->ckey_saving[crtc_id].orig_colorkey_v;
        *((unsigned int*)(mmio+DMA_CONTROL1))   = pPriv->ckey_saving[crtc_id].orig_dma1;
        *((unsigned int*)(mmio+COLORKEY_ENA))   = pPriv->ckey_saving[crtc_id].orig_reg84;
    }
}

static int DovefbSetDefaultValues(DovefbPortPrivPtr pPriv)
{
    //fprintf( stderr, "(II) dovefb(0): dft is 0x01, video key = 0x%x.\n", pDovefb->videoKey );
    if (!pPriv) return -1;

    pPriv->ckey_mode = 0x3;     /* Enable GFX color key. */
    pPriv->config_path = 0x1;   /* set config path. */
    pPriv->config_alpha = 0x00; /* set config alpha, 0x00 = no video */
    pPriv->UseGPU = 0x1;        /*set XV_USE_GPU to 1 by default, this will improve stability of video playback and lower cpu utilization*/
 
    return 0;
}

/*
 * Prepare video layer device handlers.
 * If there are two video layers, driver will open two device.
 */
static int PrepareResource(ScrnInfoPtr pScrn)
{
    char vid_name[16];
    int i, fb_size, on = 0;
    struct fb_fix_screeninfo    fb_finfo;
    struct shm_private_info info;
    FBDevRec* pDev = FBDEVPTR(pScrn);
    
    if (pDev->bXvResourceInitialized)
        return 0;

    pDev->vid_num = 0;
    pDev->need_adjust[0] = 0;
    pDev->need_adjust[1] = 0;

    xf86DrvMsg( pScrn->scrnIndex, X_INFO, "detecting xv devices.\n");
    for(i = 0; i < MRVL_MAX_CRTC_COUNT; i++) {
#if MRVL_PLATFORM_INFO==MRVL_DOVE
        sprintf( vid_name, "/dev/fb%d", i*2+1 );
#elif MRVL_PLATFORM_INFO==MRVL_MMP2
        sprintf( vid_name, "/dev/fb%d", i+2 ); 
#endif
            xf86DrvMsg( pScrn->scrnIndex, X_INFO,
            "try to open <%s>\n", vid_name);

        pDev->vid_fd[i] = open( vid_name, O_RDWR );

        /* open failed, try next one. */
        if (pDev->vid_fd[i] == -1)
            continue;

            xf86DrvMsg( pScrn->scrnIndex, X_INFO,
            "get <%s> FSCREENINFO.\n", vid_name);
        if (ioctl(pDev->vid_fd[i], FBIOGET_FSCREENINFO, &fb_finfo)) {
            xf86DrvMsg( pScrn->scrnIndex, X_INFO,
                "Can't get FSCREENINFO: %s\n",
                strerror(errno));
            return -1;
        }

            xf86DrvMsg( pScrn->scrnIndex, X_INFO,
            "check <%s> is video layer -- [%s].\n", vid_name, fb_finfo.id);
#if MRVL_PLATFORM_INFO==MRVL_MMP2
        /* if not video layer, search next one. */
        if ( 0 == strstr( fb_finfo.id, MMP2_VIDEO_ID )) {
            pDev->vid_fd[i] = close(pDev->vid_fd[i]);
            continue;
        }
#elif MRVL_PLATFORM_INFO==MRVL_DOVE
        /* if not video layer, search next one. */
        if ( 0 == strstr( fb_finfo.id, "Video Layer" )) {
            pDev->vid_fd[i] = close(pDev->vid_fd[i]);
            continue;
        } else if ( strstr(fb_finfo.id, "Video Layer 0"))
            pDev->need_adjust[i] = 1;
        else
            pDev->need_adjust[i] = 0;
#endif
        /* we find one video layer, get resource from it. */
        fb_size = fb_finfo.smem_len;
        pDev->fbPhyAddr[i] = fb_finfo.smem_start;
        pDev->fbPhySize[i] = fb_finfo.smem_len;

            xf86DrvMsg( pScrn->scrnIndex, X_INFO,
            "map <%s> frame buffer.\n", vid_name);
        /* 1. mmap frame buffer */
        pDev->fbPtr[i] = (char *)
            mmap(   0,
                fb_size,
                PROT_READ | PROT_WRITE, MAP_SHARED,
                pDev->vid_fd[i], 0);

        /* mmap fb error. */
        if (pDev->fbPtr[i] == (char *) -1) {
            xf86DrvMsg( pScrn->scrnIndex, X_ERROR,
                "Can't mmap %s\n", vid_name );
            return -2;
        }

            xf86DrvMsg( pScrn->scrnIndex, X_INFO,
            "map <%s> mmio.\n", vid_name);
        /* 2. mmap to mmio. */
        pDev->mmio[i] = (char *)
            mmap(   0,
                0x1C4,
                PROT_READ | PROT_WRITE, MAP_SHARED,
                pDev->vid_fd[i],
                fb_size);

        /* mmap mmio error. */
        if (pDev->mmio[i]  == (char *) -1) {
            xf86DrvMsg( pScrn->scrnIndex, X_ERROR,
                "Can't mmap %s mmio\n", vid_name );
            return -3;
        }

        xf86DrvMsg( pScrn->scrnIndex, X_INFO,
            "mmap %s mmio to 0x%08x\n", vid_name, (unsigned int)pDev->mmio[i]);

        /*
         * turn video layer off.
         */
        if (ioctl(pDev->vid_fd[i], DOVEFB_IOCTL_SWITCH_VID_OVLY, &on)) {
            xf86DrvMsg( pScrn->scrnIndex, X_ERROR,
                "Can't turn off video layer: %s\n", strerror(errno));
            return -4;
        }

        /*
         * initialize video default working mode to SHM_NORMAL.
         * It means decoded frame must be copied from user space to
         * kernel space when doing flipping frames.
         */
        info.method = SHM_NORMAL;
        ioctl(pDev->vid_fd[i], DOVEFB_IOCTL_SET_SRC_MODE, &info.method);

        pDev->vid_num++;
    }
    
    if (!pDev->bXvResourceInitialized)
    {
        pDev->bXvResourceInitialized = TRUE;
    }

    xf86DrvMsg( pScrn->scrnIndex, X_INFO, "resource checking okay.\n");
    return 0;
}

/*
 * Convert color key into registers format.
 * color key should be applied to two lcds.
*/
static Bool DovefbConvertColorkey2Regfields(ScrnInfoPtr pScrn, DovefbPortPrivPtr pPriv)
{
    Bool ret = TRUE;
    unsigned int r, g, b;
    //unsigned int r2, g2, b2;
    volatile unsigned int *ptr;
    FBDevRec* pDev = FBDEVPTR(pScrn);
    char* mmio;

    xf86DrvMsg( pScrn->scrnIndex, X_INFO, "convert colorkey to reg fields, colorkey=0x%08x\n", pPriv->colorkey);

    if(pPriv) {
            /* calc colorkey value for each fields */
        r = ((pPriv->colorkey & pScrn->mask.red) >> pScrn->offset.red);
        r = r * 0xFF / (pScrn->mask.red >> pScrn->offset.red);
        g = ((pPriv->colorkey & pScrn->mask.green) >> pScrn->offset.green);
        g = g * 0xFF / (pScrn->mask.green >> pScrn->offset.green);
        b = ((pPriv->colorkey & pScrn->mask.blue) >> pScrn->offset.blue);
        b = b * 0xFF / (pScrn->mask.blue >> pScrn->offset.blue);

        xf86DrvMsg( pScrn->scrnIndex, X_INFO, "r=0x%x, g=0x%x, b=0x%x\n", r, g, b);
    } else
        return FALSE;

    /*
     * check RB swap.
     */
    mmio = pDev->mmio[0];

    if (mmio == (char*)-1) return FALSE;
    xf86DrvMsg( pScrn->scrnIndex, X_INFO, "mmio[%d] = 0x%08x\n", 0, (unsigned int)mmio);

    ptr = (unsigned int*)(mmio+DMA_CONTROL0);
    /* check whether h/w turn on RB swap. */
    if (*ptr & 0x00001000) {
        xf86DrvMsg( pScrn->scrnIndex, X_INFO,
            "under rbswap mode..switch the rb data (%d/%d/%d)\n", r, g, b);
        /* exchange r b fields. */
        unsigned int temp;

        temp = r;
        r = b;
        b = temp;
    }

    /* store colorkey fields. */
    pPriv->ckey_y2 = pPriv->ckey_y1 = pPriv->ckey_y = r;
    pPriv->ckey_u2 = pPriv->ckey_u1 = pPriv->ckey_u = g;
    pPriv->ckey_v2 = pPriv->ckey_v1 = pPriv->ckey_v = b;

    /* alpha */
    pPriv->ckey_y_alpha = pPriv->ckey_u_alpha = pPriv->ckey_v_alpha = 0x00;
    xf86DrvMsg( pScrn->scrnIndex, X_INFO, "Finish color key conversion\n");

    return ret;
}

/* hsb should be a value between -50~50. */
static short convertHSB2Q114(short hsb, short base)
{
    hsb = ((hsb << 14) / base);
    if (hsb > 0)
        hsb = (hsb*2) - 1;
    else
        hsb = hsb*2;

    return hsb;
}

static void set_chsb(ScrnInfoPtr pScrn, DovefbPortPrivPtr pPriv, char* mmio)
{
    volatile unsigned int *ptr, x, x_bk;
    //short value;
    short hue, saturation, contrast, /*mul_s,*/ brightness;

    if ((mmio == (char*)-1) || !pPriv) return;

#if 0
    /* fill test data. */
    pPriv->hue = 60;
    pPriv->contrast = 50;
    pPriv->saturation = 85;
    pPriv->brightness = 50;
#endif
    /* calculate the value. */
    hue     = convertHSB2Q114(pPriv->hue - 50, 50);
    saturation  = convertHSB2Q114(pPriv->saturation, 100);
    contrast    = convertHSB2Q114(pPriv->contrast, 100);
    brightness  = 0xFF * (pPriv->brightness - 50) / 50;

    // If wrong, fix it.
    // It seems [31:16] is for HUE. [15:0] is for Saturation.
    // And Reg 0x1b0 [15:0] doesn't affect anything.
    // testing setting. x = (0x05a4 << 16) | 0x3fc2;
    /* HUE & Saturation. */
    ptr = (unsigned int*)(mmio + HUE_REG);
    x_bk = *ptr;

    x = ( (hue & 0x0000FFFF) << 16) | (saturation & 0x0000FFFF);
    //x = (0x05a4 << 16) | 0x3fc2;
    //fprintf(stderr, "x_bk = 0x%08x\n", x_bk);
    //fprintf(stderr, "hue & saturation = 0x%08x\n", x);
    if (x_bk != x)
        *ptr = x;

    /* CONTRAST & Brightness( +/- 0~255 ) */
    ptr = (unsigned int*)(mmio + CONTRAST_REG);
    x = x_bk = *ptr;

    x = (0x0000FFFF & brightness) << 16 | (0x0000FFFF & contrast);
    //fprintf(stderr, "x_bk = 0x%08x\n", x_bk);
    //fprintf(stderr, "brightness & contrast = 0x%08x\n", x);
    if (x_bk != x)
        *ptr = x;

    /* Multiplier.*/
    ptr = (unsigned int*)(mmio + SATURATION_REG);
    x = x_bk = *ptr;

    x = 0x20000000;
    //fprintf(stderr, "x_bk = 0x%08x\n", x_bk);
    //fprintf(stderr, "multiplier = 0x%08x\n", x);
    if (x_bk != x)
        *ptr = x;

    /* Enable CHSB */
    ptr = (unsigned int*)(mmio+DMA_CONTROL0);
    *ptr |= 0x20000000;


}

/* user pass the value 0~100. Need to transform it to hw bit field. */
static void DovefbSetCHSB(ScrnInfoPtr pScrn, DovefbPortPrivPtr pPriv)
{
    FBDevPtr pDev = FBDEVPTR(pScrn);
    char* mmio;
    int i;

    for (i = 0; i < pDev->vid_num; i++)
    {
        if (pDev->vid_fd[i] == -1)  continue;

        mmio = pDev->mmio[i];
        set_chsb(pScrn, pPriv, mmio);
    }
}

static void applyAlpha(char *mmio, DovefbPortPrivPtr pPriv, FBDevPtr pDev)
{
    volatile unsigned int *ptr, x, x_bk;

    if (mmio == (char*)-1)  return;

    /* set color key and alpha. */
    ptr = (unsigned int*)(mmio+COLORKEY_Y);
    x_bk = *ptr;
    x = (pPriv->ckey_y2 << 24) |
        (pPriv->ckey_y1 << 16) |
        (pPriv->ckey_y  << 8)  |
        pPriv->ckey_y_alpha;
        xf86DrvMsg( 0, X_INFO, "y colorkey reg = 0x%08x\n", x);
    if (x_bk != x)
        *ptr = x;

    ptr = (unsigned int*)(mmio+COLORKEY_U);
    x_bk = *ptr;
    x = (pPriv->ckey_u2 << 24) |
        (pPriv->ckey_u1 << 16) |
        (pPriv->ckey_u  << 8)  |
        pPriv->ckey_u_alpha;
        xf86DrvMsg( 0, X_INFO, "u colorkey reg = 0x%08x\n", x);
    if (x_bk != x)
        *ptr = x;
    ptr = (unsigned int*)(mmio+COLORKEY_V);
    x_bk = *ptr;
    x = (pPriv->ckey_v2 << 24) |
        (pPriv->ckey_v1 << 16) |
        (pPriv->ckey_v  << 8)  |
        pPriv->ckey_v_alpha;
        xf86DrvMsg( 0, X_INFO, "v colorkey reg = 0x%08x\n", x);
    if (x_bk != x)
        *ptr = x;

    /* configura dma ctrl1 */
    ptr = (unsigned int*)(mmio+DMA_CONTROL1);
    x_bk = *ptr;
    x = *ptr & 0xF8FC00FF;

    x |= (pPriv->ckey_mode& 0x7) << 24; /* set color key mode. */
    x |= (pPriv->config_path & 0x3) << 16;  /* set config path. */
    x |= (pPriv->config_alpha & 0xff) << 8;/* set config alpha. */

    if (x_bk != x)
        *ptr = x;

    /* enable color key in new regs. */
    ptr = (unsigned int*)(mmio + COLORKEY_ENA);
    if (pPriv->ckey_mode == 0x3) {
        *ptr |= 0x1 << 19;
    }
}

static void DovefbSetOverlayAlpha(ScrnInfoPtr pScrn, DovefbPortPrivPtr pPriv, Bool setAlpha, Bool specific )
{
    FBDevPtr pDev = FBDEVPTR(pScrn);
    char* mmio;
    int i;

    if (!pPriv) return;

    if (!setAlpha && !specific) {
        return;
    }

    /*
     * specific value will overwrite colorkey(default or
     * passed-in).
     */
    if(!specific) {
        /* convert colorkey into each fields. */
        DovefbConvertColorkey2Regfields(pScrn, pPriv);
    }

    /* apply color key and alpha settings. */
    for (i = 0; i < pDev->vid_num; i++)
    {
        if (pDev->vid_fd[i] == -1)  continue;

        mmio = pDev->mmio[i];
        applyAlpha(mmio, pPriv, pDev);
    }

}
/* ------------------------------------------
 * ------------  xv interface  ------------------
 *------------------------------------------- */

static XF86VideoAdaptorPtr
DovefbAllocAdaptor(ScrnInfoPtr pScrn, int numberPorts)
{
    XF86VideoAdaptorPtr adapt;
    FBDevPtr pDev = FBDEVPTR(pScrn);
    DovefbPortPrivPtr pPriv;
    int i;

    //fprintf(stderr, "allocate adaptor\n");
    /* allocate xv adaptor rec */
    if(!(adapt = xf86XVAllocateVideoAdaptorRec(pScrn)))
        return NULL;

    /* allocate private data structure.  */
    if(!(pPriv = xcalloc(1, sizeof(DovefbPortPrivRec) + (numberPorts * sizeof(DevUnion)))))
    {
        xfree(adapt);
        return NULL;
    }

    /* initialize port privates. */
    adapt->pPortPrivates = (DevUnion*)(&pPriv[1]);
    adapt->pPortPrivates[0].ptr = (pointer)pPriv;

    /* set default value. */
    pPriv->colorkey = pDev->videoKey;
    pPriv->textured = FALSE;
    DovefbSetDefaultValues(pPriv);

    /* Reset colorkey related registers */
    for (i = 0; i < MRVL_MAX_CRTC_COUNT; i++)
    {
        DovefbResetOrigCKSettings(pPriv, i);
    }

    pPriv->desired_crtc = NULL;

    return adapt;
}

static void
DovefbStopVideoOverlay(ScrnInfoPtr pScrn, pointer data, Bool cleanup)
{
    int i, on = 0;
    DovefbPortPrivPtr pPriv = (DovefbPortPrivPtr)data;
    struct shm_private_info info;
    FBDevRec* pDev = FBDEVPTR(pScrn);

    /* Force redrawing colorkey when stopping or moving window */
    REGION_EMPTY(pScrn->pScreen, &pPriv->clip);

    if (cleanup)
    {
        xf86DrvMsg( pScrn->scrnIndex, X_INFO, "clean up video...\n");

        /* set default value. */
        DovefbSetDefaultValues(pPriv);

        for (i = 0; i < pDev->vid_num; i++) {

            if (pDev->vid_fd[i] == -1)  continue;

            DovefbRestoreOrigCKSettings(pPriv, i, pDev->mmio[i]);

            /* turn off video layer. */
            ioctl(pDev->vid_fd[i], DOVEFB_IOCTL_SWITCH_VID_OVLY, &on);

            /* reset video layer working mode to initial value. */
            info.method = SHM_NORMAL;
            ioctl(pDev->vid_fd[i], DOVEFB_IOCTL_SET_SRC_MODE, &info.method);
        }
    }
    else
    {
        xf86DrvMsg( pScrn->scrnIndex, X_INFO, "do clipping or moving window.\n");
    }
}

static void
DovefbStopVideoMixedOverlay(ScrnInfoPtr pScrn, pointer data, Bool cleanup)
{
    int i, on = 0;
    DovefbPortPrivPtr pPriv = (DovefbPortPrivPtr)data;
    struct shm_private_info info;
    FBDevRec* pDev = FBDEVPTR(pScrn);

    /* Force redrawing colorkey when stopping or moving window */
    REGION_EMPTY(pScrn->pScreen, &pPriv->clip);

    if (cleanup)
    {
        xf86DrvMsg( pScrn->scrnIndex, X_INFO, "clean up video...\n");

        /* set default value. */
        DovefbSetDefaultValues(pPriv);

        for (i = 0; i < pDev->vid_num; i++) {

            if (pDev->vid_fd[i] == -1)  continue;

            DovefbRestoreOrigCKSettings(pPriv, i, pDev->mmio[i]);

            /* turn off video layer. */
            ioctl(pDev->vid_fd[i], DOVEFB_IOCTL_SWITCH_VID_OVLY, &on);

            /* reset video layer working mode to initial value. */
            info.method = SHM_NORMAL;
            ioctl(pDev->vid_fd[i], DOVEFB_IOCTL_SET_SRC_MODE, &info.method);
        }

        g_imagePhyAddr[0] = g_imagePhyAddr[1] = 0;
    }
    else
    {
        xf86DrvMsg( pScrn->scrnIndex, X_INFO, "do clipping or moving window.\n");
    }
}

static void
DovefbStopVideoTexture(ScrnInfoPtr pScrn, pointer data, Bool cleanup)
{
#if MRVL_XV_DEFERRED_STALL_GPU
    if (cleanup)
    {
        g_imagePhyAddr[0] = g_imagePhyAddr[1] = 0;
    }
#endif

    return;
}

static int
DovefbSetPortAttributeOverlay(
    ScrnInfoPtr pScrn,
    Atom attribute,
    INT32 value,
    pointer data
)
{
    FBDevPtr pDev = FBDEVPTR(pScrn);
    DovefbPortPrivPtr pPriv = (DovefbPortPrivPtr)data;
    Bool setAlpha = FALSE;
    Bool specific = FALSE;
    Bool chsb = FALSE;
    int  i;

    if (attribute == xv_active_lcd)
    {
	    xf86CrtcConfigPtr   xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
	    if ((value < -1) || (value > xf86_config->num_crtc))
	        return BadValue;
	    if (value < 0)
	        pPriv->desired_crtc = NULL;
	    else
	        pPriv->desired_crtc = xf86_config->crtc[value];
    }

    if (attribute == xv_colorkey) {
        //fprintf(stderr, "input colorkey = %d\n", value);
        pPriv->colorkey = ClipValue (value, 0, 0xFFFFFFFF);
        setAlpha = TRUE;
    } else if (attribute == xv_autopaint_colorkey) {
        //fprintf(stderr, "input autopaint = %d\n", value);
        pPriv->autopaint_colorkey = ClipValue (value, 0, 1);

        setAlpha = TRUE;
    }

    // Contrast, HUE, BRIGHTNESS, SATURATION
    if (attribute == xv_hue) {
        //fprintf(stderr, "input hue = %d\n", value);
        pPriv->hue = ClipValue(value, 0, 100);
        chsb = TRUE;
    } else if (attribute == xv_brightness){
        //fprintf(stderr, "input brightness = %d\n", value);
        pPriv->brightness = ClipValue(value, 0, 100);
        chsb = TRUE;
    } else if (attribute == xv_saturation) {
        //fprintf(stderr, "input saturation = %d\n", value);
        pPriv->saturation = ClipValue(value, 0, 100);
        chsb = TRUE;
    } else if (attribute == xv_contrast) {
        //fprintf(stderr, "input contrast = %d\n", value);
        pPriv->contrast = ClipValue(value, 0, 100);
        chsb = TRUE;
    }

    if (attribute == xv_ckey_mode) {
        pPriv->ckey_mode = ClipValue (value, 0, 7);
        specific = TRUE;
    }
    // Y
    if (attribute == xv_ckey_y1) {
        pPriv->ckey_y1 = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_y2) {
        pPriv->ckey_y2 = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_y) {
        pPriv->ckey_y = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_y_alpha) {
        pPriv->ckey_y_alpha = ClipValue (value, 0, 255);
        specific = TRUE;
    }
    // U
    if (attribute == xv_ckey_u1) {
        pPriv->ckey_u1 = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_u2) {
        pPriv->ckey_u2 = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_u) {
        pPriv->ckey_u = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_u_alpha) {
        pPriv->ckey_u_alpha = ClipValue (value, 0, 255);
        specific = TRUE;
    }
    // V
    if (attribute == xv_ckey_v1) {
        pPriv->ckey_v1 = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_v2) {
        pPriv->ckey_v2 = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_v) {
        pPriv->ckey_v = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_v_alpha) {
        pPriv->ckey_v_alpha = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if(attribute == xv_config_path) {
        pPriv->config_path = ClipValue (value, 0, 2);
        specific = TRUE;
    }
    if(attribute == xv_config_alpha) {
        pPriv->config_alpha = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    /* Apply new colorkey and alpha settings. */
    DovefbSetOverlayAlpha(pScrn, pPriv, setAlpha, specific);

    /* Save colorkey related registers */
    for (i = 0; i < pDev->vid_num; i++)
    {
        if (pDev->vid_fd[i] == -1)  continue;

        DovefbSaveOrigCKSettings(pPriv, i, pDev->mmio[i]);
    }

    /* Applay contrast, hue, saturation and  brightness. */
    if (chsb) {
        //fprintf(stderr, "set CHSB\n");
        DovefbSetCHSB(pScrn, pPriv);
    }

    return Success;
}

static int
DovefbSetPortAttributeMixedOverlay(
    ScrnInfoPtr pScrn,
    Atom attribute,
    INT32 value,
    pointer data
)
{
    FBDevPtr pDev = FBDEVPTR(pScrn);
    DovefbPortPrivPtr pPriv = (DovefbPortPrivPtr)data;
    Bool setAlpha = FALSE;
    Bool specific = FALSE;
    Bool chsb = FALSE;
    int  i;

    if (attribute == xv_active_lcd)
    {
	    xf86CrtcConfigPtr   xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
	    if ((value < -1) || (value > xf86_config->num_crtc))
	        return BadValue;
	    if (value < 0)
	        pPriv->desired_crtc = NULL;
	    else
	        pPriv->desired_crtc = xf86_config->crtc[value];
    }
    
    if (attribute == xv_deinterlace)
    {
        pPriv->bDeinterlace = ClipValue (value, 0, 1);
    }
    
    if (attribute == xv_use_gpu)
    {
        pPriv->UseGPU = ClipValue (value, 0, 1);
    }

    if (attribute == xv_colorkey) {
        //fprintf(stderr, "input colorkey = %d\n", value);
        pPriv->colorkey = ClipValue (value, 0, 0xFFFFFFFF);
        setAlpha = TRUE;
    } else if (attribute == xv_autopaint_colorkey) {
        //fprintf(stderr, "input autopaint = %d\n", value);
        pPriv->autopaint_colorkey = ClipValue (value, 0, 1);

        setAlpha = TRUE;
    }

    // Contrast, HUE, BRIGHTNESS, SATURATION
    if (attribute == xv_hue) {
        //fprintf(stderr, "input hue = %d\n", value);
        pPriv->hue = ClipValue(value, 0, 100);
        chsb = TRUE;
    } else if (attribute == xv_brightness){
        //fprintf(stderr, "input brightness = %d\n", value);
        pPriv->brightness = ClipValue(value, 0, 100);
        chsb = TRUE;
    } else if (attribute == xv_saturation) {
        //fprintf(stderr, "input saturation = %d\n", value);
        pPriv->saturation = ClipValue(value, 0, 100);
        chsb = TRUE;
    } else if (attribute == xv_contrast) {
        //fprintf(stderr, "input contrast = %d\n", value);
        pPriv->contrast = ClipValue(value, 0, 100);
        chsb = TRUE;
    }

    if (attribute == xv_ckey_mode) {
        pPriv->ckey_mode = ClipValue (value, 0, 7);
        specific = TRUE;
    }
    // Y
    if (attribute == xv_ckey_y1) {
        pPriv->ckey_y1 = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_y2) {
        pPriv->ckey_y2 = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_y) {
        pPriv->ckey_y = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_y_alpha) {
        pPriv->ckey_y_alpha = ClipValue (value, 0, 255);
        specific = TRUE;
    }
    // U
    if (attribute == xv_ckey_u1) {
        pPriv->ckey_u1 = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_u2) {
        pPriv->ckey_u2 = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_u) {
        pPriv->ckey_u = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_u_alpha) {
        pPriv->ckey_u_alpha = ClipValue (value, 0, 255);
        specific = TRUE;
    }
    // V
    if (attribute == xv_ckey_v1) {
        pPriv->ckey_v1 = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_v2) {
        pPriv->ckey_v2 = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_v) {
        pPriv->ckey_v = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if (attribute == xv_ckey_v_alpha) {
        pPriv->ckey_v_alpha = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    if(attribute == xv_config_path) {
        pPriv->config_path = ClipValue (value, 0, 2);
        specific = TRUE;
    }
    if(attribute == xv_config_alpha) {
        pPriv->config_alpha = ClipValue (value, 0, 255);
        specific = TRUE;
    }

    /* Apply new colorkey and alpha settings. */
    DovefbSetOverlayAlpha(pScrn, pPriv, setAlpha, specific);

    /* Save colorkey related registers */
    for (i = 0; i < pDev->vid_num; i++)
    {
        if (pDev->vid_fd[i] == -1)  continue;

        DovefbSaveOrigCKSettings(pPriv, i, pDev->mmio[i]);
    }

    /* Applay contrast, hue, saturation and  brightness. */
    if (chsb) {
        //fprintf(stderr, "set CHSB\n");
        DovefbSetCHSB(pScrn, pPriv);
    }

    return Success;
}

static int
DovefbSetPortAttributeTexture(
    ScrnInfoPtr pScrn,
    Atom attribute,
    INT32 value,
    pointer data
)
{
    DovefbPortPrivPtr pPriv = (DovefbPortPrivPtr)data;

    if (attribute == xv_active_lcd)
    {
	    xf86CrtcConfigPtr   xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
	    if ((value < -1) || (value > xf86_config->num_crtc))
	        return BadValue;
	    if (value < 0)
	        pPriv->desired_crtc = NULL;
	    else
	        pPriv->desired_crtc = xf86_config->crtc[value];
    }

    if (attribute == xv_deinterlace)
    {
        pPriv->bDeinterlace = ClipValue (value, 0, 1);
    }

    return Success;
}

static int
DovefbGetPortAttributeOverlay(
    ScrnInfoPtr pScrn,
    Atom attribute,
    INT32 *value,
    pointer data
)
{
    //FBDevPtr pDovefb = FBDEVPTR(pScrn);
    DovefbPortPrivPtr pPriv = (DovefbPortPrivPtr)data;

    if (attribute == xv_active_lcd)
    {
	    int		c;
	    xf86CrtcConfigPtr	xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
	    for (c = 0; c < xf86_config->num_crtc; c++)
	        if (xf86_config->crtc[c] == pPriv->desired_crtc)
		    break;
	    if (c == xf86_config->num_crtc)
	        c = -1;
	    *value = c;
    }
    
    if (attribute == xv_colorkey) {
        //fprintf(stderr, "get colorkey = %d\n", *value);
        *value = pPriv->colorkey;
    } else if (attribute == xv_autopaint_colorkey) {
        *value = pPriv->autopaint_colorkey;
        //fprintf(stderr, "get autopaint = %d\n", *value);
    }

    // Contrast, HUE, BRIGHTNESS, SATURATION
    if (attribute == xv_hue) {
        *value = pPriv->hue;
        //fprintf(stderr, "get hue = %d\n", *value);
    } else if (attribute == xv_brightness){
        *value = pPriv->brightness;
        //fprintf(stderr, "get brightness = %d\n", *value);
    } else if (attribute == xv_saturation) {
        *value = pPriv->saturation;
        //fprintf(stderr, "get saturation = %d\n", *value);
    } else if (attribute == xv_contrast) {
        *value = pPriv->contrast;
        //fprintf(stderr, "get constrast = %d\n", *value);
    }

    return Success;
}

static int
DovefbGetPortAttributeMixedOverlay(
    ScrnInfoPtr pScrn,
    Atom attribute,
    INT32 *value,
    pointer data
)
{
    //FBDevPtr pDovefb = FBDEVPTR(pScrn);
    DovefbPortPrivPtr pPriv = (DovefbPortPrivPtr)data;

    if (attribute == xv_active_lcd)
    {
	    int		c;
	    xf86CrtcConfigPtr	xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
	    for (c = 0; c < xf86_config->num_crtc; c++)
	        if (xf86_config->crtc[c] == pPriv->desired_crtc)
		    break;
	    if (c == xf86_config->num_crtc)
	        c = -1;
	    *value = c;
    }

    if (attribute == xv_deinterlace)
    {
        *value = pPriv->bDeinterlace;
    }

    if (attribute == xv_use_gpu)
    {
        *value = pPriv->UseGPU;
    }

    if (attribute == xv_colorkey) {
        //fprintf(stderr, "get colorkey = %d\n", *value);
        *value = pPriv->colorkey;
    } else if (attribute == xv_autopaint_colorkey) {
        *value = pPriv->autopaint_colorkey;
        //fprintf(stderr, "get autopaint = %d\n", *value);
    }

    // Contrast, HUE, BRIGHTNESS, SATURATION
    if (attribute == xv_hue) {
        *value = pPriv->hue;
        //fprintf(stderr, "get hue = %d\n", *value);
    } else if (attribute == xv_brightness){
        *value = pPriv->brightness;
        //fprintf(stderr, "get brightness = %d\n", *value);
    } else if (attribute == xv_saturation) {
        *value = pPriv->saturation;
        //fprintf(stderr, "get saturation = %d\n", *value);
    } else if (attribute == xv_contrast) {
        *value = pPriv->contrast;
        //fprintf(stderr, "get constrast = %d\n", *value);
    }

    return Success;
}

static int
DovefbGetPortAttributeTexture(
    ScrnInfoPtr pScrn,
    Atom attribute,
    INT32 *value,
    pointer data
)
{
    DovefbPortPrivPtr pPriv = (DovefbPortPrivPtr)data;

    if (attribute == xv_active_lcd)
    {
	    int		c;
	    xf86CrtcConfigPtr	xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
	    for (c = 0; c < xf86_config->num_crtc; c++)
	        if (xf86_config->crtc[c] == pPriv->desired_crtc)
		    break;
	    if (c == xf86_config->num_crtc)
	        c = -1;
	    *value = c;
    }

    if (attribute == xv_deinterlace)
    {
        *value = pPriv->bDeinterlace;
    }

    return Success;
}

static void
DovefbQueryBestSize(
    ScrnInfoPtr pScrn,
    Bool motion,
    short vid_w, short vid_h,
    short drw_w, short drw_h,
    unsigned int *p_w, unsigned int *p_h,
    pointer data
)
{
    //fprintf ( stderr,  "XV: Quest Best Size vid_w=%d, vid_h=%d, drw_w=%d, drw_h=%d\n", vid_w, vid_h, drw_w, drw_h );

    if(vid_w > drw_w) drw_w = vid_w;
    if(vid_h > drw_h) drw_h = vid_h;

    *p_w = drw_w;
    *p_h = drw_h;
}

#define BMM_SHM_MAGIC1  0x13572468
#define BMM_SHM_MAGIC2  0x24681357
#define MAX_QUEUE_NUM   60
static unsigned char* gFreeBufAddr[MAX_QUEUE_NUM];

static unsigned long shm_chksum(unsigned long *start, unsigned long *end)
{
    unsigned long n = 0;
    unsigned long *p = start;
    do {
        n ^= *p++;
    } while (p < end);
    return n;
}

static int DovefbPutImageOverlay(
    ScrnInfoPtr pScrn,
    short src_x, short src_y,
    short drw_x, short drw_y,
    short src_w, short src_h,
    short drw_w, short drw_h,
    int id, unsigned char* buf,
    short width, short height,
    Bool Sync,
    RegionPtr clipBoxes, pointer data,
    DrawablePtr pDraw
)
{
    DovefbPortPrivPtr pPriv = (DovefbPortPrivPtr)data;
    FBDevRec* pDev = FBDEVPTR(pScrn);
    int movieWidth, movieHeight;  // original movie size.
    int movieBPP;
    int movieSizeInBytes;
    int movieOffInBytes;
    int on = 1, off = 0;
    int i=0;
    INT32 xa, ya, xb, yb; /* srcClip */
    BoxRec dstBox;
    struct shm_private_info *shminfo;
    struct shm_private_info info;
    static struct _sOvlySurface gOvlySurface;               /* video overlay surface. */
    unsigned long *start;
    unsigned long *end;
    unsigned long n;
    int dx = 0, dy = 0;
    int xres, yres;
    xf86CrtcPtr crtc_ret;
    int active_crtc_id = 0;

    shminfo = (struct shm_private_info *)buf;

#if DEBUG_OVERALY_REG
    DebugRegs();
#endif

    /* calc clipping region */
    xa  = src_x;
    xb  = src_x + src_w;
    ya  = src_y;
    yb  = src_y + src_h;

    dstBox.x1 = drw_x;
    dstBox.x2 = drw_x + drw_w;
    dstBox.y1 = drw_y;
    dstBox.y2 = drw_y + drw_h;

    if (!mrvl_crtc_clip_video(pScrn, &crtc_ret, pPriv->desired_crtc,
                    &dstBox,
                    &xa, &xb, &ya, &yb,
                    clipBoxes,
                    width, height))
        return Success;

    if (!crtc_ret)
    {
        DovefbStopVideoOverlay(pScrn, data, TRUE);
        return Success;
    }

    dstBox.x1 -= crtc_ret->x;
    dstBox.x2 -= crtc_ret->x;
    dstBox.y1 -= crtc_ret->y;
    dstBox.y2 -= crtc_ret->y;

    xa >>= 16;
    xb >>= 16;
    ya >>= 16;
    yb >>= 16;

    active_crtc_id = ((MRVLCrtcPrivatePtr)crtc_ret->driver_private)->crtc_id;

    /*
     * Check whether current color key clipping is same as new or not.
     */
    if((!REGION_EQUAL(pScrn->pScreen, &pPriv->clip, clipBoxes)))
    {
        BoxPtr pbox = REGION_RECTS(clipBoxes);
        int i, nbox = REGION_NUM_RECTS(clipBoxes);
        xRectangle *rects;

        /* calc intersection. */
        REGION_COPY(pScrn->pScreen, &pPriv->clip, clipBoxes);

        if (debug_opt) {
            xf86DrvMsg( pScrn->scrnIndex, X_INFO,
                "DovefbPutImageOverlay(): clipping has changed.\n");
            xf86DrvMsg( pScrn->scrnIndex, X_INFO,
                "DovefbPutImageOverlay(): %d rects in clipboxes.\n", nbox);

            xf86DrvMsg( pScrn->scrnIndex, X_INFO,
                "DovefbPutImageOverlay(): src_x=%d, src_y=%d, src_w=%d, src_h=%d\n", src_x, src_y, src_w, src_h);
            xf86DrvMsg( pScrn->scrnIndex, X_INFO,
                "DovefbPutImageOverlay(): drw_x=%d, drw_y=%d, drw_w=%d, drw_h=%d\n", drw_x, drw_y, drw_w, drw_h);
    
            rects = malloc(sizeof(xRectangle)*nbox);

            for(i = 0; i < nbox; i++, pbox++) {
                rects[i].x = pbox->x1;
                rects[i].y = pbox->y1;
                rects[i].width = pbox->x2 - pbox->x1;
                rects[i].height = pbox->y2 - pbox->y1;
                xf86DrvMsg( pScrn->scrnIndex, X_INFO,
                    "DovefbPutImageOverlay(): box %d = (%d, %d, %d, %d)\n", i,
                    rects[i].x,
                    rects[i].y,
                    rects[i].width,
                    rects[i].height);
            }
        }

        /* if autopaint is turned on, call xf86XVFillKeyHelper to fill colorkey. */
        if(pPriv->autopaint_colorkey) {
            ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_WAIT_VSYNC, 0);
            xf86XVFillKeyHelper(pScrn->pScreen, pPriv->colorkey, clipBoxes);
        }
    }

    movieWidth                  = width;
    movieHeight                 = height;

    switch( id )
    {
        case FOURCC_YV12:
        movieBPP                    = 12;
        movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
        gTestViewPortInfo.ycPitch   = movieWidth;
        gTestViewPortInfo.uvPitch   = movieWidth / 2;
        gVidMode                    = DOVEFB_VMODE_YUV420PLANAR_SWAPUV;
        // Align X offset
        xa &= ~0x1;
        break;

        case FOURCC_I420:
        movieBPP                    = 12;
        movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
        gTestViewPortInfo.ycPitch   = movieWidth;
        gTestViewPortInfo.uvPitch   = movieWidth / 2;
        gVidMode                    = DOVEFB_VMODE_YUV420PLANAR;
        // Align X offset
        xa &= ~0x1;
        break;

        case FOURCC_UYVY:
        movieBPP                    = 16;
        movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
        gTestViewPortInfo.ycPitch   = movieWidth * 2;
        gTestViewPortInfo.uvPitch   = movieWidth;
        gVidMode                    = DOVEFB_VMODE_YUV422PACKED_SWAPYUorV;
        break;

        case FOURCC_YUY2:
        movieBPP                    = 16;
        movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
        gTestViewPortInfo.ycPitch   = movieWidth * 2;
        gTestViewPortInfo.uvPitch   = movieWidth;
        gVidMode                    = DOVEFB_VMODE_YUV422PACKED;
        break;

#if MRVL_XV_SUPPORT_RGB_FORMAT
        case FOURCC_RGB565:
        movieBPP                    = 16;
        movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
        gTestViewPortInfo.ycPitch   = movieWidth * 2;
        gTestViewPortInfo.uvPitch   = 0;
        gVidMode                    = DOVEFB_VMODE_RGB565;
        break;

        case FOURCC_RGBA32:
        movieBPP                    = 32;
        movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
        gTestViewPortInfo.ycPitch   = movieWidth * 4;
        gTestViewPortInfo.uvPitch   = 0;
        gVidMode                    = DOVEFB_VMODE_RGBA888;
        break;

        case FOURCC_RGB24:
        movieBPP                    = 24;
        movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
        gTestViewPortInfo.ycPitch   = movieWidth * 3;
        gTestViewPortInfo.uvPitch   = 0;
        gVidMode                    = DOVEFB_VMODE_RGB888PACK;
        break;
#endif

    default:
        movieSizeInBytes            = movieWidth*movieHeight*3/2;
        movieBPP                    = 12;
        gTestViewPortInfo.ycPitch   = movieWidth;
        gTestViewPortInfo.uvPitch   = movieWidth/2;
        gVidMode                    = DOVEFB_VMODE_YUV420PLANAR;
        break;
    }

    gTestViewPortInfo.srcWidth  = xb - xa;
    gTestViewPortInfo.srcHeight = yb - ya;
    gTestViewPortInfo.zoomXSize = dstBox.x2 - dstBox.x1;
    gTestViewPortInfo.zoomYSize = dstBox.y2 - dstBox.y1;
    gViewPortOffset.xOffset     = dstBox.x1;
    gViewPortOffset.yOffset     = dstBox.y1;

    movieOffInBytes = ya * gTestViewPortInfo.ycPitch + xa * movieBPP / 8;

    if (debug_opt) {
        xf86DrvMsg( pScrn->scrnIndex, X_INFO,
            "DovefbPutImageOverlay(): width=%d height=%d\n", movieWidth, movieHeight);
        xf86DrvMsg( pScrn->scrnIndex, X_INFO,
            "DovefbPutImageOverlay(): movie BPP=%d\n", movieBPP);
        xf86DrvMsg( pScrn->scrnIndex, X_INFO,
            "DovefbPutImageOverlay(): y  pitch = (%d)\n", gTestViewPortInfo.ycPitch);
        xf86DrvMsg( pScrn->scrnIndex, X_INFO,
            "DovefbPutImageOverlay(): uv pitch = (%d)\n", gTestViewPortInfo.uvPitch);
        xf86DrvMsg( pScrn->scrnIndex, X_INFO,
            "DovefbPutImageOverlay(): src size = (%d, %d)\n",
            gTestViewPortInfo.srcWidth,
            gTestViewPortInfo.srcHeight);
        xf86DrvMsg( pScrn->scrnIndex, X_INFO,
            "DovefbPutImageOverlay(): dst size = (%d, %d)\n",
            gTestViewPortInfo.zoomXSize,
            gTestViewPortInfo.zoomYSize);
        xf86DrvMsg( pScrn->scrnIndex, X_INFO,
            "DovefbPutImageOverlay(): dst pos = (%d, %d)\n",
            gViewPortOffset.xOffset,
            gViewPortOffset.xOffset);
    }
 
    /* fill frame to video buffer */
    if (buf) {
        /* Check BMM SHM */
        start = end = (unsigned long *)buf;
        if (*end++ == BMM_SHM_MAGIC1) {
            n = *end;
            end = start + 2 + n;
            if (shm_chksum(start, end) == *end) {
                info.method = SHM_VMETA;

                ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_SET_SRC_MODE, &info.method);

                gOvlySurface.videoMode          = gVidMode;
                gOvlySurface.viewPortInfo       = gTestViewPortInfo;
                gOvlySurface.viewPortOffset     = gViewPortOffset;
                gOvlySurface.videoBufferAddr.frameID    = 0;
                gOvlySurface.videoBufferAddr.startAddr  = (unsigned char *)(*(start + 2)) + movieOffInBytes;
                gOvlySurface.videoBufferAddr.inputData  = NULL;
                gOvlySurface.videoBufferAddr.length = movieSizeInBytes - movieOffInBytes;

                /* software workaround */
                if (pDev->need_adjust[active_crtc_id])
                {
                    xres = pDev->pCrtc[active_crtc_id]->mode.HDisplay;
                    yres = pDev->pCrtc[active_crtc_id]->mode.VDisplay;

                    if (xres >= 1280)
                        dx = ((xres * dstBox.x1 * 16) / (103 * src_w)) * xres / 1920;
                    if (yres >= 768)
                        dy = ((yres * dstBox.y1 * 2 * yres) / ( 10 * src_h * 1080));

                    gViewPortOffset.xOffset     = (dstBox.x1 < 0) ? 0 : (dstBox.x1 - dx);
                    gViewPortOffset.yOffset     = (dstBox.y1 < 0) ? 0 : (dstBox.y1 - dy);
                }

                // Commit our surface to LCD driver.
                if (ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_FLIP_VID_BUFFER, &gOvlySurface)) {
                    xf86DrvMsg( pScrn->scrnIndex, X_ERROR,
                        "Can't DOVEFB_IOCTL_FLIP_VID_BUFFER: %s\n", strerror(errno));
                    return BadAlloc;
                }

                /* make sure video layer is on. */
                ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_SWITCH_VID_OVLY, &on);

                /* deal with clone mode */
                if (pDev->vid_num > 1 && 
                    pDev->pCrtc[active_crtc_id]->mode.HDisplay == pScrn->virtualX &&
                    pDev->pCrtc[active_crtc_id]->mode.VDisplay == pScrn->virtualY &&
                    pDev->pCrtc[((active_crtc_id+1)%2)]->mode.HDisplay == pScrn->virtualX &&
                    pDev->pCrtc[((active_crtc_id+1)%2)]->mode.VDisplay == pScrn->virtualY )
                {
                    ioctl(pDev->vid_fd[((active_crtc_id+1)%2)], DOVEFB_IOCTL_SWITCH_VID_OVLY, &on);
                    ioctl(pDev->vid_fd[((active_crtc_id+1)%2)], DOVEFB_IOCTL_FLIP_VID_BUFFER, &gOvlySurface);
                }
                else if (pDev->vid_num > 1)
                {
                    ioctl(pDev->vid_fd[((active_crtc_id+1)%2)], DOVEFB_IOCTL_SWITCH_VID_OVLY, &off);
                }

                /* collect free buffer list */
                memset( gFreeBufAddr, 0, MAX_QUEUE_NUM *sizeof(unsigned char*));

                ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_GET_FREELIST, &gFreeBufAddr);

                n = 0;
                end = start;
                *end++ = BMM_SHM_MAGIC2;
                *end++ = 0;
                for(i=0; i<MAX_QUEUE_NUM; i++ ) {
                    if (0 == gFreeBufAddr[i])
                        continue;

                    n++;
                    *end++ = (unsigned long)gFreeBufAddr[i];
                    gFreeBufAddr[i] = 0;
                }
                *(start + 1) = n;
                *end = shm_chksum(start, end);

                return Success;
            }
        } else if (*start == BMM_SHM_MAGIC2){
            end = start;
            n = *(end + 1);

            end = start + 2 + n;
            if (shm_chksum(start, end) == *end) {
                /*
                 * Application might forget to fill BMM_SHM_MAGIC1. 
                 * We treat it as reuseing same buffer. Hence, we 
                 * do nothing here.
                 */
                return Success;
            }
            /* Not reusing cause, go to fallback flow. */
        }

        /* which kind of src we receive. */
        ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_GET_SRC_MODE, &info.method);
#if MRVL_PLATFORM_INFO==MRVL_MMP2
        info.method = SHM_NORMAL;
#endif
        if (SHM_NORMAL != info.method) {
            info = *shminfo;
            info.width = movieWidth;
            info.height = movieHeight;
        }

        if (info.method == SHM_SOFTWARE_MAP) {
            ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_GET_FBPA, &info);
        }

        if (info.method == SHM_VMETA) {
            /* Not call vMeta memory management API directly anymore.
             * Program should not go here. Please check user application's
             * call sequence.
             */
        }

        gOvlySurface.videoMode          = gVidMode;
        gOvlySurface.viewPortInfo       = gTestViewPortInfo;
        gOvlySurface.viewPortOffset     = gViewPortOffset;
        gOvlySurface.videoBufferAddr.frameID    = info.fbid;
        gOvlySurface.videoBufferAddr.startAddr  = (unsigned char*)info.fb_pa + movieOffInBytes;
        gOvlySurface.videoBufferAddr.inputData  = 0;
        gOvlySurface.videoBufferAddr.length = movieSizeInBytes - movieOffInBytes;

        if (info.method == SHM_NORMAL) {
            gOvlySurface.videoBufferAddr.frameID    = 0;
            gOvlySurface.videoBufferAddr.startAddr  = 0;

            memcpy(pDev->fbPtr[active_crtc_id], (buf + movieOffInBytes), (movieSizeInBytes - movieOffInBytes));
        }

        /* software workaround */
        if (pDev->need_adjust[active_crtc_id])
        {
            xres = pDev->pCrtc[active_crtc_id]->mode.HDisplay;
            yres = pDev->pCrtc[active_crtc_id]->mode.VDisplay;

            if (xres >= 1280)
                dx = ((xres * dstBox.x1 * 16) / (103 * src_w)) * xres / 1920;
            if (yres >= 768)
                dy = ((yres * dstBox.y1 * 2 * yres) / ( 10 * src_h * 1080));

            gViewPortOffset.xOffset     = (dstBox.x1 < 0) ? 0 : (dstBox.x1 - dx);
            gViewPortOffset.yOffset     = (dstBox.y1 < 0) ? 0 : (dstBox.y1 - dy);
        }

        ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_FLIP_VID_BUFFER, &gOvlySurface);

        /* make sure video layer is on. */
        ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_SWITCH_VID_OVLY, &on);

        /* deal with clone mode */
        if (pDev->vid_num > 1 && 
            pDev->pCrtc[active_crtc_id]->mode.HDisplay == pScrn->virtualX &&
            pDev->pCrtc[active_crtc_id]->mode.VDisplay == pScrn->virtualY &&
            pDev->pCrtc[((active_crtc_id+1)%2)]->mode.HDisplay == pScrn->virtualX &&
            pDev->pCrtc[((active_crtc_id+1)%2)]->mode.VDisplay == pScrn->virtualY )
        {
            ioctl(pDev->vid_fd[((active_crtc_id+1)%2)], DOVEFB_IOCTL_SWITCH_VID_OVLY, &on);
            ioctl(pDev->vid_fd[((active_crtc_id+1)%2)], DOVEFB_IOCTL_FLIP_VID_BUFFER, &gOvlySurface);
        }
        else if (pDev->vid_num > 1)
        {
            ioctl(pDev->vid_fd[((active_crtc_id+1)%2)], DOVEFB_IOCTL_SWITCH_VID_OVLY, &off);
        }

    } else {
            xf86DrvMsg( pScrn->scrnIndex, X_ERROR, "xv data buf is NULL!!\n" );
    }

    return Success;
}

static int DovefbPutImageMixedOverlay(
    ScrnInfoPtr pScrn,
    short src_x, short src_y,
    short drw_x, short drw_y,
    short src_w, short src_h,
    short drw_w, short drw_h,
    int id, unsigned char* buf,
    short width, short height,
    Bool Sync,
    RegionPtr clipBoxes, pointer data,
    DrawablePtr pDraw
)
{
    DovefbPortPrivPtr pPriv = (DovefbPortPrivPtr)data;
    FBDevRec* pDev = FBDEVPTR(pScrn);
    int movieWidth, movieHeight;  // original movie size.
    int movieBPP;
    static int movieSizeInBytes;
    static unsigned int movieOffInBytes;
    int on = 1, off = 0;
    int i=0;
    INT32 xa, ya, xb, yb; /* srcClip */
    BoxRec dstBox;
    struct shm_private_info *shminfo;
    struct shm_private_info info;
    static struct _sOvlySurface gOvlySurface;               /* video overlay surface. */
    unsigned long *start = NULL;
    unsigned long *end = NULL;
    unsigned long n;
    int dx = 0, dy = 0;
    int xres, yres;
    xf86CrtcPtr crtc_ret;
    int active_crtc_id = 0;
    Bool            bNeedConvert = FALSE, bBmmBuffer = FALSE;
    unsigned int    dwYAddr = 0, dwYStride = 0, dwUAddr = 0, dwUStride = 0, dwVAddr = 0, dwVStride = 0, dwUOff = 0, dwVOff = 0;
    gceSURF_FORMAT  conSrcFormat = 0;
    static unsigned int    conDstAddr = 0;
    gceSTATUS       status;
    unsigned int    src_paddr;
    int                 map_src_pitch = 0;
    void              *mapInfo;
    static int      savedUseGPU = 0;
    static unsigned int    flipIndex = 0;
    static unsigned int    convert_width = 0, convert_height = 0;
    static struct _sViewPortInfo    last_gTestViewPortInfo;
    static struct _sViewPortOffset  last_gViewPortOffset;
    static DOVEFBVideoMode          last_gVidMode;
    Bool                            b_defered_gpu_stall = FALSE;
    unsigned int                    max_frame_count = 0;
    gceSURF_FORMAT                  non_bmm_src_fmt = 0;
    #define FRAME_WIDTH  1920
    #define FRAME_HEIGHT 1080
    #define GPU_BLIT_BPP 16

    shminfo = (struct shm_private_info *)buf;

#if DEBUG_OVERALY_REG
    DebugRegs();
#endif

    /* calc clipping region */
    xa  = src_x;
    xb  = src_x + src_w;
    ya  = src_y;
    yb  = src_y + src_h;

    dstBox.x1 = drw_x;
    dstBox.x2 = drw_x + drw_w;
    dstBox.y1 = drw_y;
    dstBox.y2 = drw_y + drw_h;

    if (!mrvl_crtc_clip_video(pScrn, &crtc_ret, pPriv->desired_crtc,
                    &dstBox,
                    &xa, &xb, &ya, &yb,
                    clipBoxes,
                    width, height))
        return Success;

    if (!crtc_ret)
    {
        DovefbStopVideoOverlay(pScrn, data, TRUE);
        return Success;
    }

    dstBox.x1 -= crtc_ret->x;
    dstBox.x2 -= crtc_ret->x;
    dstBox.y1 -= crtc_ret->y;
    dstBox.y2 -= crtc_ret->y;

    xa >>= 16;
    xb >>= 16;
    ya >>= 16;
    yb >>= 16;

    active_crtc_id = ((MRVLCrtcPrivatePtr)crtc_ret->driver_private)->crtc_id;
    
    savedUseGPU = pPriv->UseGPU;
    
    convert_width               = MEM_PAGE_ALIGN_UP(drw_w, 16);
    convert_height              = MEM_PAGE_ALIGN_UP(drw_h, 16);

    // Destination output memory for GPU is limited to 1920 x 1080. 
    // So when the mode is beyond this scope, we need to resize the resolution of color convert.
    convert_width   = min(convert_width,  FRAME_WIDTH);
    convert_height  = min(convert_height, FRAME_HEIGHT);
    
    // Overlay can not do de-interlace, force to enable GPU path.
    if (pPriv->bDeinterlace)
    {
        pPriv->UseGPU = 1;    
    }
    
    if (pDev->fbPhySize[active_crtc_id])
        max_frame_count = pDev->fbPhySize[active_crtc_id] / (FRAME_WIDTH * FRAME_HEIGHT * 2);

    if (max_frame_count == 0)
    {
        // can not use GPU path.
        pPriv->UseGPU = 0;    
    }
    else if (max_frame_count >= 1 && max_frame_count <= 2)
    {
        // one or two buffers can not fix tearing issue with defered gpu mode.
        b_defered_gpu_stall = FALSE;
    }
    else 
    {
        b_defered_gpu_stall = TRUE;
    }    
    
    /*
     * Check whether current color key clipping is same as new or not.
     */
    if((!REGION_EQUAL(pScrn->pScreen, &pPriv->clip, clipBoxes)))
    {      
        /* calc intersection. */
        REGION_COPY(pScrn->pScreen, &pPriv->clip, clipBoxes);

        /* if autopaint is turned on, call xf86XVFillKeyHelper to fill colorkey. */
        if(pPriv->autopaint_colorkey) {
            ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_WAIT_VSYNC, 0);
            xf86XVFillKeyHelper(pScrn->pScreen, pPriv->colorkey, clipBoxes);
        }
    }    
    
    if(pPriv->UseGPU)
    {
        start = end = (unsigned long *)buf;
        if (*end++ == BMM_SHM_MAGIC1) {
            /* BMM SHM PATH */
            n = *end;
            end = start + 2 + n;
            if (shm_chksum(start, end) == *end)
            {
                dwYAddr = (unsigned int)(*(start + 2));
                bBmmBuffer = TRUE;
    
                if (b_defered_gpu_stall)
                {
                    if (g_imagePhyAddr[0] == 0 )
                    {
                        g_imagePhyAddr[0] = dwYAddr;
                    }
                    else
                    {
                        g_imagePhyAddr[1] = g_imagePhyAddr[0];
                        g_imagePhyAddr[0] = dwYAddr;
        				
        		        // Make sure last frame is finished through GPU.
                        mrvlFencePoolStall(pDev->pXVScreenFence);                                                      
    
                        gOvlySurface.videoMode          = last_gVidMode;
                        gOvlySurface.viewPortInfo       = last_gTestViewPortInfo;
                        gOvlySurface.viewPortOffset     = last_gViewPortOffset;                        
                        gOvlySurface.videoBufferAddr.frameID    = 0;
                        gOvlySurface.videoBufferAddr.startAddr  = (unsigned char *)conDstAddr + movieOffInBytes;
                        gOvlySurface.videoBufferAddr.inputData  = 0;
                        gOvlySurface.videoBufferAddr.length = (movieSizeInBytes - movieOffInBytes);
    
                        ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_FLIP_VID_BUFFER, &gOvlySurface);

                        ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_SWITCH_VID_OVLY, &on); 
                
                        if (pDev->vid_num > 1 && 
                            pDev->pCrtc[active_crtc_id]->mode.HDisplay == pScrn->virtualX &&
                            pDev->pCrtc[active_crtc_id]->mode.VDisplay == pScrn->virtualY &&
                            pDev->pCrtc[((active_crtc_id+1)%2)]->mode.HDisplay == pScrn->virtualX &&
                            pDev->pCrtc[((active_crtc_id+1)%2)]->mode.VDisplay == pScrn->virtualY )
                        {
                            ioctl(pDev->vid_fd[((active_crtc_id+1)%2)], DOVEFB_IOCTL_SWITCH_VID_OVLY, &on);
                                
                            ioctl(pDev->vid_fd[((active_crtc_id+1)%2)], DOVEFB_IOCTL_FLIP_VID_BUFFER, &gOvlySurface);
                        }
                        else if (pDev->vid_num > 1)
                        {
                            ioctl(pDev->vid_fd[((active_crtc_id+1)%2)], DOVEFB_IOCTL_SWITCH_VID_OVLY, &off);
                        }                    
                    }
                }
            }
            else
            {
                xf86DrvMsg(0, X_ERROR, "PutTexturedVideo: Invalid shm buffer info\n");
                pPriv->UseGPU = savedUseGPU;
                return Success;
            }
        }
        else
        {
            bBmmBuffer = FALSE;

            switch(id)
            {
            case FOURCC_YV12:
            case FOURCC_I420:
                map_src_pitch = width *  12 / 8;
                break;
            
            case FOURCC_UYVY:
            case FOURCC_YUY2:
            case FOURCC_RGB565:
                map_src_pitch = width * 2;
                break;
            case FOURCC_RGBA32:
                map_src_pitch = width * 4;
                break;            
            default:
                xf86DrvMsg(0, X_ERROR, "PutMixedVideo: Invalid non-bmm buffer format\n");
                return Success;
            }
            
            status = gcoOS_MapUserMemory(pDev->exaInfo.Os, buf, map_src_pitch * height, &mapInfo, &src_paddr);
            if (status != gcvSTATUS_OK)
            {
                // fallback to overlay path.
                xf86DrvMsg(0, X_ERROR, "PutMixedVideo: Failed to map user memory\n");
                pPriv->UseGPU = 0;
            }
            else
            {
                dwYAddr = src_paddr;
                pPriv->UseGPU = 1;
                b_defered_gpu_stall = FALSE;
            }
        }        
    }

    movieWidth                  = width;
    movieHeight                 = height;    

    switch( id )
    {
        case FOURCC_YV12:
        {
            if(!pPriv->UseGPU)
            {
                movieBPP                    = 12;
                movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
                gTestViewPortInfo.ycPitch   = movieWidth;
                gTestViewPortInfo.uvPitch   = movieWidth / 2;
                gVidMode                    = DOVEFB_VMODE_YUV420PLANAR_SWAPUV;
            }
            else
            {
                movieBPP                    = 12;
                movieSizeInBytes            = convert_width * convert_height * pScrn->bitsPerPixel / 8;
                bNeedConvert                = TRUE;
        
                dwVOff                      = movieWidth * movieHeight;
                dwUOff                      = dwVOff + (dwVOff / 4);
        
                dwUAddr                     = dwYAddr + dwUOff;
                dwVAddr                     = dwYAddr + dwVOff;
                dwYStride                   = movieWidth;
                dwUStride                   = movieWidth / 2;
                dwVStride                   = movieWidth / 2;
        
                conSrcFormat                = gcvSURF_YV12;
                
                gTestViewPortInfo.ycPitch   = convert_width * GPU_BLIT_BPP / 8;
                gTestViewPortInfo.uvPitch   = 0;
                gVidMode                    = DOVEFB_VMODE_RGB565;
            }
            
            // Align X offset
            xa &= ~0x1;
            
            break;
        }

        case FOURCC_I420:
        {
            if(!pPriv->UseGPU)
            {
                movieBPP                    = 12;
                movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
                gTestViewPortInfo.ycPitch   = movieWidth;
                gTestViewPortInfo.uvPitch   = movieWidth / 2;
                gVidMode                    = DOVEFB_VMODE_YUV420PLANAR;
            }
            else
            {
                movieBPP                    = 12;
                movieSizeInBytes            = convert_width * convert_height * pScrn->bitsPerPixel / 8;
                bNeedConvert                = TRUE;
        
                dwUOff                      = movieWidth * movieHeight;
                dwVOff                      = dwUOff + (dwUOff / 4);
        
                dwUAddr                     = dwYAddr + dwUOff;
                dwVAddr                     = dwYAddr + dwVOff;
                dwYStride                   = movieWidth;
                dwUStride                   = movieWidth / 2;
                dwVStride                   = movieWidth / 2;
        
                conSrcFormat                = gcvSURF_I420;
                
                gTestViewPortInfo.ycPitch   = convert_width * GPU_BLIT_BPP / 8;
                gTestViewPortInfo.uvPitch   = 0;
                gVidMode                    = DOVEFB_VMODE_RGB565;
            }
            
            // Align X offset
            xa &= ~0x1;
            break;
        }
    
        case FOURCC_UYVY:
        {
            if(!pPriv->UseGPU)
            {
                movieBPP                    = 16;
                movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
                gTestViewPortInfo.ycPitch   = movieWidth * 2;
                gTestViewPortInfo.uvPitch   = movieWidth;
                gVidMode                    = DOVEFB_VMODE_YUV422PACKED_SWAPYUorV;
            }
            else
            {
                movieBPP                    = 16;
                movieSizeInBytes            = convert_width * convert_height * pScrn->bitsPerPixel / 8;
                bNeedConvert                = TRUE;
        
                dwUOff                      = 0;
                dwVOff                      = 0;
        
                dwUAddr                     = dwYAddr + dwUOff;
                dwVAddr                     = dwYAddr + dwVOff;
                dwYStride                   = movieWidth * movieBPP / 8;
                dwUStride                   = movieWidth;
                dwVStride                   = movieWidth;
        
                conSrcFormat                = gcvSURF_UYVY;
                
                gTestViewPortInfo.ycPitch   = convert_width * GPU_BLIT_BPP / 8;
                gTestViewPortInfo.uvPitch   = 0;
                gVidMode                    = DOVEFB_VMODE_RGB565;
            }
        
            break;
        }

        case FOURCC_YUY2:
        {
            if(!pPriv->UseGPU)
            {
                movieBPP                    = 16;
                movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
                gTestViewPortInfo.ycPitch   = movieWidth * 2;
                gTestViewPortInfo.uvPitch   = movieWidth;
                gVidMode                    = DOVEFB_VMODE_YUV422PACKED;
            }
            else
            {
                movieBPP                    = 16;
                movieSizeInBytes            = convert_width * convert_height * pScrn->bitsPerPixel / 8;
                bNeedConvert                = TRUE;
        
                dwUOff                      = 0;
                dwVOff                      = 0;
        
                dwUAddr                     = dwYAddr + dwUOff;
                dwVAddr                     = dwYAddr + dwVOff;
                dwYStride                   = movieWidth * movieBPP / 8;
                dwUStride                   = 0;
                dwVStride                   = 0;
        
                conSrcFormat                = gcvSURF_YUY2;
                
                gTestViewPortInfo.ycPitch   = convert_width * GPU_BLIT_BPP / 8;
                gTestViewPortInfo.uvPitch   = 0;
                gVidMode                    = DOVEFB_VMODE_RGB565;
            }
        
            break;
        }

#if MRVL_XV_SUPPORT_RGB_FORMAT
        case FOURCC_RGB565:
        {
            if(!pPriv->UseGPU)
            {
                movieBPP                    = 16;
                movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
                gTestViewPortInfo.ycPitch   = movieWidth * 2;
                gTestViewPortInfo.uvPitch   = 0;
                gVidMode                    = DOVEFB_VMODE_RGB565;
            }
            else
            {       
                convert_height              = movieHeight;
                movieBPP                    = 16;
                movieSizeInBytes            = convert_width * convert_height * movieBPP / 8;
                gTestViewPortInfo.ycPitch   = convert_width * 2;
                gTestViewPortInfo.uvPitch   = 0;
                gVidMode                    = DOVEFB_VMODE_RGB565;
                non_bmm_src_fmt             = gcvSURF_R5G6B5;
            }
          
            break;
        }

        case FOURCC_RGBA32:
        {
            if(!pPriv->UseGPU)
            {
                movieBPP                    = 32;
                movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
                gTestViewPortInfo.ycPitch   = movieWidth * 4;
                gTestViewPortInfo.uvPitch   = 0;
                gVidMode                    = DOVEFB_VMODE_RGBA888;
            }
            else
            {
                convert_height              = movieHeight;
                movieBPP                    = 16;
                movieSizeInBytes            = convert_width * convert_height * movieBPP / 8;
                gTestViewPortInfo.ycPitch   = convert_width * 2;
                gTestViewPortInfo.uvPitch   = 0;
                gVidMode                    = DOVEFB_VMODE_RGB565;
                non_bmm_src_fmt             = gcvSURF_A8R8G8B8;            
            }
            break;
        }

        case FOURCC_RGB24:
        {
            movieBPP                    = 24;
            movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
            gTestViewPortInfo.ycPitch   = movieWidth * 3;
            gTestViewPortInfo.uvPitch   = 0;
            gVidMode                    = DOVEFB_VMODE_RGB888PACK;            
            break;
        }
#endif

    default:
        xf86DrvMsg(0, X_ERROR, "PutMixedVideo: Invalid image format\n");
        pPriv->UseGPU = savedUseGPU;
        return Success;
    }       
    
    if (pPriv->UseGPU)
    {
        gcsRECT         conSrcRect, conDstRect;

        conDstAddr = pDev->fbPhyAddr[active_crtc_id] + flipIndex * FRAME_WIDTH * FRAME_HEIGHT * 2;       

        conSrcRect.left     = 0;
        conSrcRect.top      = 0;
        conSrcRect.right    = width;
        conSrcRect.bottom   = height;

        conDstRect.left     = 0;
        conDstRect.top      = 0;
        conDstRect.right    = convert_width;
        conDstRect.bottom   = convert_height;

        if (pPriv->bDeinterlace && bNeedConvert)
        {
            conSrcRect.bottom   /= 2;
            dwYStride           *= 2;
            dwUStride           *= 2;
            dwVStride           *= 2;
        }

        status = gco2D_SetClipping(pDev->exaInfo.Engine2D, &conDstRect);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "PutMixedVideo: Failed to set clipping, %d line\n", __LINE__);
            pPriv->UseGPU = savedUseGPU;
            return Success;
        }

        if (bNeedConvert)
        {
            status = gco2D_SetKernelSize(pDev->exaInfo.Engine2D, 1, 1);
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "PutMixedVideo: Failed to set kernel size, %d line\n", __LINE__);
                pPriv->UseGPU = savedUseGPU;
                return Success;
            }

            status = gco2D_FilterBlit(pDev->exaInfo.Engine2D,
                                    dwYAddr,
                                    dwYStride,
                                    dwUAddr,
                                    dwUStride,
                                    dwVAddr,
                                    dwVStride,
                                    conSrcFormat,
                                    gcvSURF_0_DEGREE,
                                    width,
                                    &conSrcRect,
                                    conDstAddr,
                                    convert_width * 2,
                                    gcvSURF_R5G6B5,
                                    gcvSURF_0_DEGREE,
                                    convert_width,
                                    &conDstRect,
                                    &conDstRect);
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "PutMixedVideo: Failed to do filter blit, %d line\n", __LINE__);
                pPriv->UseGPU = savedUseGPU;
                return Success;
            }
        }
        else
        {
            if (!mrvlGeneralTransferImage(pDev->exaInfo.Engine2D,
                                        src_paddr,
                                        map_src_pitch,
                                        conDstAddr,
                                        convert_width * 2,
                                        &conSrcRect,
                                        &conDstRect,
                                        non_bmm_src_fmt,
                                        gcvSURF_R5G6B5,
                                        TRUE,
                                        FALSE,
                                        32,
                                        64))
            {
                xf86DrvMsg(0, X_ERROR, "PutMixedVideo: General image transfer failed\n");
            }
        }
        
        if(bBmmBuffer && b_defered_gpu_stall)
        {        
            mrvlFencePoolKickOff(pDraw->pScreen, pDev->pXVScreenFence);
        }
        else
	    {
            mrvlFencePoolKickOff(pDraw->pScreen, pDev->pXVScreenFence);
            mrvlFencePoolStall(pDev->pXVScreenFence); 
        }

        flipIndex++;
        flipIndex = flipIndex % max_frame_count;        
    }  

    gTestViewPortInfo.srcWidth  = (!pPriv->UseGPU) ? xb - xa : (xb - xa) * convert_width / width;
    gTestViewPortInfo.srcHeight = (!pPriv->UseGPU) ? yb - ya : (yb - ya) * convert_height / height;
    gTestViewPortInfo.zoomXSize = dstBox.x2 - dstBox.x1;
    gTestViewPortInfo.zoomYSize = dstBox.y2 - dstBox.y1;
    gViewPortOffset.xOffset     = dstBox.x1;
    gViewPortOffset.yOffset     = dstBox.y1;

    if (pPriv->UseGPU)
    {
        int con_ya, con_xa;

        con_xa = convert_width * xa / width;
        con_ya = convert_height * ya / height;

        movieOffInBytes = con_ya * gTestViewPortInfo.ycPitch + con_xa * pScrn->bitsPerPixel / 8;
    }
    else
    {
        movieOffInBytes = ya * gTestViewPortInfo.ycPitch + xa * movieBPP / 8;
    }

    /* fill frame to video buffer */
    if ( buf && (!pPriv->UseGPU || (pPriv->UseGPU && !b_defered_gpu_stall))) 
    {
        /* Check BMM SHM */        
        if (!pPriv->UseGPU)
        {
            start = end = (unsigned long *)buf;
            if (*end++ == BMM_SHM_MAGIC1) {
                n = *end;
                end = start + 2 + n;
                if (shm_chksum(start, end) == *end) {
                    info.method = SHM_VMETA;
    
                    ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_SET_SRC_MODE, &info.method);
    
                    gOvlySurface.videoMode          = gVidMode;
                    gOvlySurface.viewPortInfo       = gTestViewPortInfo;
                    gOvlySurface.viewPortOffset     = gViewPortOffset;
                    gOvlySurface.videoBufferAddr.frameID    = 0;
                    gOvlySurface.videoBufferAddr.startAddr  = (unsigned char *)(*(start + 2)) + movieOffInBytes;
                    gOvlySurface.videoBufferAddr.inputData  = NULL;
                    gOvlySurface.videoBufferAddr.length = movieSizeInBytes - movieOffInBytes;
    
                    /* software workaround */
                    if (pDev->need_adjust[active_crtc_id])
                    {
                        xres = pDev->pCrtc[active_crtc_id]->mode.HDisplay;
                        yres = pDev->pCrtc[active_crtc_id]->mode.VDisplay;
    
                        if (xres >= 1280)
                            dx = ((xres * dstBox.x1 * 16) / (103 * src_w)) * xres / 1920;
                        if (yres >= 768)
                            dy = ((yres * dstBox.y1 * 2 * yres) / ( 10 * src_h * 1080));
    
                        gViewPortOffset.xOffset     = (dstBox.x1 < 0) ? 0 : (dstBox.x1 - dx);
                        gViewPortOffset.yOffset     = (dstBox.y1 < 0) ? 0 : (dstBox.y1 - dy);
                    }
    
                    // Commit our surface to LCD driver.
                    if (ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_FLIP_VID_BUFFER, &gOvlySurface)) {
                        xf86DrvMsg( pScrn->scrnIndex, X_ERROR,
                            "Can't DOVEFB_IOCTL_FLIP_VID_BUFFER: %s\n", strerror(errno));
                        pPriv->UseGPU = savedUseGPU;
                        return BadAlloc;
                    }
    
                    /* make sure video layer is on. */
                    ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_SWITCH_VID_OVLY, &on);
    
                    /* deal with clone mode */
                    if (pDev->vid_num > 1 && 
                        pDev->pCrtc[active_crtc_id]->mode.HDisplay == pScrn->virtualX &&
                        pDev->pCrtc[active_crtc_id]->mode.VDisplay == pScrn->virtualY &&
                        pDev->pCrtc[((active_crtc_id+1)%2)]->mode.HDisplay == pScrn->virtualX &&
                        pDev->pCrtc[((active_crtc_id+1)%2)]->mode.VDisplay == pScrn->virtualY )
                    {
                        ioctl(pDev->vid_fd[((active_crtc_id+1)%2)], DOVEFB_IOCTL_SWITCH_VID_OVLY, &on);
                        ioctl(pDev->vid_fd[((active_crtc_id+1)%2)], DOVEFB_IOCTL_FLIP_VID_BUFFER, &gOvlySurface);
                    }
                    else if (pDev->vid_num > 1)
                    {
                        ioctl(pDev->vid_fd[((active_crtc_id+1)%2)], DOVEFB_IOCTL_SWITCH_VID_OVLY, &off);
                    }
    
                    /* collect free buffer list */
                    memset( gFreeBufAddr, 0, MAX_QUEUE_NUM *sizeof(unsigned char*));
    
                    ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_GET_FREELIST, &gFreeBufAddr);
    
                    n = 0;
                    end = start;
                    *end++ = BMM_SHM_MAGIC2;
                    *end++ = 0;
                    for(i=0; i<MAX_QUEUE_NUM; i++ ) {
                        if (0 == gFreeBufAddr[i])
                            continue;
    
                        n++;
                        *end++ = (unsigned long)gFreeBufAddr[i];
                        gFreeBufAddr[i] = 0;
                    }
                    *(start + 1) = n;
                    *end = shm_chksum(start, end);
    
                    pPriv->UseGPU = savedUseGPU;
                    
                    return Success;
                }
            } else if (*start == BMM_SHM_MAGIC2){
                end = start;
                n = *(end + 1);
    
                end = start + 2 + n;
                if (shm_chksum(start, end) == *end) {
                    /*
                     * Application might forget to fill BMM_SHM_MAGIC1. 
                     * We treat it as reuseing same buffer. Hence, we 
                     * do nothing here.
                     */
                    pPriv->UseGPU = savedUseGPU;
                    return Success;
                }
                /* Not reusing cause, go to fallback flow. */
            }
        }

        gOvlySurface.videoMode          = gVidMode;
        gOvlySurface.viewPortInfo       = gTestViewPortInfo;
        gOvlySurface.viewPortOffset     = gViewPortOffset;
        gOvlySurface.videoBufferAddr.frameID    = 0;
        gOvlySurface.videoBufferAddr.startAddr  = (!pPriv->UseGPU) ? (void *)(pDev->fbPhyAddr[active_crtc_id]+movieOffInBytes) : (void *)(conDstAddr + movieOffInBytes);
        gOvlySurface.videoBufferAddr.inputData  = 0;
        gOvlySurface.videoBufferAddr.length = (!pPriv->UseGPU) ? 0 : (movieSizeInBytes - movieOffInBytes);

        if (!pPriv->UseGPU) {
            memcpy(pDev->fbPtr[active_crtc_id], (buf + movieOffInBytes), (movieSizeInBytes - movieOffInBytes));
        }

        /* software workaround */
        if (pDev->need_adjust[active_crtc_id])
        {
            xres = pDev->pCrtc[active_crtc_id]->mode.HDisplay;
            yres = pDev->pCrtc[active_crtc_id]->mode.VDisplay;

            if (xres >= 1280)
                dx = ((xres * dstBox.x1 * 16) / (103 * src_w)) * xres / 1920;
            if (yres >= 768)
                dy = ((yres * dstBox.y1 * 2 * yres) / ( 10 * src_h * 1080));

            gViewPortOffset.xOffset     = (dstBox.x1 < 0) ? 0 : (dstBox.x1 - dx);
            gViewPortOffset.yOffset     = (dstBox.y1 < 0) ? 0 : (dstBox.y1 - dy);
        }

        ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_FLIP_VID_BUFFER, &gOvlySurface);

        /* make sure video layer is on. */
        ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_SWITCH_VID_OVLY, &on);
        
        /* deal with clone mode */
        if (pDev->vid_num > 1 && 
            pDev->pCrtc[active_crtc_id]->mode.HDisplay == pScrn->virtualX &&
            pDev->pCrtc[active_crtc_id]->mode.VDisplay == pScrn->virtualY &&
            pDev->pCrtc[((active_crtc_id+1)%2)]->mode.HDisplay == pScrn->virtualX &&
            pDev->pCrtc[((active_crtc_id+1)%2)]->mode.VDisplay == pScrn->virtualY )
        {
            ioctl(pDev->vid_fd[((active_crtc_id+1)%2)], DOVEFB_IOCTL_SWITCH_VID_OVLY, &on);
                
            ioctl(pDev->vid_fd[((active_crtc_id+1)%2)], DOVEFB_IOCTL_FLIP_VID_BUFFER, &gOvlySurface);
        }
        else if (pDev->vid_num > 1)
        {
            ioctl(pDev->vid_fd[((active_crtc_id+1)%2)], DOVEFB_IOCTL_SWITCH_VID_OVLY, &off);
        }
        
        if(pPriv->UseGPU && !bBmmBuffer)
        {
            status = gcoOS_UnmapUserMemory(pDev->exaInfo.Os, buf, map_src_pitch * height, mapInfo, src_paddr);
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "PutMixedVideo: Failed to unmap user memory\n");
                return FALSE;
            }
        }

    }

    memset( gFreeBufAddr, 0, MAX_QUEUE_NUM *sizeof(unsigned char*));

    ioctl(pDev->vid_fd[active_crtc_id], DOVEFB_IOCTL_GET_FREELIST, &gFreeBufAddr);

    n = 0;
    end = start;
    *end++ = BMM_SHM_MAGIC2;
    *end++ = 0;
    for(i=0; i<MAX_QUEUE_NUM; i++ ) {
        if (0 == gFreeBufAddr[i] || ((unsigned int)gFreeBufAddr[i] >= pDev->fbPhyAddr[active_crtc_id] && 
                                     (unsigned int)gFreeBufAddr[i] < pDev->fbPhyAddr[active_crtc_id] + pDev->fbPhySize[active_crtc_id]))
            continue;

        n++;
        *end++ = (unsigned long)gFreeBufAddr[i];
        gFreeBufAddr[i] = 0;
    }

    if (pPriv->UseGPU)
    { 
        // Notify Client to free buffer
        if (bBmmBuffer && g_imagePhyAddr[1] != 0 && b_defered_gpu_stall)
        {
            n++;
            *end++ = (unsigned long)g_imagePhyAddr[1];
            g_imagePhyAddr[1] = 0;
        }

        if (bBmmBuffer && !b_defered_gpu_stall)
        {
            n++;
            *end++ = (unsigned long)dwYAddr;
        }                 
    }

    *(start + 1) = n;
    *end = shm_chksum(start, end);        

    pPriv->UseGPU = savedUseGPU;
    last_gTestViewPortInfo = gTestViewPortInfo;  
    last_gViewPortOffset = gViewPortOffset;  
    last_gVidMode = gVidMode;
    
    return Success;
}

static void
mrvlGetStretchFactor(gcsRECT *pSrcRect, gcsRECT *pDstRect, int *horFactor, int *verFactor)
{
    if (((pSrcRect->right - pSrcRect->left) == 1) || 
        ((pDstRect->right - pDstRect->left) == 1) ||
        ((pSrcRect->bottom - pSrcRect->top) == 1) ||
        ((pDstRect->bottom - pDstRect->top) == 1) )
    {
        *horFactor = ((pSrcRect->right - pSrcRect->left) << 16) / (pDstRect->right - pDstRect->left);
        *verFactor = ((pSrcRect->bottom - pSrcRect->top) << 16) / (pDstRect->bottom - pDstRect->top);
    }
    else
    {
        *horFactor = ((pSrcRect->right - pSrcRect->left - 1) << 16) / (pDstRect->right - pDstRect->left - 1);
        *verFactor = ((pSrcRect->bottom - pSrcRect->top - 1) << 16) / (pDstRect->bottom - pDstRect->top - 1);
    }
}

static Bool
mrvlGeneralTransferImage(gco2D          Engine2D,
                        unsigned int    src_paddr,
                        int             src_pitch,
                        unsigned int    dst_paddr,
                        int             dst_pitch,
                        gcsRECT         *pSrcRect,
                        gcsRECT         *pDstRect,
                        gceSURF_FORMAT  srcFormat,
                        gceSURF_FORMAT  dstFormat,
                        Bool            bCheckSrc,
                        Bool            bCheckDst,
                        unsigned int    pitchAlignment,
                        unsigned int    offsetAlignment)
{
    gcsRECT         srcRect = *pSrcRect, dstRect = *pDstRect;
    unsigned int    aligned_src_paddr = 0, aligned_src_pitch = 0, aligned_dst_paddr = 0, aligned_dst_pitch = 0;
    Bool            bSrcBlitByLine = FALSE, bDstBlitByLine = FALSE;
    gceSTATUS       status;
    int             i, cpp;
    int             horFactor;
    int             verFactor;

    if (srcFormat == gcvSURF_R5G6B5)
        cpp = 2;
    else if (srcFormat == gcvSURF_A8R8G8B8)
        cpp = 4;
    else
    {
        xf86DrvMsg(0, X_ERROR, "mrvlGeneralTransferImage: doesn't support format\n");
        return FALSE;
    }

    if (bCheckSrc &&
        (src_paddr % offsetAlignment != 0 ||
         src_pitch % pitchAlignment != 0) )
    {
        bSrcBlitByLine = TRUE;
    }

    if (bCheckDst &&
        (dst_paddr % offsetAlignment != 0 ||
         dst_pitch % pitchAlignment != 0) )
    {
        bDstBlitByLine = TRUE;
    }

    // check if we support this blit.
    if ( bSrcBlitByLine || bDstBlitByLine)
    {
        for (i = 0; i < (pDstRect->bottom - pDstRect->top); i++)
        {
            unsigned int    src_align, dst_align;
            unsigned int    src_start_paddr, dst_start_paddr;

            // adjust source physical address and pitch.
            if (bSrcBlitByLine)
            {
                src_start_paddr     = src_paddr + pSrcRect->top * src_pitch + i * src_pitch;
                aligned_src_paddr   = MEM_PAGE_ALIGN_DOWN(src_start_paddr, offsetAlignment);
                src_align           = src_start_paddr - aligned_src_paddr;

                if (src_align % cpp != 0)
                {
                    xf86DrvMsg(0, X_ERROR, "mrvlGeneralTransferImage: unsupported src alignment, %d line\n", __LINE__);
                    return FALSE;
                }
            }

            // adjust dstination physical address and pitch.
            if (bDstBlitByLine)
            {
                dst_start_paddr     = dst_paddr + pDstRect->top * dst_pitch + i * dst_pitch;
                aligned_dst_paddr   = MEM_PAGE_ALIGN_DOWN(dst_start_paddr, offsetAlignment);
                dst_align           = dst_start_paddr - aligned_dst_paddr;

                if (dst_align % cpp != 0)
                {
                    xf86DrvMsg(0, X_ERROR, "mrvlGeneralTransferImage: unsupported dst alignment, %d line\n", __LINE__);
                    return FALSE;
                }
            }
        }
    }

    // offset and pitch match alignment, blit by rectangle.
    if (!bSrcBlitByLine && !bDstBlitByLine)
    {
        status = gco2D_SetClipping(Engine2D, &dstRect);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralTransferImage: Failed to set clipping, %d line\n", __LINE__);
            return FALSE;
        }

        status = gco2D_SetColorSource(Engine2D,
                                        src_paddr,
                                        src_pitch,
                                        srcFormat,
                                        gcvSURF_0_DEGREE,
                                        0,
                                        gcvFALSE,
                                        gcvSURF_OPAQUE,
                                        0);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralTransferImage: Failed to set color source, %d line\n", __LINE__);
            return FALSE;
        }

        status = gco2D_SetSource(Engine2D, &srcRect);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralTransferImage: Failed to set source, %d line\n", __LINE__);
            return FALSE;
        }

        status = gco2D_SetTarget(Engine2D,
                                dst_paddr,
                                dst_pitch,
                                gcvSURF_0_DEGREE,
                                0);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralTransferImage: Failed to set target, %d line\n", __LINE__);
            return FALSE;
        }

        mrvlGetStretchFactor(&srcRect, &dstRect, &horFactor, &verFactor);

        status = gco2D_SetStretchFactors(Engine2D, horFactor, verFactor);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralTransferImage: Failed to set stretch factors, %d line\n", __LINE__);
            return FALSE;
        }

        status = gco2D_StretchBlit(Engine2D, 1, &dstRect, 0xCC, 0xCC, dstFormat);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralTransferImage: Failed to blit, %d line\n", __LINE__);
            return FALSE;
        }
    }
    else
    {
        for (i = 0; i < (pDstRect->bottom - pDstRect->top); i++)
        {
            unsigned int    src_align, dst_align;
            unsigned int    src_start_paddr, dst_start_paddr;

            // adjust source physical address and pitch.
            if (bSrcBlitByLine)
            {
                srcRect.top         = 0;
                srcRect.bottom      = 1;
                src_start_paddr     = src_paddr + pSrcRect->top * src_pitch + i * src_pitch;
                aligned_src_paddr   = MEM_PAGE_ALIGN_DOWN(src_start_paddr, offsetAlignment);
                src_align           = src_start_paddr - aligned_src_paddr;
                srcRect.left        = (src_align / cpp) + pSrcRect->left;
                srcRect.right       = (src_align / cpp) + pSrcRect->right;
                aligned_src_pitch   = MEM_PAGE_ALIGN_UP((src_pitch + src_align), pitchAlignment);
            }
            else
            {
                srcRect.top         = pSrcRect->top + i;
                srcRect.bottom      = pSrcRect->top + i + 1;
                srcRect.left        = pSrcRect->left;
                srcRect.right       = pSrcRect->right;

                aligned_src_paddr   = src_paddr;
                aligned_src_pitch   = src_pitch;
            }

            // adjust dstination physical address and pitch.
            if (bDstBlitByLine)
            {
                dstRect.top         = 0;
                dstRect.bottom      = 1;
                dst_start_paddr     = dst_paddr + pDstRect->top * dst_pitch + i * dst_pitch;
                aligned_dst_paddr   = MEM_PAGE_ALIGN_DOWN(dst_start_paddr, offsetAlignment);
                dst_align           = dst_start_paddr - aligned_dst_paddr;
                dstRect.left        = (dst_align / cpp) + pDstRect->left;
                dstRect.right       = (dst_align / cpp) + pDstRect->right;
                aligned_dst_pitch   = MEM_PAGE_ALIGN_UP((dst_pitch + dst_align), pitchAlignment);
            }
            else
            {
                dstRect.top         = pDstRect->top + i;
                dstRect.bottom      = pDstRect->top + i + 1;
                dstRect.left        = pDstRect->left;
                dstRect.right       = pDstRect->right;

                aligned_dst_paddr   = dst_paddr;
                aligned_dst_pitch   = dst_pitch;
            }

            status = gco2D_SetClipping(Engine2D, &dstRect);
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "mrvlGeneralTransferImage: Failed to set clipping, %d line\n", __LINE__);
                return FALSE;
            }

            status = gco2D_SetColorSource(Engine2D,
                                            aligned_src_paddr,
                                            aligned_src_pitch,
                                            srcFormat,
                                            gcvSURF_0_DEGREE,
                                            0,
                                            gcvFALSE,
                                            gcvSURF_OPAQUE,
                                            0);
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "mrvlGeneralTransferImage: Failed to set color source, %d line\n", __LINE__);
                return FALSE;
            }

            status = gco2D_SetSource(Engine2D, &srcRect);
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "mrvlGeneralTransferImage: Failed to set source, %d line\n", __LINE__);
                return FALSE;
            }

            status = gco2D_SetTarget(Engine2D,
                                    aligned_dst_paddr,
                                    aligned_dst_pitch,
                                    gcvSURF_0_DEGREE,
                                    0);
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "mrvlGeneralTransferImage: Failed to set target, %d line\n", __LINE__);
                return FALSE;
            }

            mrvlGetStretchFactor(&srcRect, &dstRect, &horFactor, &verFactor);

            status = gco2D_SetStretchFactors(Engine2D, horFactor, verFactor);
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "mrvlGeneralTransferImage: Failed to set stretch factors, %d line\n", __LINE__);
                return FALSE;
            }

            status = gco2D_StretchBlit(Engine2D, 1, &dstRect, 0xCC, 0xCC, dstFormat);
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "mrvlGeneralTransferImage: Failed to blit, %d line\n", __LINE__);
                return FALSE;
            }
        }
    }

    status = gco2D_Flush(Engine2D);
    if (status != gcvSTATUS_OK)
    {
        xf86DrvMsg(0, X_ERROR, "mrvlGeneralTransferImage: Failed to flush GPU cache, %d line\n", __LINE__);
        return FALSE;
    }

    return TRUE;
}

static Bool
DovefbCreateFilterSurface(ScreenPtr pScreen)
{
    MRVLGetPrivate(pScreen);
    MRVLGetScrnInfo(pScreen);

#if MRVL_SUPPORT_EXA
    pDev->bCreateXVFilterSurf = FALSE;

    if (pDev->UseGPU && pDev->UseExa && pDev->exaMode == 2)
    {
        pDev->pFilterPix = pScreen->CreatePixmap(pScreen, 2048, 2048, 16, 0);

        if (pDev->pFilterPix == NULL)
            return FALSE;
        else
        {
            pDev->bCreateXVFilterSurf = TRUE;
            return TRUE;
        }
    }
    else if (pDev->UseGPU)
    {
        gceSTATUS status;

        if (pDev->exaInfo.Hal == NULL)
            return FALSE;

        status = gcoSURF_Construct(pDev->exaInfo.Hal,
                              2048,
                              2048,
                              1,
                              gcvSURF_BITMAP,
                              gcvSURF_R5G6B5,
                              gcvPOOL_SYSTEM,
                              (gcoSURF *)&pDev->pFilterSurf
                              );
        if( status != gcvSTATUS_OK )
        {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "gcoSURF_Construct failed. file %s, line %d\n", __FILE__, __LINE__);
            pDev->pFilterSurf = NULL;
            return FALSE;
        }  

        status = gcoSURF_Lock(pDev->pFilterSurf,   
                                  &pDev->dwFilterPhyAddr,
                                  NULL
                                  );
        if( status != gcvSTATUS_OK )
        {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "gcoSURF_Lock failed. file %s, line %d\n", __FILE__, __LINE__);
            return FALSE;
        }

        pDev->bCreateXVFilterSurf = TRUE;
    }

    return TRUE;
#else
    pDev->bCreateXVFilterSurf = TRUE;
    return TRUE;
#endif
}

static unsigned int
DovefbGetPhysicalAddressOfFilterSurface(ScreenPtr pScreen)
{
    MRVLGetPrivate(pScreen);
    MRVLGetScrnInfo(pScreen);

    if (!pDev->bCreateXVFilterSurf)
        return 0;

#if MRVL_SUPPORT_EXA
    if (pDev->UseGPU && pDev->UseExa && pDev->exaMode == 2)
    {
        if (pDev->pFilterPix == NULL)
            return 0;

        MRVLGetPixmapPrivate(pPixSurf, pDev->pFilterPix);

        return pPixSurf->dwPhyAddr;
    }
    else if (pDev->UseGPU)
    {
        if (pDev->pFilterSurf == NULL)
            return 0;

        return pDev->dwFilterPhyAddr;
    }
    else
    {
        return pDev->memPhysBase + pScrn->displayWidth * pScrn->virtualY * pScrn->bitsPerPixel / 8;
    }
#else
    return pDev->memPhysBase + pScrn->displayWidth * pScrn->virtualY * pScrn->bitsPerPixel / 8;
#endif
}

void
DovefbDestroyFilterSurface(ScreenPtr pScreen)
{
    MRVLGetPrivate(pScreen);
    MRVLGetScrnInfo(pScreen);

    if (pDev->bCreateXVFilterSurf == FALSE)
        return;

#if MRVL_SUPPORT_EXA
    if (pDev->UseGPU && pDev->UseExa && pDev->exaMode == 2)
    {
        pScreen->DestroyPixmap(pDev->pFilterPix);
    }
    else if (pDev->UseGPU)
    {
        gceSTATUS status;

        status = gcoSURF_Unlock(pDev->pFilterSurf, NULL);
        if( status != gcvSTATUS_OK )
        {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "gcoSURF_Unlock failed. file %s, line %d\n", __FILE__, __LINE__);
        }
        else
        { 
            status = gcoSURF_Destroy(pDev->pFilterSurf);
            if( status != gcvSTATUS_OK )
            {
                xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvlDestroyPixmap: gcoSURF_Destroy failed.\n");                
            } 
        }
    }

    pDev->bCreateXVFilterSurf = FALSE;

    return;
#else
    pDev->bCreateXVFilterSurf = FALSE;

    return;
#endif
}

static int
DovefbPutImageTextured(
    ScrnInfoPtr pScrn,
    short src_x, short src_y,
    short drw_x, short drw_y,
    short src_w, short src_h,
    short drw_w, short drw_h,
    int id, unsigned char* buf,
    short width, short height,
    Bool Sync,
    RegionPtr clipBoxes, pointer data,
    DrawablePtr pDraw
)
{
    DovefbPortPrivPtr pPriv = (DovefbPortPrivPtr)data;
    FBDevRec* pDev = FBDEVPTR(pScrn);
    int movieWidth, movieHeight;  // original movie size.
    int movieBPP;
    int movieSizeInBytes;
    INT32 xa, ya, xb, yb; /* srcClip */
    BoxRec dstBox;
    struct shm_private_info *shminfo;
    //struct shm_private_info info;
    unsigned long *start;
    unsigned long *end;
    unsigned long n;
    //xf86CrtcPtr crtc_ret;
    //int active_crtc_id = 0;
    unsigned int    src_paddr, dst_paddr;
    int             src_pitch = 0, dst_pitch = 0, map_src_pitch = 0;
    BoxPtr          pbox;
    int             i, nbox;
    Bool            bNeedConvert = FALSE, bBmmBuffer = FALSE;
    unsigned int    dwYAddr = 0, dwYStride, dwUAddr, dwUStride, dwVAddr, dwVStride, dwUOff, dwVOff;
    gceSURF_FORMAT  conSrcFormat;
    unsigned int    conDstAddr = 0;
    void            *mapInfo;
    gceSTATUS       status;

    shminfo = (struct shm_private_info *)buf;

#if DEBUG_OVERALY_REG
    DebugRegs();
#endif

    /* calc clipping region */
    xa  = src_x;
    xb  = src_x + src_w;
    ya  = src_y;
    yb  = src_y + src_h;

    dstBox.x1 = drw_x;
    dstBox.x2 = drw_x + drw_w;
    dstBox.y1 = drw_y;
    dstBox.y2 = drw_y + drw_h;

    if (!mrvl_crtc_clip_video(pScrn, NULL, NULL,
                    &dstBox,
                    &xa, &xb, &ya, &yb,
                    clipBoxes,
                    width, height))
        return Success;

    src_w = (xb - xa) >> 16;
    src_h = (yb - ya) >> 16;
    drw_w = dstBox.x2 - dstBox.x1;
    drw_h = dstBox.y2 - dstBox.y1;

    xa >>= 16;
    xb >>= 16;
    ya >>= 16;
    yb >>= 16;

    if ((xb <= xa) || (yb <= ya))
        return Success;

    start = end = (unsigned long *)buf;
    if (*end++ == BMM_SHM_MAGIC1) {
        /* BMM SHM PATH */
        n = *end;
        end = start + 2 + n;
        if (shm_chksum(start, end) == *end)
        {
            dwYAddr = (unsigned int)(*(start + 2));
            bBmmBuffer = TRUE;

#if MRVL_XV_DEFERRED_STALL_GPU
            if (g_imagePhyAddr[0] == 0 )
            {
                g_imagePhyAddr[0] = dwYAddr;
            }
            else
            {
                g_imagePhyAddr[1] = g_imagePhyAddr[0];
                g_imagePhyAddr[0] = dwYAddr;
				
		// Make sure last frame is finished through GPU.
#if MRVL_XV_USE_FAKE_FENCE_STALL
                mrvlFencePoolKickOff(pDraw->pScreen, pDev->pXVScreenFence);
                mrvlFencePoolStall(pDev->pXVScreenFence);
#else
                gcoHAL_Commit(pDev->exaInfo.Hal, TRUE);
#endif
            }
#endif
        }
        else
        {
            xf86DrvMsg(0, X_ERROR, "PutTexturedVideo: Invalid shm buffer info\n");
            return Success;
        }
    }
    else
    {
        switch(id)
        {
        case FOURCC_YV12:
        case FOURCC_I420:
            map_src_pitch = width *  12 / 8;
            break;

        case FOURCC_UYVY:
        case FOURCC_YUY2:
        default:
            map_src_pitch = width * 2;
            break;
        }

        status = gcoOS_MapUserMemory(pDev->exaInfo.Os, buf, map_src_pitch * height, &mapInfo, &src_paddr);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "PutTexturedVideo: Failed to map user memory\n");
            return FALSE;
        }

        dwYAddr = src_paddr;
    }

    movieWidth                  = width;
    movieHeight                 = height;

    switch( id )
    {
        case FOURCC_YV12:
        movieBPP                    = 12;
        movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
        bNeedConvert                = TRUE;

        dwVOff                      = movieWidth * movieHeight;
        dwUOff                      = dwVOff + (dwVOff / 4);

        dwUAddr                     = dwYAddr + dwUOff;
        dwVAddr                     = dwYAddr + dwVOff;
        dwYStride                   = movieWidth;
        dwUStride                   = movieWidth / 2;
        dwVStride                   = movieWidth / 2;

        conSrcFormat                = gcvSURF_YV12;

        // Align X offset
        xa &= ~0x1;
        break;

        case FOURCC_I420:
        movieBPP                    = 12;
        movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
        bNeedConvert                = TRUE;

        dwUOff                      = movieWidth * movieHeight;
        dwVOff                      = dwUOff + (dwUOff / 4);

        dwUAddr                     = dwYAddr + dwUOff;
        dwVAddr                     = dwYAddr + dwVOff;
        dwYStride                   = movieWidth;
        dwUStride                   = movieWidth / 2;
        dwVStride                   = movieWidth / 2;

        conSrcFormat                = gcvSURF_I420;

        // Align X offset
        xa &= ~0x1;
        break;

        case FOURCC_UYVY:
        movieBPP                    = 16;
        movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
        bNeedConvert                = TRUE;

        dwUOff                      = 0;
        dwVOff                      = 0;

        dwUAddr                     = dwYAddr + dwUOff;
        dwVAddr                     = dwYAddr + dwVOff;
        dwYStride                   = movieWidth * movieBPP / 8;
        dwUStride                   = movieWidth;
        dwVStride                   = movieWidth;

        conSrcFormat                = gcvSURF_UYVY;

        break;

        case FOURCC_YUY2:
        movieBPP                    = 16;
        movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
        bNeedConvert                = TRUE;

        dwUOff                      = 0;
        dwVOff                      = 0;

        dwUAddr                     = dwYAddr + dwUOff;
        dwVAddr                     = dwYAddr + dwVOff;
        dwYStride                   = movieWidth * movieBPP / 8;
        dwUStride                   = 0;
        dwVStride                   = 0;

        conSrcFormat                = gcvSURF_YUY2;

        break;

#if MRVL_XV_SUPPORT_RGB_FORMAT
        case FOURCC_RGB565:
        movieBPP                    = 16;
        movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
        src_pitch                   = movieWidth * movieBPP / 8;
        bNeedConvert                = FALSE;
        break;

        case FOURCC_RGBA32:
        movieBPP                    = 32;
        movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
        src_pitch                   = movieWidth * movieBPP / 8;
        bNeedConvert                = FALSE;
        break;

        case FOURCC_RGB24:
        movieBPP                    = 24;
        movieSizeInBytes            = movieWidth * movieHeight * movieBPP / 8;
        src_pitch                   = movieWidth * movieBPP / 8;
        bNeedConvert                = FALSE;
        break;
#endif

    default:
        xf86DrvMsg(0, X_ERROR, "PutTexturedVideo: Invalid image format\n");
        return Success;
    }

    if (bNeedConvert)
    {
        gcsRECT         conSrcRect, conDstRect;

        conDstAddr = DovefbGetPhysicalAddressOfFilterSurface(pDraw->pScreen);

        if (conDstAddr == 0)
        {
            xf86DrvMsg(0, X_ERROR, "PutTexturedVideo: Can not get valid physical address for filter surface\n");
            return Success;
        }

        conSrcRect.left     = 0;
        conSrcRect.top      = 0;
        conSrcRect.right    = width;
        conSrcRect.bottom   = height;

        conDstRect.left     = 0;
        conDstRect.top      = 0;
        conDstRect.right    = width;
        conDstRect.bottom   = height;

        if (pPriv->bDeinterlace)
        {
            conSrcRect.bottom   /= 2;
            dwYStride           *= 2;
            dwUStride           *= 2;
            dwVStride           *= 2;
        }

        status = gco2D_SetClipping(pDev->exaInfo.Engine2D, &conDstRect);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "PutTexturedVideo: Failed to set clipping, %d line\n", __LINE__);
            return Success;
        }

        status = gco2D_SetKernelSize(pDev->exaInfo.Engine2D, 9, 9);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "PutTexturedVideo: Failed to set kernel size, %d line\n", __LINE__);
            return Success;
        }

        status = gco2D_FilterBlit(pDev->exaInfo.Engine2D,
                                dwYAddr,
                                dwYStride,
                                dwUAddr,
                                dwUStride,
                                dwVAddr,
                                dwVStride,
                                conSrcFormat,
                                gcvSURF_0_DEGREE,
                                width,
                                &conSrcRect,
                                conDstAddr,
                                width * 2,
                                gcvSURF_R5G6B5,
                                gcvSURF_0_DEGREE,
                                width,
                                &conDstRect,
                                &conDstRect);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "PutTexturedVideo: Failed to do filter blit, %d line\n", __LINE__);
            return Success;
        }

        // Kick off GPU command buffer without wating.
        //gcoHAL_Commit(pDev->exaInfo.Hal, FALSE);
    }

    /* fill frame to video buffer */
    if (buf)
    {
        gcsRECT         destRect, srcRect;
        gceSTATUS       status;    
        ScreenPtr       pScreen = pDraw->pScreen; 
        ScrnInfoPtr         pScrn = xf86Screens[pScreen->myNum];
        xf86CrtcConfigPtr   xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);
        int   c;   

        pbox = REGION_RECTS(clipBoxes);
        nbox = REGION_NUM_RECTS(clipBoxes);

        if (bNeedConvert)
        {
            src_paddr = conDstAddr;
            src_pitch = width * 2;
        }
        else
        {
            src_paddr = dwYAddr;
            src_pitch = width * 2;
        }

        dst_paddr = pDev->memPhysBase;
        dst_pitch = pScrn->displayWidth * pScrn->bitsPerPixel / 8;

        for (i = 0; i < nbox; i++, pbox++)
        {
            if ((pbox->x1 < dstBox.x1) ||
                (pbox->y1 < dstBox.y1) ||
                (pbox->x2 > dstBox.x2) ||
                (pbox->y2 > dstBox.y2) )
            {
                continue;
            }

            destRect.left   = pbox->x1;
            destRect.top    = pbox->y1;
            destRect.right  = pbox->x2;
            destRect.bottom = pbox->y2;

            srcRect.left   = xa + (pbox->x1 - dstBox.x1) * src_w / drw_w;
            srcRect.top    = ya + (pbox->y1 - dstBox.y1) * src_h / drw_h;
            srcRect.right  = xb - (dstBox.x2 - pbox->x2) * src_w / drw_w;
            srcRect.bottom = yb - (dstBox.y2 - pbox->y2) * src_h / drw_h;

            if ((srcRect.left > srcRect.right) || (srcRect.top > srcRect.bottom))
                continue;

            if (srcRect.left == srcRect.right)
                srcRect.right += 1;

            if (srcRect.top == srcRect.bottom)
                srcRect.bottom += 1;

            if (!mrvlGeneralTransferImage(pDev->exaInfo.Engine2D,
                                        src_paddr,
                                        src_pitch,
                                        dst_paddr,
                                        dst_pitch,
                                        &srcRect,
                                        &destRect,
                                        gcvSURF_R5G6B5,
                                        (pScrn->bitsPerPixel == 16) ?gcvSURF_R5G6B5 : gcvSURF_A8R8G8B8,
                                        TRUE,
                                        FALSE,
                                        32,
                                        64))
            {
                xf86DrvMsg(0, X_ERROR, "PutTexturedVideo: General image transfer failed\n");
            }

            /*  If current rotaion is not 0 degree, need to report damage by driver. 
            We would better to find a better solution for this issue. */
            for (c = 0; c < xf86_config->num_crtc; c++)
            {
                if (xf86_config->crtc[c]->rotation != RR_Rotate_0)
                {
                    mrvlMarkPixmapDirty(&(pScreen->GetScreenPixmap(pScreen)->drawable),
                                destRect.left, destRect.top, destRect.right, destRect.bottom);
                    break;
                }
            }            
        }

#if MRVL_XV_DEFERRED_STALL_GPU
        if(bBmmBuffer)
            gcoHAL_Commit(pDev->exaInfo.Hal, FALSE);
	else
#endif
	{
#if MRVL_XV_USE_FAKE_FENCE_STALL
            mrvlFencePoolKickOff(pDraw->pScreen, pDev->pXVScreenFence);
            mrvlFencePoolStall(pDev->pXVScreenFence);
#else
            gcoHAL_Commit(pDev->exaInfo.Hal, TRUE);		
#endif	    
	}

        if (!bBmmBuffer)
        {
            status = gcoOS_UnmapUserMemory(pDev->exaInfo.Os, buf, map_src_pitch * height, mapInfo, src_paddr);
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "PutTexturedVideo: Failed to unmap user memory\n");
                return FALSE;
            }
        }

        // Notify Client to free buffer
#if MRVL_XV_DEFERRED_STALL_GPU
        if (bBmmBuffer && g_imagePhyAddr[1] != 0)
#else
        if (bBmmBuffer)
#endif
        {
            end = start;
            *end++ = BMM_SHM_MAGIC2;
            *end++ = 1;
#if MRVL_XV_DEFERRED_STALL_GPU
            *end++ = (unsigned long)g_imagePhyAddr[1];
            g_imagePhyAddr[1] = 0;
#else
            *end++ = (unsigned long)dwYAddr;
#endif
            *end = shm_chksum(start, end);
        }
    }
    else
    {
        xf86DrvMsg( pScrn->scrnIndex, X_ERROR, "xv data buf is NULL!!\n" );
    }

    return Success;
}

static int
DovefbQueryImageAttributes(
    ScrnInfoPtr pScrn,
    int id,
    unsigned short *w, unsigned short *h,
    int *pitches, int *offsets
)
{
    int size;

    *w = (*w + 1) & ~1;
    *h = (*h + 1) & ~1;

    if(offsets)
    {
        offsets[0] = 0;   // y0 offset
    }

    switch(id)
    {
        case FOURCC_YV12:
        case FOURCC_I420:
        {
            size = (*w)*(*h)*3/2;

            if ( pitches )
            {            
                pitches[0] = (*w);
                pitches[1] = (*w)/2;
                pitches[2] = (*w)/2;
            }

            if ( offsets )
            {
                offsets[1] = offsets[0]+((*w)*(*h));    // u0 offset
                offsets[2] = offsets[1]+((*w)*(*h)/4); //  vo offset
            }

            break;
        }
        case FOURCC_UYVY:
        case FOURCC_YUY2:
        {
            size = (*w)*(*h)*2;

            if ( pitches )
            {
                *pitches = (*w)*2;
            }

            break;
        }
        case FOURCC_RGBA32:
        {
            size = (*w)*(*h)*4;

            if ( pitches )
            {
                pitches[0] = (*w)*4;
            }

            break;
        }
        case FOURCC_RGB565:
        {
            size = (*w)*(*h)*2;

            if ( pitches )
            {
                pitches[0] = (*w)*2;
            }

            break;
        }
        default:
        {
            size = 0;
            break;
        }
    }

    return size;
}

static XF86VideoAdaptorPtr
DovefbSetupImageVideoOverlay(ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    XF86VideoAdaptorPtr adapt;

    xf86DrvMsg( pScreen->myNum, X_INFO, "Initializing xv adapter.\n" );
    if(!(adapt = DovefbAllocAdaptor(pScrn, 1)))
        return NULL;

    adapt->type = XvWindowMask | XvInputMask | XvImageMask;
    adapt->flags = VIDEO_OVERLAID_IMAGES /*| VIDEO_CLIP_TO_VIEWPORT*/;
    adapt->name = "Marvell Overlay Video";
    adapt->nPorts = 1;
    adapt->nEncodings = sizeof(OverlayEncoding) / sizeof(XF86VideoEncodingRec);
    adapt->pEncodings = OverlayEncoding;
    adapt->nFormats = sizeof(OverlayFormats) / sizeof(XF86VideoFormatRec);
    adapt->pFormats = OverlayFormats;
    adapt->nAttributes = sizeof(OverlayAttributes) / sizeof(XF86AttributeRec);
    adapt->pAttributes = OverlayAttributes;
    adapt->nImages = sizeof(OverlayImages) / sizeof(XF86ImageRec);
    adapt->pImages = OverlayImages;
    adapt->PutVideo = NULL;
    adapt->PutStill = NULL;
    adapt->GetVideo = NULL;
    adapt->GetStill = NULL;
    adapt->StopVideo = DovefbStopVideoOverlay;
    adapt->SetPortAttribute = DovefbSetPortAttributeOverlay;
    adapt->GetPortAttribute = DovefbGetPortAttributeOverlay;
    adapt->QueryBestSize = DovefbQueryBestSize;
    adapt->PutImage = DovefbPutImageOverlay;
    adapt->QueryImageAttributes = DovefbQueryImageAttributes;

    xf86DrvMsg( pScreen->myNum, X_INFO, "Allocate xv adaptor OK.\n");
    return adapt;
}

static XF86VideoAdaptorPtr
DovefbSetupImageVideoMixedOverlay(ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    XF86VideoAdaptorPtr adapt;
    DovefbPortPrivPtr pPortPriv;

    xf86DrvMsg( pScreen->myNum, X_INFO, "Initializing xv adapter.\n" );
    if(!(adapt = DovefbAllocAdaptor(pScrn, 1)))
        return NULL;

    adapt->type = XvWindowMask | XvInputMask | XvImageMask;
    adapt->flags = VIDEO_OVERLAID_IMAGES /*| VIDEO_CLIP_TO_VIEWPORT*/;
    adapt->name = "Marvell Mixed Overlay Video";
    adapt->nPorts = 1;
    adapt->nEncodings = sizeof(OverlayEncoding) / sizeof(XF86VideoEncodingRec);
    adapt->pEncodings = OverlayEncoding;
    adapt->nFormats = sizeof(OverlayFormats) / sizeof(XF86VideoFormatRec);
    adapt->pFormats = OverlayFormats;
    adapt->nAttributes = sizeof(MixedOverlayAttributes) / sizeof(XF86AttributeRec);
    adapt->pAttributes = MixedOverlayAttributes;
    adapt->nImages = sizeof(OverlayImages) / sizeof(XF86ImageRec);
    adapt->pImages = OverlayImages;
    adapt->PutVideo = NULL;
    adapt->PutStill = NULL;
    adapt->GetVideo = NULL;
    adapt->GetStill = NULL;
    adapt->StopVideo = DovefbStopVideoMixedOverlay;
    adapt->SetPortAttribute = DovefbSetPortAttributeMixedOverlay;
    adapt->GetPortAttribute = DovefbGetPortAttributeMixedOverlay;
    adapt->QueryBestSize = DovefbQueryBestSize;
    adapt->PutImage = DovefbPutImageMixedOverlay;
    adapt->QueryImageAttributes = DovefbQueryImageAttributes;

    pPortPriv = (DovefbPortPrivPtr)adapt->pPortPrivates[0].ptr;

    pPortPriv->UseGPU = 1;

    xf86DrvMsg( pScreen->myNum, X_INFO, "Allocate mixed overly adaptor OK.\n");
    return adapt;
}

XF86VideoAdaptorPtr
DovefbSetupImageVideoTexture(ScreenPtr pScreen)
{
#if MRVL_XV_USE_FAKE_FENCE_STALL
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    MRVLGetPrivate(pScreen);
#endif
    DovefbPortPrivPtr pPortPriv;
    XF86VideoAdaptorPtr adapt;
    int i;
    int num_texture_ports = MRVL_XV_ADAPTOR_NUM;

#if MRVL_XV_USE_FAKE_FENCE_STALL
    if (!mrvlFencePoolInit(pDev->exaInfo.Hal, &pDev->exaInfo.fakeFencePool))
    {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "XV initialize fence pool fails\n");
        return FALSE;
    }
	
    pDev->pXVScreenFence = mrvlFencePoolAlloc(&pDev->exaInfo.fakeFencePool);
    if (pDev->pXVScreenFence == NULL)
    {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Fail to allocate fence. file %s, line %d\n", __FILE__, __LINE__);
        return NULL;
    }
#endif

    adapt = xcalloc(1, sizeof(XF86VideoAdaptorRec) + num_texture_ports *
		    (sizeof(DovefbPortPrivRec) + sizeof(DevUnion)));

    if (adapt == NULL)
	    return NULL;

    adapt->type = XvWindowMask | XvInputMask | XvImageMask;
    adapt->flags = 0;
    adapt->name = "Marvell Textured Video";
    adapt->nEncodings = 1;
	adapt->pEncodings = OverlayEncoding;
    adapt->nFormats = sizeof(OverlayFormats) / sizeof(XF86VideoFormatRec);
    adapt->pFormats = OverlayFormats;
    adapt->nPorts = num_texture_ports;
    adapt->pPortPrivates = (DevUnion*)(&adapt[1]);

    pPortPriv =
	(DovefbPortPrivPtr)(&adapt->pPortPrivates[num_texture_ports]);

	adapt->pAttributes = OverlayTexturedAttributes;
	adapt->nAttributes = sizeof(OverlayTexturedAttributes) / sizeof(XF86AttributeRec);
    adapt->pImages = OverlayImages;
    adapt->nImages = sizeof(OverlayImages) / sizeof(XF86ImageRec);
    adapt->PutVideo = NULL;
    adapt->PutStill = NULL;
    adapt->GetVideo = NULL;
    adapt->GetStill = NULL;
    adapt->StopVideo = DovefbStopVideoTexture;
    adapt->SetPortAttribute = DovefbSetPortAttributeTexture;
    adapt->GetPortAttribute = DovefbGetPortAttributeTexture;
    adapt->QueryBestSize = DovefbQueryBestSize;
    adapt->PutImage = DovefbPutImageTextured;
    adapt->ReputImage = NULL;
    adapt->QueryImageAttributes = DovefbQueryImageAttributes;

    DovefbCreateFilterSurface(pScreen);

    for (i = 0; i < num_texture_ports; i++)
    {
	    DovefbPortPrivPtr pPriv = &pPortPriv[i];

	    pPriv->textured = TRUE;
        pPriv->bDeinterlace = 0;

	    REGION_NULL(pScreen, &pPriv->clip);
	    adapt->pPortPrivates[i].ptr = (pointer) (pPriv);
    }

    return adapt;
}

void DovefbXVInitVideo(ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    XF86VideoAdaptorPtr *adaptors, *newAdaptors = NULL;
    XF86VideoAdaptorPtr overlayAdaptor = NULL, textureAdaptor = NULL, mixedAdaptor = NULL;
    int num_adaptors;
    //MRVLGetPrivate(pScreen);
    int my_adaptors_num = 0;
    //MRVLGetPrivateByScrn(pScrn);

    xf86DrvMsg( pScreen->myNum, X_INFO,
            "Dovefb is setting up xv adapter.\n");

#if MRVL_XV_OVERLAY_VIDEO > 0
    my_adaptors_num++;    
#endif

#if MRVL_XV_TEX_VIDEO > 0
    my_adaptors_num++;
#endif

#if MRVL_XV_MIXED_VIDEO > 0
    my_adaptors_num++;
#endif

    if (my_adaptors_num == 0)
    {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Unavailable video adaptor\n");
        return;
    }

    /* Query how many xv device exist. */
    num_adaptors = xf86XVListGenericAdaptors(pScrn, &adaptors);

    newAdaptors = xalloc((num_adaptors + my_adaptors_num) * sizeof(XF86VideoAdaptorPtr*));

    if (newAdaptors == NULL)
        return;

    memcpy(newAdaptors, adaptors, num_adaptors * sizeof(XF86VideoAdaptorPtr));
    adaptors = newAdaptors;
    
#if MRVL_XV_MIXED_VIDEO > 0
    {                
        mixedAdaptor = DovefbSetupImageVideoMixedOverlay(pScreen);

        if (mixedAdaptor != NULL)
        {
            adaptors[num_adaptors++] = mixedAdaptor;
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Set up mixed video adaptor\n");
        }
        else
        {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Failed to set up mixed video adaptor\n");
        }
        
        /*
         * prepare video layer handlers
         */
        PrepareResource(pScrn);
    }
#endif    

#if MRVL_XV_OVERLAY_VIDEO > 0
    {                
        /* Create xv overlay adaptor */
        overlayAdaptor = DovefbSetupImageVideoOverlay(pScreen);

        if (overlayAdaptor != NULL)
        {
            adaptors[num_adaptors++] = overlayAdaptor;
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Set up overlay video adaptor\n");
        }
        else
        {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Failed to set up overlay video adaptor\n");
        }   
        
        /*
         * prepare video layer handlers
         */
        PrepareResource(pScrn);             
    }
#endif

#if MRVL_XV_TEX_VIDEO > 0
    {
        textureAdaptor = DovefbSetupImageVideoTexture(pScreen);

        if (textureAdaptor != NULL)
        {
            adaptors[num_adaptors++] = textureAdaptor;
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Set up textured video adaptor\n");
        }
        else
        {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Failed to set up textured video adaptor\n");
        }
    }
#endif

    if (textureAdaptor && overlayAdaptor) {
        if (enc_func & CHANGE_XV_ADAPTOR_SEQ) {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Register LCD Xv first.\n");
            adaptors[num_adaptors - 2] = overlayAdaptor;
            adaptors[num_adaptors - 1] = textureAdaptor;
        } else {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Register GPU Xv first.\n");
            adaptors[num_adaptors - 2] = textureAdaptor;
            adaptors[num_adaptors - 1] = overlayAdaptor;
        }
    }

    /*
     * Make atoms for attributes.
     */
    DovefbResetVideo(pScrn);

    /* registe xv device into xserver. */
    if(num_adaptors)
        xf86XVScreenInit(pScreen, adaptors, num_adaptors);

    if(newAdaptors)
        xfree(newAdaptors);

    xf86DrvMsg( pScreen->myNum, X_INFO, "Dovefb xv has been set up successfully.\n");
}

