#ifndef __MRVL_EDID_H__
#define __MRVL_EDID_H__

#define EDID_LENGTH 128
#define DDC_ADDR 0x50

struct est_timings {
    unsigned char t1;
    unsigned char t2;
    unsigned char mfg_rsvd;
} __attribute__((packed));

/* 00=16:10, 01=4:3, 10=5:4, 11=16:9 */
#define EDID_TIMING_ASPECT_SHIFT 6
#define EDID_TIMING_ASPECT_MASK  (0x3 << EDID_TIMING_ASPECT_SHIFT)

/* need to add 60 */
#define EDID_TIMING_VFREQ_SHIFT  0
#define EDID_TIMING_VFREQ_MASK   (0x3f << EDID_TIMING_VFREQ_SHIFT)

struct std_timing {
    unsigned char hsize; /* need to multiply by 8 then add 248 */
    unsigned char vfreq_aspect;
} __attribute__((packed));

#define MRVL_EDID_PT_HSYNC_POSITIVE (1 << 1)
#define MRVL_EDID_PT_VSYNC_POSITIVE (1 << 2)
#define MRVL_EDID_PT_SEPARATE_SYNC  (3 << 3)
#define MRVL_EDID_PT_STEREO         (1 << 5)
#define MRVL_EDID_PT_INTERLACED     (1 << 7)

/* If detailed data is pixel timing */
struct detailed_pixel_timing {
    unsigned char hactive_lo;
    unsigned char hblank_lo;
    unsigned char hactive_hblank_hi;
    unsigned char vactive_lo;
    unsigned char vblank_lo;
    unsigned char vactive_vblank_hi;
    unsigned char hsync_offset_lo;
    unsigned char hsync_pulse_width_lo;
    unsigned char vsync_offset_pulse_width_lo;
    unsigned char hsync_vsync_offset_pulse_width_hi;
    unsigned char width_mm_lo;
    unsigned char height_mm_lo;
    unsigned char width_height_mm_hi;
    unsigned char hborder;
    unsigned char vborder;
    unsigned char misc;
} __attribute__((packed));

/* If it's not pixel timing, it'll be one of the below */
struct detailed_data_string {
    unsigned char str[13];
} __attribute__((packed));

struct detailed_data_monitor_range {
    unsigned char min_vfreq;
    unsigned char max_vfreq;
    unsigned char min_hfreq_khz;
    unsigned char max_hfreq_khz;
    unsigned char pixel_clock_mhz; /* need to multiply by 10 */
    unsigned short sec_gtf_toggle; /* A000=use above, 20=use below */
    unsigned char hfreq_start_khz; /* need to multiply by 2 */
    unsigned char c; /* need to divide by 2 */
    unsigned short m;
    unsigned char k;
    unsigned char j; /* need to divide by 2 */
} __attribute__((packed));

struct detailed_data_wpindex {
    unsigned char white_yx_lo; /* Lower 2 bits each */
    unsigned char white_x_hi;
    unsigned char white_y_hi;
    unsigned char gamma; /* need to divide by 100 then add 1 */
} __attribute__((packed));

struct detailed_data_color_point {
    unsigned char windex1;
    unsigned char wpindex1[3];
    unsigned char windex2;
    unsigned char wpindex2[3];
} __attribute__((packed));

struct detailed_non_pixel {
    unsigned char pad1;
    unsigned char type; /* ff=serial, fe=string, fd=monitor range, fc=monitor name
            fb=color point data, fa=standard timing data,
            f9=undefined, f8=mfg. reserved */
    unsigned char pad2;
    union {
        struct detailed_data_string str;
        struct detailed_data_monitor_range range;
        struct detailed_data_wpindex color;
        struct std_timing timings[5];
    } data;
} __attribute__((packed));

#define EDID_DETAIL_STD_MODES 0xfa
#define EDID_DETAIL_MONITOR_CPDATA 0xfb
#define EDID_DETAIL_MONITOR_NAME 0xfc
#define EDID_DETAIL_MONITOR_RANGE 0xfd
#define EDID_DETAIL_MONITOR_STRING 0xfe
#define EDID_DETAIL_MONITOR_SERIAL 0xff

struct detailed_timing {
    unsigned short pixel_clock; /* need to multiply by 10 KHz */
    union {
        struct detailed_pixel_timing pixel_data;
        struct detailed_non_pixel other_data;
    } data;
} __attribute__((packed));

#define MRVL_EDID_INPUT_SERRATION_VSYNC (1 << 0)
#define MRVL_EDID_INPUT_SYNC_ON_GREEN   (1 << 1)
#define MRVL_EDID_INPUT_COMPOSITE_SYNC  (1 << 2)
#define MRVL_EDID_INPUT_SEPARATE_SYNCS  (1 << 3)
#define MRVL_EDID_INPUT_BLANK_TO_BLACK  (1 << 4)
#define MRVL_EDID_INPUT_VIDEO_LEVEL     (3 << 5)
#define MRVL_EDID_INPUT_DIGITAL         (1 << 7) /* bits below must be zero if set */

#define MRVL_EDID_FEATURE_DEFAULT_GTF      (1 << 0)
#define MRVL_EDID_FEATURE_PREFERRED_TIMING (1 << 1)
#define MRVL_EDID_FEATURE_STANDARD_COLOR   (1 << 2)
#define MRVL_EDID_FEATURE_DISPLAY_TYPE     (3 << 3) /* 00=mono, 01=rgb, 10=non-rgb, 11=unknown */
#define MRVL_EDID_FEATURE_PM_ACTIVE_OFF    (1 << 5)
#define MRVL_EDID_FEATURE_PM_SUSPEND       (1 << 6)
#define MRVL_EDID_FEATURE_PM_STANDBY       (1 << 7)

struct edid {
    unsigned char header[8];
    /* Vendor & product info */
    unsigned char mfg_id[2];
    unsigned char prod_code[2];
    unsigned int serial; /* FIXME: byte order */
    unsigned char mfg_week;
    unsigned char mfg_year;
    /* EDID version */
    unsigned char version;
    unsigned char revision;
    /* Display info: */
    unsigned char input;
    unsigned char width_cm;
    unsigned char height_cm;
    unsigned char gamma;
    unsigned char features;
    /* Color characteristics */
    unsigned char red_green_lo;
    unsigned char black_white_lo;
    unsigned char red_x;
    unsigned char red_y;
    unsigned char green_x;
    unsigned char green_y;
    unsigned char blue_x;
    unsigned char blue_y;
    unsigned char white_x;
    unsigned char white_y;
    /* Est. timings and mfg rsvd timings*/
    struct est_timings established_timings;
    /* Standard timings 1-8*/
    struct std_timing standard_timings[8];
    /* Detailing timings 1-4 */
    struct detailed_timing detailed_timings[4];
    /* Number of 128 byte ext. blocks */
    unsigned char extensions;
    /* Checksum */
    unsigned char checksum;
} __attribute__((packed));

#define EDID_PRODUCT_ID(e) ((e)->prod_code[0] | ((e)->prod_code[1] << 8))

Bool 
mrvl_edid_is_valid(struct edid *edid);

Bool 
mrvl_detect_hdmi_monitor(struct edid *edid);

DisplayModePtr
mrvl_add_extended_edid_modes(struct edid *edid, DisplayModePtr modes);

#endif /* __MRVL_EDID_H__ */
