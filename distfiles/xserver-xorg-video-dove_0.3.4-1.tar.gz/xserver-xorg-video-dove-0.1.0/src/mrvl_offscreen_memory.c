/******************************************************************************
//(C) Copyright 2009 Marvell International Ltd.
//All Rights Reserved
******************************************************************************/
#include "xf86.h"
#include <unistd.h>
#include <X11/Xmd.h>
#include "fb.h"
#include "xf86.h"
#include <video/dovefb.h>
#include <sys/ioctl.h>
#include "dovefb_driver.h"
#include "exa.h"


/* Allocates memory, either by resizing the allocation pointed to by mem_struct,
 * or by freeing mem_struct (if non-NULL) and allocating a new space.  The size
 * is measured in bytes, and the offset from the beginning of card space is
 * returned.
 */
uint32_t
mrvl_allocate_memory(ScrnInfoPtr pScrn,
		       void **mem_struct,
		       int size,
		       int align)
{
    ScreenPtr pScreen = screenInfo.screens[pScrn->scrnIndex];
    FBDevPtr  info = FBDEVPTR(pScrn);
    uint32_t  offset = 0;

    if (info->UseExa) 
    {
    	ExaOffscreenArea *area = *mem_struct;
    
    	if (area != NULL) {
    	    if (area->size >= size)
    		return area->offset;
    
    	    exaOffscreenFree(pScreen, area);
    	}
    
    	area = exaOffscreenAlloc(pScreen, size, align, TRUE, NULL, NULL);
    
    	*mem_struct = area;
    	if (area == NULL)
        {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "mrvl_allocate_memory: Fail to get offscreen memory\n");
    	    return 0;
        }
    	offset = area->offset;
    }

    return offset;
}

void
mrvl_free_memory(ScrnInfoPtr pScrn,
		   void *mem_struct)
{
    FBDevPtr  info = FBDEVPTR(pScrn);
    ScreenPtr pScreen = screenInfo.screens[pScrn->scrnIndex];

    if (info->UseExa) 
    {
    	ExaOffscreenArea *area = mem_struct;
    
    	if (area != NULL)
    	    exaOffscreenFree(pScreen, area);
    	area = NULL;
    }
}

