/******************************************************************************
//(C) Copyright 2009 Marvell International Ltd.
//All Rights Reserved
******************************************************************************/

#include <unistd.h>
#include "dovefb_driver.h"

static BlendOp mrvlExaBlendOp[] = {
	/* Clear */
	{gcvSURF_BLEND_ZERO, gcvSURF_BLEND_ZERO},
	/* Src */
	{gcvSURF_BLEND_ONE, gcvSURF_BLEND_ZERO},
	/* Dst */
	{gcvSURF_BLEND_ZERO, gcvSURF_BLEND_ONE},
	/* Over */
	{gcvSURF_BLEND_ONE, gcvSURF_BLEND_INVERSED},
	/* OverReverse */
	{gcvSURF_BLEND_INVERSED, gcvSURF_BLEND_ONE},
	/* In */
	{gcvSURF_BLEND_STRAIGHT, gcvSURF_BLEND_ZERO},
	/* InReverse */
	{gcvSURF_BLEND_ZERO, gcvSURF_BLEND_STRAIGHT},
	/* Out */
	{gcvSURF_BLEND_INVERSED, gcvSURF_BLEND_ZERO},
	/* OutReverse */
	{gcvSURF_BLEND_ZERO, gcvSURF_BLEND_INVERSED},
	/* Atop */
	{gcvSURF_BLEND_STRAIGHT, gcvSURF_BLEND_INVERSED},
	/* AtopReverse */
	{gcvSURF_BLEND_INVERSED, gcvSURF_BLEND_STRAIGHT},
	/* Xor */
	{gcvSURF_BLEND_INVERSED, gcvSURF_BLEND_INVERSED},
	/* Add */
	{gcvSURF_BLEND_ONE, gcvSURF_BLEND_ONE}
};

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
BlendOp *
mrvlGetBlendOperation()
{
    return mrvlExaBlendOp;
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
int 
mrvlGetBlendOperationSize()
{
    return sizeof(mrvlExaBlendOp);
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
void
mrvlMarkPixmapDirty (DrawablePtr drawable, int x1, int y1, int x2, int y2)
{
    BoxRec box;
    RegionRec region;

    box.x1 = max(x1, 0);
    box.y1 = max(y1, 0);
    box.x2 = min(x2, drawable->width);
    box.y2 = min(y2, drawable->height);

    if (box.x1 >= box.x2 || box.y1 >= box.y2)
	return;

    REGION_INIT(pScreen, &region, &box, 1);
    DamageRegionAppend(drawable, &region);
    DamageRegionProcessPending(drawable);
    REGION_UNINIT(pScreen, &region);
}


/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/	
Bool
mrvlGeneralRotationBlit(
    gco2D               engine2D,
	gcoSURF             srcSurface,
	gcoSURF             destSurface,
	gcoSURF             filterDstSurface,
	gcsRECT_PTR         srcRect,
	gcsRECT_PTR         dstRect,
	gceSURF_ROTATION    rotationDegree
	)
{
    gceSTATUS           status = gcvSTATUS_OK;
    Bool                bNeedFilterBlit = FALSE, bNeedRotation = FALSE;
    gceSURF_FORMAT      srcFormat, dstFormat;
    gctUINT32           srcW, dstW;

    if (!srcSurface || !destSurface)
    {
        xf86DrvMsg(0, X_ERROR, "mrvlGeneralRotationBlit: invalid surface handle\n");
        return FALSE;
    }

    if (srcSurface)
    {
        status = gcoSURF_GetFormat(srcSurface, NULL, &srcFormat);
        if (status != gcvSTATUS_OK )
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralRotationBlit: failed to get src format\n");
            return FALSE;
        }

        status = gcoSURF_GetAlignedSize(srcSurface, &srcW, NULL, NULL);
        if (status != gcvSTATUS_OK )
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralRotationBlit: failed to get src pitch\n");
            return FALSE;
        }
    } 

    if (destSurface)
    {
        status = gcoSURF_GetFormat(destSurface, NULL, &dstFormat);
        if (status != gcvSTATUS_OK )
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralRotationBlit: failed to get dst format\n");
            return FALSE;
        }

        status = gcoSURF_GetAlignedSize(destSurface, &dstW, NULL, NULL);
        if (status != gcvSTATUS_OK )
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralRotationBlit: failed to get dst pitch\n");
            return FALSE;
        }
    } 
        
    switch(srcFormat)
    {
    case gcvSURF_YUY2:
    case gcvSURF_UYVY:
    case gcvSURF_YV12:
    case gcvSURF_I420:
    case gcvSURF_NV12:
        bNeedFilterBlit = TRUE;
        
        if (filterDstSurface == NULL)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralRotationBlit: Please check your intermediate surface\n");   
            return FALSE;
        }
        
        break;
        
    default:
        bNeedFilterBlit = FALSE;
        break; 
    }
    
    switch(rotationDegree)
    {
    case gcvSURF_90_DEGREE:
    case gcvSURF_180_DEGREE:
    case gcvSURF_270_DEGREE:
        bNeedRotation = TRUE;
        break;
    
    default:
        bNeedRotation = FALSE;
        break;
    }        
    
    if (bNeedFilterBlit)
    {
        status = gco2D_SetKernelSize(engine2D, 9, 9);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralRotationBlit: gcoSURF_MapUserSurface failed \n");
            return FALSE;
        }                   
       
        status = gcoSURF_FilterBlit(srcSurface, 
                                    bNeedRotation ? filterDstSurface : destSurface, 
                                    srcRect, 
                                    dstRect, 
                                    gcvNULL);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralRotationBlit: gcoSURF_FilterBlit failed \n");
            return FALSE;
        } 
    }      
    
    if (bNeedRotation)
    {  
        gcsRECT rotateSrcRect, rotateDstRect;
        
        switch (rotationDegree)
        {
        case gcvSURF_90_DEGREE:
        
            rotateSrcRect.left      = srcRect->left;
            rotateSrcRect.right     = srcRect->right;
            rotateSrcRect.top       = srcRect->top;
            rotateSrcRect.bottom    = srcRect->bottom;
            
            rotateDstRect.left      = dstRect->top;
            rotateDstRect.right     = dstRect->bottom;
            rotateDstRect.top       = dstW - dstRect->right;
            rotateDstRect.bottom    = dstW - dstRect->left; 
                
            status = gcoSURF_SetRotation(destSurface, rotationDegree); 
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "mrvlGeneralRotationBlit: gcoSURF_SetRotation failed \n");
                return FALSE;
            }  
               
            break;

        case gcvSURF_180_DEGREE:
        
            rotateSrcRect.left      = srcRect->left;
            rotateSrcRect.right     = srcRect->right;
            rotateSrcRect.top       = srcRect->top;
            rotateSrcRect.bottom    = srcRect->bottom;
            
            rotateDstRect.left      = dstRect->left;
            rotateDstRect.right     = dstRect->right;
            rotateDstRect.top       = dstRect->top;
            rotateDstRect.bottom    = dstRect->bottom; 
        
            status = gco2D_SetBitBlitMirror(engine2D, TRUE, TRUE);
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "mrvlGeneralRotationBlit: gco2D_SetBitBlitMirror failed \n");
                return FALSE;
            }     
            
            break;

        case gcvSURF_270_DEGREE:
        
            rotateSrcRect.left      = srcRect->top;
            rotateSrcRect.right     = srcRect->bottom;
            rotateSrcRect.top       = srcW - srcRect->right;
            rotateSrcRect.bottom    = srcW - srcRect->left;
            
            rotateDstRect.left      = dstRect->left;
            rotateDstRect.right     = dstRect->right;
            rotateDstRect.top       = dstRect->top;
            rotateDstRect.bottom    = dstRect->bottom;  
        
            status = gcoSURF_SetRotation(bNeedFilterBlit ? filterDstSurface : srcSurface, gcvSURF_90_DEGREE); 
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "mrvlGeneralRotationBlit: gcoSURF_SetRotation failed \n");
                return FALSE;
            }     
    
            break;

        case gcvSURF_0_DEGREE:
        default:
            break;

        }
    
        status = gco2D_SetClipping(engine2D, &rotateDstRect);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralRotationBlit: gco2D_SetClipping failed \n");
            return FALSE;
        }
    
        status = gcoSURF_Blit(bNeedFilterBlit ? filterDstSurface : srcSurface, 
                            destSurface, 
                            1,
                            &rotateSrcRect, 
                            &rotateDstRect,
                            gcvNULL,
                            0xCC,
                            0xCC,
                            gcvSURF_OPAQUE,
                            0,
                            gcvNULL, 
                            0);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralRotationBlit: gcoSURF_FilterBlit failed \n");
            return FALSE;
        }                  
    }
    
#if 0
    status = gco2D_Flush(engine2D);
    if (status != gcvSTATUS_OK)
    {
        xf86DrvMsg(0, X_ERROR, "mrvlGeneralRotationBlit: gcoSURF_Flush failed \n");
        return FALSE;
    }
#endif   
    
    if (bNeedRotation)
    { 
        status = gcoSURF_SetRotation(bNeedFilterBlit ? filterDstSurface : srcSurface, gcvSURF_0_DEGREE); 
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralRotationBlit: gcoSURF_SetRotation failed \n");
            return FALSE;
        }      
        
        status = gcoSURF_SetRotation(destSurface, gcvSURF_0_DEGREE); 
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralRotationBlit: gcoSURF_SetRotation failed \n");
            return FALSE;
        }      
             
        status = gco2D_SetBitBlitMirror(engine2D, FALSE, FALSE);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralRotationBlit: gcoSURF_SetRotation failed \n");
            return FALSE;
        } 
    }
    
    return TRUE; 
}		


/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
void mrvl_src_blit(CARD8 *pSrc, 
                   CARD8 *pDst, 
                   BoxPtr pSrcBox, 
                   BoxPtr pDstBox, 
                   int src_pitch, 
                   int dst_pitch, 
                   int src_bpp, 
                   int dst_bpp)
 {
    int i;
    int bytes = (pDstBox->x2 - pDstBox->x1) * dst_bpp / 8;
    
    if ((pDstBox->x2 - pDstBox->x1) != (pSrcBox->x2 - pSrcBox->x1))
        return;

    pSrc += pSrcBox->y1 * src_pitch + pSrcBox->x1 * src_bpp / 8;
    pDst += pDstBox->y1 * dst_pitch + pDstBox->x1 * dst_bpp / 8;

    for (i = pDstBox->y2 - pDstBox->y1; i; i--) {
    	memcpy (pDst, pSrc, bytes);
    	pSrc += src_pitch;
    	pDst += dst_pitch;
    }
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
static Bool 
mrvlPixelHasAlpha(gceSURF_FORMAT srcFormat)
{
    switch ( srcFormat ) 
    {
    case gcvSURF_A8R8G8B8:
    case gcvSURF_X8R8G8B8:
    case gcvSURF_A8B8G8R8:
    case gcvSURF_X8B8G8R8:
        return TRUE;
        
    /* 24bpp formats */
    case gcvSURF_R8G8B8:
    case gcvSURF_B8G8R8:
    /* 16bpp formats */
    case gcvSURF_R5G6B5:
    case gcvSURF_B5G6R5:
    case gcvSURF_A1R5G5B5:
    case gcvSURF_X1R5G5B5:
    case gcvSURF_A1B5G5R5:
    case gcvSURF_A4R4G4B4:
    case gcvSURF_X4R4G4B4:
    case gcvSURF_A4B4G4R4:
    default:
        return FALSE;
    }
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
Bool
mrvlAlphaBlendBlt(int op, 
                gco2D Engine2D, 
                gcoSURF srcSurf, 
                gcoSURF dstSurf, 
                gcoSURF alphaSurf,
                gcoSURF maskSurf,
                gcsRECT *srcRect, 
                gcsRECT *dstRect,
                Bool    bDstMask
                )
{
    gceSTATUS       status;
    gceSURF_FORMAT  srcFormat;
    gceSURF_FORMAT  dstFormat;
    gceSURF_FORMAT  alphaFormat, maskFormat;
    Bool            bDstBlendAlpha;
    Bool            bSrcBlendAlpha;
    
    if (!Engine2D ||
        !srcSurf || 
        !dstSurf ||
        !alphaSurf ||
        !srcRect ||
        !dstRect)
    {
        xf86DrvMsg(0, X_ERROR, "mrvlAlphaBlendBlt: Invalid parameters\n");
        return FALSE;
    }
    
    if (bDstMask && !maskSurf)
    {
        xf86DrvMsg(0, X_ERROR, "mrvlAlphaBlendBlt: Null mask transfromation surface\n");
        return FALSE;
    }

    if (srcSurf)
    {
        status = gcoSURF_GetFormat(srcSurf, NULL, &srcFormat);
        if (status != gcvSTATUS_OK )
        {
            xf86DrvMsg(0, X_ERROR, "mrvlAlphaBlendBlt: failed to get src format\n");
            return FALSE;
        } 	
    }

    if (dstSurf)
    {
        status = gcoSURF_GetFormat(dstSurf, NULL, &dstFormat);
        if (status != gcvSTATUS_OK )
        {
            xf86DrvMsg(0, X_ERROR, "mrvlAlphaBlendBlt: failed to get dest format\n");
            return FALSE;
        }
    } 	

    if (alphaSurf)
    {
        status = gcoSURF_GetFormat(alphaSurf, NULL, &alphaFormat);
        if (status != gcvSTATUS_OK )
        {
            xf86DrvMsg(0, X_ERROR, "mrvlAlphaBlendBlt: failed to get alpha format\n");
            return FALSE;
        }
    } 

    if (maskSurf)
    {
        status = gcoSURF_GetFormat(maskSurf, NULL, &maskFormat);
        if (status != gcvSTATUS_OK )
        {
            xf86DrvMsg(0, X_ERROR, "mrvlAlphaBlendBlt: failed to get mask format\n");
            return FALSE;
        } 	
    }
    
    //xf86DrvMsg(0, X_ERROR, "mrvlAlphaBlendBlt: src f %d, dst f %d, alpha f %d, mask f %d\n", srcFormat, dstFormat, alphaFormat, maskFormat);	
    
    bSrcBlendAlpha = mrvlPixelHasAlpha(srcFormat);
    bDstBlendAlpha = mrvlPixelHasAlpha(dstFormat);
    
    if (bDstMask && !bDstBlendAlpha)
    {
        xf86DrvMsg(0, X_ERROR, "mrvlAlphaBlendBlt: Invalid mask format without alpha channal %d\n", dstFormat);
        return FALSE;
    }		

    if (!bDstBlendAlpha && !alphaSurf)
    {        
        xf86DrvMsg(0, X_ERROR, "mrvlAlphaBlendBlt: Null alpha transfromation surface\n");
        return FALSE;
    }										
    							
    status = gco2D_SetClipping(Engine2D, dstRect);
    if (status != gcvSTATUS_OK )
    {
        xf86DrvMsg(0, X_ERROR, "mrvlAlphaBlendBlt: failed to set clipping rectangle\n");
        return FALSE;
    } 	
							
	if (!bDstBlendAlpha || bDstMask)
	{
		status =  gcoSURF_Blit( dstSurf, 
                                bDstMask ? maskSurf : alphaSurf,
                                1, 
                                dstRect, dstRect,
                                NULL,
                                0xCC, 
                                0xCC,
                                gcvSURF_OPAQUE,
                                0,
                                gcvNULL, 
                                0);
        if (status != gcvSTATUS_OK )
        {
            xf86DrvMsg(0, X_ERROR, "mrvlAlphaBlendBlt: SURF_Blit faild with status %d in line %d\n", status, __LINE__);
            return FALSE;
        }
	}

	status = gco2D_EnableAlphaBlend( Engine2D,
							0,
							0,
							gcvSURF_PIXEL_ALPHA_STRAIGHT,
							gcvSURF_PIXEL_ALPHA_STRAIGHT,
							gcvSURF_GLOBAL_ALPHA_OFF,
							gcvSURF_GLOBAL_ALPHA_OFF,
							mrvlExaBlendOp[op].srcFactorMode,
							mrvlExaBlendOp[op].dstFactorMode,
							gcvSURF_COLOR_STRAIGHT,
							gcvSURF_COLOR_STRAIGHT);
    if (status != gcvSTATUS_OK )
    {
        xf86DrvMsg(0, X_ERROR, "mrvlAlphaBlendBlt: failed to nable alpha blend \n");
        return FALSE;
    } 		
	
    /* Do the blit. */
    status =  gcoSURF_Blit( srcSurf, 
                            bDstMask ? maskSurf : (!bDstBlendAlpha ? alphaSurf : dstSurf),
                            1, 
                            srcRect, dstRect,
                            NULL,
                            0xCC, 
                            0xCC,
                            gcvSURF_OPAQUE,
                            0,
                            gcvNULL, 
                            0);
    if (status != gcvSTATUS_OK )
    {
        xf86DrvMsg(0, X_ERROR, "mrvlAlphaBlendBlt: SURF_Blit faild with status %d in line %d\n", status, __LINE__);
        return FALSE;
    }
    
    status = gco2D_DisableAlphaBlend(Engine2D);
    if (status != gcvSTATUS_OK )
    {
        xf86DrvMsg(0, X_ERROR, "mrvlAlphaBlendBlt: failed to disable alpha blend\n");
        return FALSE;
    }
    
    if (!bDstBlendAlpha && !bDstMask)
	{
		status =  gcoSURF_Blit( alphaSurf, 
                                dstSurf,
                                1, 
                                dstRect, dstRect,
                                NULL,
                                0xCC, 
                                0xCC,
                                gcvSURF_OPAQUE,
                                0,
                                gcvNULL, 
                                0);

        if (status != gcvSTATUS_OK )
        {
            xf86DrvMsg(0, X_ERROR, "mrvlAlphaBlendBlt: SURF_Blit faild with status %d in line %d\n", status, __LINE__);
            return FALSE;
        }
	}    
    
    return TRUE;
    
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
static Bool
mrvlHorizontalRepeatBlt(int srcW, 
                        int srcH, 
                        int srcOrigLeft, 
                        gcoSURF srcSurf, 
                        gcoSURF dstSurf, 
                        gcsRECT *srcRect,
                        gcsRECT *dstRect)
{
    gcsRECT         repDstR, repSrcR;
    int             tempSrcOrigLeft = srcOrigLeft;
    int             backCount = 0;  
    gceSTATUS       status;
    
    if (srcOrigLeft > 0)
    {
        while ((tempSrcOrigLeft - srcW) > 0)
        {
            tempSrcOrigLeft -= srcW;   
            ++backCount; 
        }
        
        repSrcR.left    = srcW - tempSrcOrigLeft;
        repSrcR.right   = srcW;

        repDstR.left    = 0;
        repDstR.right   = tempSrcOrigLeft;
    }
    else if (srcOrigLeft < 0)
    {
        repSrcR.left    = -srcOrigLeft;
        repSrcR.right   = srcW;

        repDstR.left    = 0;
        repDstR.right   = srcW + srcOrigLeft;
    }
    else
    {
        repSrcR.left    = 0;
        repSrcR.right   = srcW;

        repDstR.left    = 0;
        repDstR.right   = srcW;
    }
     
    repSrcR.top     = srcRect->top;
    repSrcR.bottom  = srcRect->bottom;
        
    
    repDstR.top     = dstRect->top;
    repDstR.bottom  = dstRect->bottom;

#if TRACE_REPEAT
    MRVL_LOG("\t\tRepeat trace\n");
#endif

    do
    {
#if TRACE_REPEAT
        MRVL_LOG("\t\t\t\tsrc (%d, %d, %d, %d), dst (%d, %d, %d, %d)\n", 
        repSrcR.left, repSrcR.right, repSrcR.top, repSrcR.bottom,
        repDstR.left, repDstR.right, repDstR.top, repDstR.bottom);
#endif
        status =  gcoSURF_Blit( srcSurf, 
                                dstSurf,
                                1, 
                                &repSrcR, &repDstR,
                                NULL,
                                0xCC, 
                                0xCC,
                                gcvSURF_OPAQUE,
                                0,
                                gcvNULL, 
                                0);
        if (status != gcvSTATUS_OK )
        {
            xf86DrvMsg(0, X_ERROR, "mrvlHorizontalRepatBlt: SURF_Blit faild with status %d in line %d\n", status, __LINE__);
            return FALSE;
        }

        if (repDstR.right >= dstRect->right)
        {
            break;
        }

        repDstR.left  += (repSrcR.left != 0) ? tempSrcOrigLeft : srcW;
        repDstR.right += srcW;
        
        if (repSrcR.left != 0)
        {
            repSrcR.left = 0;    
        }
    }
    while (1);
    
    return TRUE;
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
static Bool
mrvlNormalRepeatBlt(int srcW, 
                    int srcH, 
                    int srcOrigLeft, 
                    int srcOrigTop, 
                    gcoSURF srcSurf, 
                    gcoSURF dstSurf, 
                    gcsRECT *dstRect)
{
    gcsRECT     repSrcR, repDstR;
    int         tempSrcOrigTop = srcOrigTop;
    int         backCount = 0;
    
    if (srcOrigTop > 0)
    {
        while ((tempSrcOrigTop - srcH) > 0)
        {
            tempSrcOrigTop -= srcH;   
            ++backCount; 
        }
        
        repSrcR.top     = srcH - tempSrcOrigTop;
        repSrcR.bottom  = srcH;

        repDstR.top     = 0;
        repDstR.bottom  = tempSrcOrigTop;
    }
    else if (srcOrigTop < 0)
    {
        repSrcR.top     = -srcOrigTop;
        repSrcR.bottom  = srcH;

        repDstR.top     = 0;
        repDstR.bottom  = srcH + srcOrigTop;
    }
    else
    {
        repSrcR.top     = 0;
        repSrcR.bottom  = srcH;

        repDstR.top     = 0;
        repDstR.bottom  = srcH;
    }
    
    repSrcR.left    = 0;
    repSrcR.right   = srcW;
    
    repDstR.right   = dstRect->right;
    repDstR.left    = dstRect->left;
    
    do
    {                
        if (!mrvlHorizontalRepeatBlt(srcW, 
                            srcH,
                            srcOrigLeft,
                            srcSurf,
                            dstSurf,
                            &repSrcR,
                            &repDstR))
        {
            xf86DrvMsg(0, X_ERROR, "mrvlNormalRepeatBlt: failed to repeat in x directly, line %d\n", __LINE__);
            return FALSE;
        }

        if (repDstR.bottom >= dstRect->bottom)
        {
            break;
        }

        repDstR.top     += (repSrcR.top != 0) ? tempSrcOrigTop : srcH;
        repDstR.bottom  += srcH;
        
        if (repSrcR.top != 0)
        {
            repSrcR.top = 0;    
        }
    }
    while (1);
    
    return TRUE;
    
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
Bool
mrvlGeneralRepeatBlt(int repeatMode, 
                    gco2D Engine2D,
                    int srcWidth, 
                    int srcHeight, 
                    gcoSURF srcSurf, 
                    gcoSURF dstSurf, 
                    gcsRECT *dstRect)
{
    gcsRECT         dstR = *dstRect;
    int             srcOrigLeft = -1, srcOrigTop = -1;
    gceSTATUS       status;
    
    // If source rectangle is included in dstination rectangle, return directly.
    if (dstRect->left >= 0 &&
        dstRect->right <= srcWidth &&
        dstRect->top >= 0 &&
        dstRect->bottom <= srcHeight)
    {
        return TRUE;   
    }
    
    srcOrigLeft   = -dstRect->left;
    
    if (dstRect->left < 0 )
    {
        dstRect->right  -= dstRect->left;
        dstRect->left   = 0;
        dstR.right      = dstRect->right;
        dstR.left       = dstRect->left;
        
        xf86DrvMsg(0, X_ERROR, "mrvlGeneralRepeatBlt: negative left\n");   
    }
    
    srcOrigTop = -dstRect->top;
    
    if (dstRect->top < 0 )
    {
        dstRect->bottom -= dstRect->top;           
        dstRect->top    = 0;
        dstR.bottom     = dstRect->bottom;
        dstR.top        = dstRect->top;
        
        xf86DrvMsg(0, X_ERROR, "mrvlGeneralRepeatBlt: negative top\n");
    }

    status = gco2D_SetClipping(Engine2D, dstRect);
    if (status != gcvSTATUS_OK )
    {
        xf86DrvMsg(0, X_ERROR, "mrvlGeneralRepeatBlt: failed to set clipping rectangle\n");
        return FALSE;
    } 	

    switch (repeatMode)
    {
    case RepeatNormal:
    {
        mrvlNormalRepeatBlt(srcWidth,
                            srcHeight,
                            srcOrigLeft,
                            srcOrigTop,
                            srcSurf,
                            dstSurf,
                            &dstR);
        break;
    }
    
    case RepeatPad:
    case RepeatReflect:
    default:
        xf86DrvMsg(0, X_ERROR, "Unsupported repeat mode till now\n");
        return FALSE;
    }
    
    return TRUE;
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
void
mrvlWrapRBChannel(gcoSURF pSurface, unsigned int *pAddress)
{
    unsigned int    srcW, srcH;
    int             srcStride;
    PX8B8G8R8_FMT   pStartPix = (PX8B8G8R8_FMT)pAddress;
    int             i, j;

    gcoSURF_GetAlignedSize(pSurface, &srcW, &srcH, &srcStride);

    for (i = 0; i < srcH; i++)
    {
        for (j = 0; j < srcW; j++)
        {
            unsigned char b = pStartPix->b;

            pStartPix->b = pStartPix->r;
            pStartPix->r = b;

            pStartPix++;
        }
    }
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
void 
mrvlMemcpyBox (PixmapPtr pPixmap, 
                    BoxPtr pbox, 
                    CARD8 *src, 
                    int src_pitch,
	                CARD8 *dst, 
                    int dst_pitch, 
                    Bool bSrcOff, 
                    Bool bDstOff)
 {
    int i, cpp = pPixmap->drawable.bitsPerPixel / 8;
    int bytes = (pbox->x2 - pbox->x1) * cpp;

    if (bSrcOff)
    {
        src += pbox->y1 * src_pitch + pbox->x1 * cpp;
    }

    if (bDstOff)
    {
        dst += pbox->y1 * dst_pitch + pbox->x1 * cpp;
    }

    for (i = pbox->y2 - pbox->y1; i; i--) {
	memcpy (dst, src, bytes);
	src += src_pitch;
	dst += dst_pitch;
    }
}


/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
void 
mrvlMemcpy(PixmapPtr pSrc, 
                    PixmapPtr pDst, 
                    BoxPtr pSrcBox, 
                    BoxPtr pDstBox, 
                    CARD8 *src, 
                    int src_pitch, 
                    CARD8 *dst, 
                    int dst_pitch)
 {
    int i;
    int src_cpp = pSrc->drawable.bitsPerPixel / 8;
    int dst_cpp = pDst->drawable.bitsPerPixel / 8;
    int bytes = (pDstBox->x2 - pDstBox->x1) * dst_cpp;

    src += pSrcBox->y1 * src_pitch + pSrcBox->x1 * src_cpp;
    dst += pDstBox->y1 * dst_pitch + pDstBox->x1 * dst_cpp;

    for (i = pDstBox->y2 - pDstBox->y1; i; i--) {
    	memcpy (dst, src, bytes);
    	src += src_pitch;
    	dst += dst_pitch;
    }
}


/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
Bool
mrvlGeneralImageTransfer(gco2D          Engine2D,
                        unsigned int    src_paddr,
                        int             src_pitch,
                        unsigned int    dst_paddr,
                        int             dst_pitch,
                        gcsRECT         *pSrcRect,
                        gcsRECT         *pDstRect,
                        gceSURF_FORMAT  srcFormat,
                        gceSURF_FORMAT  dstFormat,
                        Bool            bCheckSrc,
                        Bool            bCheckDst,
                        unsigned int    pitchAlignment,
                        unsigned int    offsetAlignment)
{
    gcsRECT         srcRect = *pSrcRect, dstRect = *pDstRect;
    unsigned int    aligned_src_paddr = 0, aligned_src_pitch = 0, aligned_dst_paddr = 0, aligned_dst_pitch = 0;
    Bool            bSrcBlitByLine = FALSE, bDstBlitByLine = FALSE;
    gceSTATUS       status;
    int             i, cpp;

    if ((pSrcRect->right - pSrcRect->left) != (pDstRect->right - pDstRect->left) ||
        (pSrcRect->bottom - pSrcRect->top) != (pDstRect->bottom - pDstRect->top))
    {
        xf86DrvMsg(0, X_ERROR, "mrvlGeneralImageTransfer: doesn't support stretch blit\n");
        return FALSE;
    }

    if (srcFormat == gcvSURF_R5G6B5)
        cpp = 2;
    else if (srcFormat == gcvSURF_A8R8G8B8)
        cpp = 4;
    else
    {
        xf86DrvMsg(0, X_ERROR, "mrvlGeneralImageTransfer: doesn't support format\n");
        return FALSE;
    }

    if (bCheckSrc && 
        (src_paddr % offsetAlignment != 0 ||
         src_pitch % pitchAlignment != 0) )
    {
        bSrcBlitByLine = TRUE;
    }

    if (bCheckDst && 
        (dst_paddr % offsetAlignment != 0 ||
         dst_pitch % pitchAlignment != 0) )
    {
        bDstBlitByLine = TRUE;
    }

    // check if we support this blit.
    if ( bSrcBlitByLine || bDstBlitByLine)
    {
        for (i = 0; i < (pDstRect->bottom - pDstRect->top); i++)
        {     
            unsigned int    src_align, dst_align;
            unsigned int    src_start_paddr, dst_start_paddr;                    
            
            // adjust source physical address and pitch.
            if (bSrcBlitByLine)
            {               
                src_start_paddr     = src_paddr + pSrcRect->top * src_pitch + i * src_pitch;
                aligned_src_paddr   = MEM_PAGE_ALIGN_DOWN(src_start_paddr, offsetAlignment);
                src_align           = src_start_paddr - aligned_src_paddr;

                if (src_align % cpp != 0)
                {
                    xf86DrvMsg(0, X_ERROR, "mrvlGeneralImageTransfer: unsupported src alignment, %d line\n", __LINE__);
                    return FALSE;
                }
            }            
            
            // adjust dstination physical address and pitch.
            if (bDstBlitByLine)
            {                             
                dst_start_paddr     = dst_paddr + pDstRect->top * dst_pitch + i * dst_pitch;
                aligned_dst_paddr   = MEM_PAGE_ALIGN_DOWN(dst_start_paddr, offsetAlignment);
                dst_align           = dst_start_paddr - aligned_dst_paddr;       

                if (dst_align % cpp != 0)
                {
                    xf86DrvMsg(0, X_ERROR, "mrvlGeneralImageTransfer: unsupported dst alignment, %d line\n", __LINE__);
                    return FALSE;
                }         
            }            
        }
    }
  
    // offset and pitch match alignment, blit by rectangle.
    if (!bSrcBlitByLine && !bDstBlitByLine)
    {
        status = gco2D_SetClipping(Engine2D, &dstRect);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralImageTransfer: Failed to set clipping, %d line\n", __LINE__);
            return FALSE;
        }
        
        status = gco2D_SetColorSource(Engine2D, 
                                        src_paddr, 
                                        src_pitch, 
                                        srcFormat, 
                                        gcvSURF_0_DEGREE, 
                                        0, 
                                        gcvFALSE,
                                        gcvSURF_OPAQUE,
                                        0);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralImageTransfer: Failed to set color source, %d line\n", __LINE__);
            return FALSE;
        }

        status = gco2D_SetSource(Engine2D, &srcRect);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralImageTransfer: Failed to set source, %d line\n", __LINE__);
            return FALSE;
        }

        status = gco2D_SetTarget(Engine2D, 
                                dst_paddr, 
                                dst_pitch,  
                                gcvSURF_0_DEGREE,
                                0);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralImageTransfer: Failed to set target, %d line\n", __LINE__);
            return FALSE;
        }

        status = gco2D_Blit(Engine2D, 1, &dstRect, 0xCC, 0xCC, dstFormat);
        if (status != gcvSTATUS_OK)
        {
            xf86DrvMsg(0, X_ERROR, "mrvlGeneralImageTransfer: Failed to blit, %d line\n", __LINE__);
            return FALSE;
        }
    }
    else
    {              
        for (i = 0; i < (pDstRect->bottom - pDstRect->top); i++)
        {     
            unsigned int    src_align, dst_align;
            unsigned int    src_start_paddr, dst_start_paddr;                    
            
            // adjust source physical address and pitch.
            if (bSrcBlitByLine)
            {
                srcRect.top         = 0;
                srcRect.bottom      = 1;
                src_start_paddr     = src_paddr + pSrcRect->top * src_pitch + i * src_pitch;
                aligned_src_paddr   = MEM_PAGE_ALIGN_DOWN(src_start_paddr, offsetAlignment);
                src_align           = src_start_paddr - aligned_src_paddr;                
                srcRect.left        = (src_align / cpp) + pSrcRect->left;
                srcRect.right       = (src_align / cpp) + pSrcRect->right;
                aligned_src_pitch   = MEM_PAGE_ALIGN_UP((src_pitch + src_align), pitchAlignment);                      
            }
            else
            {
                srcRect.top         = pSrcRect->top + i;
                srcRect.bottom      = pSrcRect->top + i + 1;
                srcRect.left        = pSrcRect->left;
                srcRect.right       = pSrcRect->right;

                aligned_src_paddr   = src_paddr;
                aligned_src_pitch   = src_pitch;
            }
            
            // adjust dstination physical address and pitch.
            if (bDstBlitByLine)
            {             
                dstRect.top         = 0;
                dstRect.bottom      = 1;
                dst_start_paddr     = dst_paddr + pDstRect->top * dst_pitch + i * dst_pitch;
                aligned_dst_paddr   = MEM_PAGE_ALIGN_DOWN(dst_start_paddr, offsetAlignment);
                dst_align           = dst_start_paddr - aligned_dst_paddr;
                dstRect.left        = (dst_align / cpp) + pDstRect->left;
                dstRect.right       = (dst_align / cpp) + pDstRect->right;
                aligned_dst_pitch   = MEM_PAGE_ALIGN_UP((dst_pitch + dst_align), pitchAlignment);
            }
            else
            {
                dstRect.top         = pDstRect->top + i;
                dstRect.bottom      = pDstRect->top + i + 1;
                dstRect.left        = pDstRect->left;
                dstRect.right       = pDstRect->right;

                aligned_dst_paddr   = dst_paddr;
                aligned_dst_pitch   = dst_pitch;
            }

            status = gco2D_SetClipping(Engine2D, &dstRect);
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "mrvlGeneralImageTransfer: Failed to set clipping, %d line\n", __LINE__);
                return FALSE;
            }            
            
            status = gco2D_SetColorSource(Engine2D, 
                                            aligned_src_paddr, 
                                            aligned_src_pitch, 
                                            srcFormat, 
                                            gcvSURF_0_DEGREE, 
                                            0, 
                                            gcvFALSE,
                                            gcvSURF_OPAQUE,
                                            0);
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "mrvlGeneralImageTransfer: Failed to set color source, %d line\n", __LINE__);
                return FALSE;
            }
 
            status = gco2D_SetSource(Engine2D, &srcRect);
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "mrvlGeneralImageTransfer: Failed to set source, %d line\n", __LINE__);
                return FALSE;
            }      

            status = gco2D_SetTarget(Engine2D, 
                                    aligned_dst_paddr, 
                                    aligned_dst_pitch,  
                                    gcvSURF_0_DEGREE,
                                    0);
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "mrvlGeneralImageTransfer: Failed to set target, %d line\n", __LINE__);
                return FALSE;
            }      

            status = gco2D_Blit(Engine2D, 1, &dstRect, 0xCC, 0xCC, dstFormat);
            if (status != gcvSTATUS_OK)
            {
                xf86DrvMsg(0, X_ERROR, "mrvlGeneralImageTransfer: Failed to blit, %d line\n", __LINE__);
                return FALSE;
            }
        }  
    }

    status = gco2D_Flush(Engine2D);
    if (status != gcvSTATUS_OK)
    {
        xf86DrvMsg(0, X_ERROR, "mrvlGeneralImageTransfer: Failed to flush GPU cache, %d line\n", __LINE__);
        return FALSE;
    }

    return TRUE;
}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
Bool
mrvlImageTransferToScreen(PixmapPtr pDst, 
                            int x, 
                            int y, 
                            int w, 
                            int h, 
                            char *src_vaddr, 
                            int src_pitch, 
                            int syncType)
{
    unsigned int    src_paddr = 0, dst_paddr = 0, dst_pitch = 0;
    int             pixBpp = pDst->drawable.bitsPerPixel;    
    gcsRECT         srcRect, dstRect;
    gceSURF_FORMAT  format;
    gceSTATUS       status;
    void            *mapInfo;
    MRVLGetPrivateByPix(pDst);
    MRVLGetPixmapPrivate(priv, pDst);

    srcRect.left    = 0;
    srcRect.top     = 0;
    srcRect.right   = w;
    srcRect.bottom  = h;

    dstRect.left    = x;
    dstRect.top     = y;
    dstRect.right   = x + w;
    dstRect.bottom  = y + h;

    if (pixBpp == 16)
        format = gcvSURF_R5G6B5;
    else if (pixBpp == 32)
        format = gcvSURF_A8R8G8B8;
    else
    {
        xf86DrvMsg(0, X_ERROR, "mrvlImageTransferToScreen: Invalid pixmap format\n");
        return FALSE;
    }

    status = gcoOS_MapUserMemory(pDev->exaInfo.Os, src_vaddr, src_pitch * h, &mapInfo, &src_paddr);
    if (status != gcvSTATUS_OK)
    {
        xf86DrvMsg(0, X_ERROR, "mrvlImageTransferToScreen: Failed to map user memory\n");
        return FALSE;
    }

    dst_paddr = priv->dwPhyAddr;
    dst_pitch = priv->iAlignedStride;

    if (!mrvlGeneralImageTransfer(pDev->exaInfo.Engine2D,
                                src_paddr,                                
                                src_pitch,
                                dst_paddr,
                                dst_pitch,
                                &srcRect,
                                &dstRect,
                                format,
                                format,
                                TRUE,
                                FALSE,
                                pDev->exaInfo.ExaDriver->pixmapPitchAlign,
                                pDev->exaInfo.ExaDriver->pixmapOffsetAlign))
    {
        xf86DrvMsg(0, X_ERROR, "mrvlImageTransferToScreen: General image transfer failed\n");
        gcoHAL_ScheduleUnmapUserMemory(pDev->exaInfo.Hal, mapInfo, src_pitch * h, src_paddr, src_vaddr);
        return FALSE;
    }

    mrvlFencePoolCommit(pDst->drawable.pScreen, priv->pFakeFence); 

    status = gcoHAL_ScheduleUnmapUserMemory(pDev->exaInfo.Hal, mapInfo, src_pitch * h, src_paddr, src_vaddr);
    if (status != gcvSTATUS_OK)
    {
        xf86DrvMsg(0, X_ERROR, "mrvlImageTransferToScreen: Failed to map user memory\n");
        return FALSE;
    }

    if (syncType == 1)
    {
        gcoHAL_Commit(pDev->exaInfo.Hal, FALSE);
    }
    else if (syncType == 2)
    {
        mrvlFencePoolStall(priv->pFakeFence);
    }
    else if (syncType == 3)
    {
        gcoHAL_Commit(pDev->exaInfo.Hal, TRUE);
    }

    return TRUE;

}

/*******************************************************************************
* xxx:
*
* DESCRIPTION: 
*
* INPUTS:
*
*
*
* RETURNS:
*
*
* COMMENTS:
*
*
*******************************************************************************/
Bool
mrvlImageTransferFromScreen(PixmapPtr pSrc, 
                            int x, 
                            int y, 
                            int w, 
                            int h, 
                            char *dst_vaddr, 
                            int dst_pitch, 
                            int syncType)
{
    unsigned int    src_paddr = 0, src_pitch = 0, dst_paddr = 0;
    int             pixBpp = pSrc->drawable.bitsPerPixel;
    gcsRECT         srcRect, dstRect;
    gceSURF_FORMAT  format;
    gceSTATUS       status;
    void            *mapInfo;
    MRVLGetPrivateByPix(pSrc);
    MRVLGetPixmapPrivate(priv, pSrc);

    srcRect.left    = x;
    srcRect.top     = y;
    srcRect.right   = x + w;
    srcRect.bottom  = y + h;

    dstRect.left    = 0;
    dstRect.top     = 0;
    dstRect.right   = w;
    dstRect.bottom  = h;

    if (pixBpp == 16)
        format = gcvSURF_R5G6B5;
    else if (pixBpp == 32)
        format = gcvSURF_A8R8G8B8;
    else
    {
        xf86DrvMsg(0, X_ERROR, "mrvlImageTransferFromScreen: Invalid pixmap format\n");
        return FALSE;
    }

    status = gcoOS_MapUserMemory(pDev->exaInfo.Os, dst_vaddr, dst_pitch * h, &mapInfo, &dst_paddr);
    if (status != gcvSTATUS_OK)
    {
        xf86DrvMsg(0, X_ERROR, "mrvlImageTransferFromScreen: Failed to map user memory\n");
        return FALSE;
    }

    src_paddr = priv->dwPhyAddr;
    src_pitch = priv->iAlignedStride;

    if (!mrvlGeneralImageTransfer(pDev->exaInfo.Engine2D,
                                src_paddr,
                                src_pitch,
                                dst_paddr,
                                dst_pitch,
                                &srcRect,
                                &dstRect,
                                format,
                                format,
                                FALSE,
                                TRUE,
                                pDev->exaInfo.ExaDriver->pixmapPitchAlign,
                                pDev->exaInfo.ExaDriver->pixmapOffsetAlign))
    {
        xf86DrvMsg(0, X_ERROR, "mrvlImageTransferFromScreen: General image transfer failed\n");
        gcoHAL_ScheduleUnmapUserMemory(pDev->exaInfo.Hal, mapInfo, dst_pitch * h, dst_paddr, dst_vaddr);
        return FALSE;
    }

    mrvlFencePoolCommit(pSrc->drawable.pScreen, priv->pFakeFence);        

    status = gcoHAL_ScheduleUnmapUserMemory(pDev->exaInfo.Hal, mapInfo, dst_pitch * h, dst_paddr, dst_vaddr);
    if (status != gcvSTATUS_OK)
    {
        xf86DrvMsg(0, X_ERROR, "mrvlImageTransferFromScreen: Failed to map user memory\n");
        return FALSE;
    }

    if (syncType == 1)
    {
        gcoHAL_Commit(pDev->exaInfo.Hal, FALSE);
    }
    else if (syncType == 2)
    {
        mrvlFencePoolStall(priv->pFakeFence);
    }
    else if (syncType == 3)
    {
        gcoHAL_Commit(pDev->exaInfo.Hal, TRUE);
    }

    return TRUE;
}

