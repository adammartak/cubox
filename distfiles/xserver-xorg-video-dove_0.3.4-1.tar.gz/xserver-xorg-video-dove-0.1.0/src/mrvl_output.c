//#include "mrvl.h"
#include "dovefb_driver.h"

#include <linux/fb.h>
#include <sys/ioctl.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <linux/types.h>
#include <video/dovefb.h>
#include <sys/mman.h>
#include <stdlib.h>

extern XF86ConfigPtr xf86configptr;

static MRVLOutputPrivateRec mrvlOutputPrivate[MRVL_MAX_CRTC_COUNT];
#define mode_num 20
#define DIGITAL(x) x

struct simple_mode_info {
    int                         Refresh;        /* refresh rate */
    int                         HDisplay;       /* horizontal timing */
    int                         VDisplay;       /* vertical timing */
};

struct mode_info {
    int                         Clock;          /* pixel clock freq (kHz) */
    int                         HDisplay;       /* horizontal timing */
    int                         HSyncStart;
    int                         HSyncEnd;
    int                         HTotal;
    int                         VDisplay;       /* vertical timing */
    int                         VSyncStart;
    int                         VSyncEnd;
    int                         VTotal;
    int                         Flags;
};

typedef enum {
	OPTION_ENABLE,
	OPTION_DISABLE,
	OPTION_NoDDCValue,
	OPTION_NonDDCDefaultMode,
	OPTION_MON_VGA,
	OPTION_MON_LVDS
} LcdEnableOpts;

static OptionInfoRec LcdEnableOptions[] = {
	{OPTION_ENABLE,            "Enable",            OPTV_BOOLEAN, {0}, FALSE },
	{OPTION_DISABLE,           "Disable",           OPTV_BOOLEAN, {0}, FALSE },
	{OPTION_NoDDCValue,        "NoDDCValue",        OPTV_BOOLEAN, {0}, FALSE },
	{OPTION_NonDDCDefaultMode, "NonDDCDefaultMode", OPTV_STRING,  {0}, FALSE },
        {OPTION_MON_VGA,           "Monitor-VGA",       OPTV_STRING,  {0}, FALSE },
        {OPTION_MON_LVDS,          "Monitor-lvds",      OPTV_STRING,  {0}, FALSE },
	{-1,                        NULL,               OPTV_NONE,    {0}, FALSE },
};


/* Built-in Timings Table. */
static struct mode_info built_in_mode[mode_num] = {
    { 154000,  1920, 1968, 2000, 2080,  1200, 1203, 1209, 1235, V_PHSYNC|V_NVSYNC },  /*  1 */
    { 148500,  1920, 2008, 2052, 2200,  1080, 1084, 1089, 1125, V_PHSYNC|V_NVSYNC },  /*  2 */
    { 162000,  1600, 1664, 1856, 2160,  1200, 1201, 1204, 1250, V_PHSYNC|V_PVSYNC },  /*  3 */
    { 146250,  1680, 1784, 1960, 2240,  1050, 1053, 1059, 1089, V_NHSYNC|V_PVSYNC },  /*  4 */
    { 135000,  1280, 1296, 1440, 1688,  1024, 1025, 1028, 1066, V_PHSYNC|V_PVSYNC },  /*  5 */
    { 118250,  1600, 1696, 1856, 2112,   900,  903,  908,  934, V_NHSYNC|V_PVSYNC },  /*  6 */
    { 108000,  1280, 1328, 1440, 1688,  1024, 1025, 1028, 1066, V_PHSYNC|V_PVSYNC },  /*  7 */
    { 106500,  1440, 1520, 1672, 1904,   900,  903,  909,  934, V_NHSYNC|V_PVSYNC },  /*  8 */
    { 108000,  1280, 1376, 1488, 1800,   960,  961,  964, 1000, V_PHSYNC|V_PVSYNC },  /*  9 */
    {  85750,  1366, 1436, 1579, 1792,   768,  771,  774,  798, V_PHSYNC|V_NVSYNC },  /* 10 */
    {  83500,  1280, 1352, 1480, 1680,   800,  803,  809,  831, V_NHSYNC|V_PVSYNC },  /* 11 */
    {  81620,  1152, 1216, 1336, 1520,   864,  865,  868,  895, V_NHSYNC|V_PVSYNC },  /* 12 */
    {  68250,  1280, 1328, 1360, 1440,   768,  771,  778,  790, V_PHSYNC|V_NVSYNC },  /* 13 */
    {  74480,  1280, 1336, 1472, 1664,   720,  721,  724,  746, V_NHSYNC|V_PVSYNC },  /* 14 */
    {  65000,  1024, 1048, 1184, 1344,   768,  771,  777,  806, V_NHSYNC|V_NVSYNC },  /* 15 */
    {  44640,  1024, 1062, 1162, 1200,   600,  608,  612,  620, V_PHSYNC|V_NVSYNC },  /* 16 */
    {  40000,   800,  840,  968, 1056,   600,  601,  605,  628, V_PHSYNC|V_PVSYNC },  /* 17 */
    {  36000,   800,  824,  896, 1024,   600,  601,  603,  625, V_PHSYNC|V_PVSYNC },  /* 18 */
    {  30120,   800 , 840,  844,  1056,  480,  490,  494,  525, V_PHSYNC|V_PVSYNC },  /* 19 */ /* MMP2 */
    {  25180,   640,  656,  752,  800,   480,  490,  492,  525, V_NHSYNC|V_NVSYNC }   /* 20 */
};

int mrvl_output_get_fb_info(xf86OutputPtr output,
        struct fb_fix_screeninfo *fix,
	struct fb_var_screeninfo *var,
	char** iobase)
{
    FBDevRec* pDev;
    ScrnInfoPtr pScrn;
    int fd;
    struct fb_fix_screeninfo local_fix;
    MRVLCrtcPrivatePtr pCrtcPriv;

    pScrn = output->scrn;
    pDev = FBDEVPTR(pScrn);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Enter mrvl_output_get_fb_info()\n");
    pCrtcPriv = (MRVLCrtcPrivatePtr)output->crtc->driver_private;

    fd = pDev->gfx_fd[pCrtcPriv->crtc_id];

    if(fd < 0) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "failed to open fb for CRTC%d\n", pCrtcPriv->crtc_id);
        return -1;
    } else {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Open fb for CRTC%d [%p] successfully\n",
            pCrtcPriv->crtc_id, output->crtc);
    }

    /* Get fix screen info */
    if (!fix)
	fix = &local_fix;

    if (ioctl(fd, FBIOGET_FSCREENINFO, fix)) {
        return -1;
    }

    /* mmap to reg base. */
    if (iobase)
        if ((*iobase = (char *) mmap(0, 0x1C4, PROT_READ | PROT_WRITE, MAP_SHARED, fd, fix->smem_len)) == (char *) -1) {
            return -1;
        }

    /* Get var screen info */
    if (var)
        if (ioctl(fd, FBIOGET_VSCREENINFO, var)) {
            return -1;
        }
 
    return fd;
}

int mrvl_output_config(xf86OutputPtr output, struct fb_var_screeninfo *var)
{
    int fd;
    FBDevRec* pDev;
    ScrnInfoPtr pScrn;
    MRVLOutputPrivatePtr private_data;

    pScrn = output->scrn;
    pDev = FBDEVPTR(pScrn);

    fd = mrvl_output_get_fb_info(output, 0, 0, 0);

    /*
     * if no var, we apply curent setting again.
     */
    if (var == 0) {
        /* get current setting. */
        private_data = (MRVLOutputPrivatePtr)output->driver_private;
        var = (struct fb_var_screeninfo*)private_data->cur_mode;
    }

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "switch to <%dx%d>....\n", var->xres, var->yres);
    /*
     * apply new setting
     */
    if (ioctl(fd, FBIOPUT_VSCREENINFO, var) == -1) 
    {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "mrvl_check_current_pos: FBIOPUT_VSCREENINFO FAILED \n"
            "Please check virtual desktop won't exceed 2048x2048 @32bpp\n");
        return -1;
    }

    return 0;
}

/*
 * return 0, mode is valid and store parsed info in parameter mode.
 * return -1, mode is not valid. Can't find "x". (case-sensetive).
 */
static int parse_dft_mode(char *mode_str, struct simple_mode_info *mode)
{
    char *cur, *w_str, *h_str, *refresh_str;
    int w, h, refresh;
    char *str_head, *str;

    if (!mode_str) return -2;

    str_head = str = strdup(mode_str);

    w_str = h_str = refresh_str = 0;

    //xf86DrvMsg(0, X_INFO, "#*** str = <%s>\n", str);
    if ((cur = strstr(str, "x"))) {
	w_str = str;
	*cur = '\0';
        //xf86DrvMsg(0, X_INFO, "#*** 1. w_str = <%s>\n", w_str);
	str = cur+1;
    } else {
        return -1;
    }

    h_str = str;
    if ((cur = strstr(str, "@"))) {
        *cur = '\0';
        refresh_str = cur+1;
    }

    //xf86DrvMsg(0, X_INFO, "#*** 2. h_str = <%s>\n", h_str);
    //xf86DrvMsg(0, X_INFO, "#*** 3. refresh_str = <%s>\n", refresh_str);
    w       = atoi(w_str); 
    h       = atoi(h_str); 
    refresh = atoi(refresh_str);

    free(str_head);

    if (w <= 0)	w = 1024;
    if (h <= 0)	w = 768;
    if (refresh <= 0)	w = 60;

    mode->HDisplay = w;
    mode->VDisplay = h;
    mode->Refresh = refresh;

    return 0;
}

#define DFT_RESOLUTION_W	1024
#define DFT_RESOLUTION_H	768
#define DFT_RESOLUTION_REFRESH	60

static int search_mode_index(struct mode_info *modes, int width, int height)
{
    if (modes) {
        int i;

        for (i = 0; i < mode_num; i++) {
            if ((width == modes[i].HDisplay) && (height == modes[i].VDisplay))
                break;
        }

        if (i >= mode_num)
            return -2;

        return i;
    }

    return -1;
}

static void print_default_timing_table(int scrnIndex, struct mode_info *modes)
{
    if (modes) {
        int i;

        for (i = 0; i < mode_num; i++) {
            xf86DrvMsg(scrnIndex, X_INFO, "Mode[0] <%4dx%4d@%d>\n",
            modes[i].HDisplay,
            modes[i].VDisplay,
            (modes[i].Clock * 1000) / (modes[i].HTotal * modes[i].VTotal));
        }
    } else
        xf86DrvMsg(scrnIndex, X_WARNING, "modes is NULL\n");
}

static int config_mode(DisplayModePtr new, struct mode_info *pMode, int refresh)
{
    if (new && pMode) {
        if (refresh)
            new->Clock  = ((pMode->HTotal * pMode->VTotal * refresh) / 1000);
        else
            new->Clock  = pMode->Clock;
        new->HDisplay   = pMode->HDisplay;
        new->HSyncStart = pMode->HSyncStart;
        new->HSyncEnd   = pMode->HSyncEnd;
        new->HTotal     = pMode->HTotal;
        new->HSkew      = 0;
        new->VDisplay   = pMode->VDisplay;
        new->VSyncStart = pMode->VSyncStart;
        new->VSyncEnd   = pMode->VSyncEnd;
        new->VTotal     = pMode->VTotal;
        new->VScan      = 0;
        new->Flags      &= ~(pMode->Flags);
        new->Flags      |= pMode->Flags;
    }

    return -1;
}

static DisplayModePtr
mrvl_get_common_modes(xf86OutputPtr output, DisplayModePtr modes)
{
    int i;
    DisplayModePtr new;
    ScrnInfoPtr             pScrn = output->scrn;
    char *NoDDCDefaultMode;
    XF86ConfMonitorPtr monptr = 0;
    OptionInfoPtr lcd_options;

    if (output->conf_monitor) {
        struct simple_mode_info mode;
        monptr = output->conf_monitor;
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "monitor id: <%s>\n", monptr->mon_identifier);

        /* Parse the options in Monitor section of xorg.conf */
        lcd_options = xalloc (sizeof (LcdEnableOptions));
        memcpy (lcd_options, LcdEnableOptions, sizeof (LcdEnableOptions));
        xf86ProcessOptions (pScrn->scrnIndex, monptr->mon_option_lst, lcd_options);

        NoDDCDefaultMode = xf86GetOptValString(lcd_options, OPTION_NonDDCDefaultMode);
        if (NoDDCDefaultMode) {
            int result;

            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Mode string is = <%s>\n",
                NoDDCDefaultMode);
            result = parse_dft_mode(NoDDCDefaultMode, &mode);

            if (!result) {
                xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Mode string is valid, Mode = <%dx%d@%d>\n",
                    mode.HDisplay,
                    mode.VDisplay,
                    mode.Refresh);
                
            } else {
                xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Parse Error!!, we set to 1024x768@60.\n");
                mode.HDisplay = DFT_RESOLUTION_W;
                mode.VDisplay = DFT_RESOLUTION_H;
                mode.Refresh  = DFT_RESOLUTION_REFRESH;
            }

            /* add default mode for non-DDC mode.*/
            new = xf86CVTMode(mode.HDisplay, mode.VDisplay, mode.Refresh, FALSE, FALSE);

                        
            new->type       = M_T_PREFERRED;

            i = search_mode_index(built_in_mode, mode.HDisplay, mode.VDisplay);

            if (0 <= i) {
                config_mode(new, &built_in_mode[i], mode.Refresh);
            } else {
                xf86DrvMsg(pScrn->scrnIndex, X_WARNING,
                    "Please set right NonDDCDefaultMode,"
                    " should choose one from default table as below:\n");
                print_default_timing_table(pScrn->scrnIndex, built_in_mode);
                
                xf86DrvMsg(pScrn->scrnIndex, X_WARNING, "We fall back to pick 1024x768@60 now!!\n");
                i = search_mode_index(built_in_mode, DFT_RESOLUTION_W, DFT_RESOLUTION_H);
                config_mode(new, &built_in_mode[i], 0);
            }

            modes = xf86ModesAdd(modes, new);   
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Insert a preferred mode = <%dx%d@%d>\n",
                    new->HDisplay,
                    new->VDisplay,
                    mode.Refresh);
        } else {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "No default mode option, we set to 1024x768@60.\n");
        }

	xfree(lcd_options);
    } else {
        xf86DrvMsg(pScrn->scrnIndex, X_WARNING, "No output monitor, Can't get option list!!\n");
    }

    for (i = 0; i < mode_num; i++) {
	
        /* Create mode structure. */
        new = xf86CVTMode(  built_in_mode[i].HDisplay,
                  built_in_mode[i].VDisplay,
                  built_in_mode[i].Clock/(built_in_mode[i].HTotal*built_in_mode[i].VTotal),
                  FALSE, FALSE);

	if ((!NoDDCDefaultMode) &&
            (new->HDisplay == DFT_RESOLUTION_W) &&
            (new->VDisplay == DFT_RESOLUTION_H)) {
            new->type       = M_T_PREFERRED;
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Insert default preferred %4dx%4d mode\n",
		built_in_mode[i].HDisplay,
		built_in_mode[i].VDisplay);
        } else {
            new->type       = M_T_DRIVER;
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Insert default built-in %3dx%3d mode\n",
		built_in_mode[i].HDisplay,
		built_in_mode[i].VDisplay);
        }

        config_mode(new, &built_in_mode[i], 0);
        modes = xf86ModesAdd(modes, new);   
    }

    return modes;
}

#if MRVL_RANDR_EDID_MODES
static xf86OutputStatus
mrvl_detect_with_edid(xf86OutputPtr output)
{
    ScrnInfoPtr             pScrn = output->scrn;
    MRVLOutputPrivatePtr    pOutputPriv = (MRVLOutputPrivatePtr)output->driver_private;
    int                     lcd;
    struct _sEdidInfo       edid_info;
    MRVLGetPrivateByScrn(pScrn);
    int i, lcd_status, noddc;
    OptionInfoPtr lcd_options;
    XF86ConfMonitorPtr monptr = 0;
    int *pCurConnectStatus;
    int *pConnectStatus[2];
    char *mon_vga, *mon_lvds;
    FBDevPtr fPtr;

    fPtr = FBDEVPTR(pScrn);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "enter mrvl_detect_edid, there are %d crtc, output %d\n",
        (int)pDev->crtc_num, (int)(output->possible_crtcs >> 1));

    pCurConnectStatus = &pDev->controller[output->possible_crtcs >> 1].output_connected;
    pConnectStatus[0] = &pDev->controller[0].output_connected;

    pOutputPriv->edid_valid     = 0;    
    pOutputPriv->edid_is_hdmi   = 0;

    if (2 <= pDev->crtc_num) 
        pConnectStatus[1] = &pDev->controller[1].output_connected;

    /*
     * Do correction for DVI2VGA and Y-Cable.
     * Check monitor's input type is digital or analog input to
     * enable or disable monitor automatically.
     */
    if (*(pConnectStatus[output->possible_crtcs >> 1])) {
        /* EDID is presented. */
        int lcd;
        struct _sEdidInfo       edid_info;

        /* 0. Get Current EDID status. */
        lcd = pDev->gfx_fd[output->possible_crtcs >> 1];
        ioctl(lcd, DOVEFB_IOCTL_GET_EDID_INFO, &edid_info);

        /* 1. Clear EDID buffer. */
        memset(pOutputPriv->edid_raw_data,
            0,
            EDID_LENGTH * (edid_info.extension + 1));

        /* 2. Get EDID*/
        ioctl(lcd, DOVEFB_IOCTL_GET_EDID_DATA, pOutputPriv->edid_raw_data);

        /* 3. Check EDID is valid. */
        if (mrvl_edid_is_valid((struct edid *)pOutputPriv->edid_raw_data)) {
            /*
             * EDID is valid, we keep check whether EDID cames from right input
             * lvds should get digital EDID and VGA gets analog EDID.
             */
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "*#* output<%d> is %s.\n",
                (signed int)(output->possible_crtcs >> 1),
                (pOutputPriv->edid_raw_data[20] & 0x80) ? "digital" : "analog");
        
            if ((output->possible_crtcs >> 1) ^ ((pOutputPriv->edid_raw_data[20] >> 7) & 0x1)) {
                /* EDID input type match LCD type, do nothing. */
                ;
            } else {
                /*
                 * Because EDID reports different input type from lvds or VGA channel.
                 * we should use this EDID for this port.
                 */
                xf86DrvMsg(pScrn->scrnIndex, X_WARNING, "*#* output%d get %s input\n",
                    (signed int)(output->possible_crtcs >> 1), (pOutputPriv->edid_raw_data[20] & 0x80) ? "digital" : "analog" );
                if (!pDev->EnableDualDisplay)
                    *(pConnectStatus[output->possible_crtcs >> 1]) = 0;
                else
                    *(pConnectStatus[output->possible_crtcs >> 1]) = 3;
            }
        }
    }

    if (output->conf_monitor) {
	monptr = output->conf_monitor;
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "monitor id: <%s>\n", monptr->mon_identifier);

        /* Parse the options in Monitor section of xorg.conf */
        lcd_options = xalloc (sizeof (LcdEnableOptions));
        memcpy (lcd_options, LcdEnableOptions, sizeof (LcdEnableOptions));

        xf86ProcessOptions (pScrn->scrnIndex, monptr->mon_option_lst, lcd_options);

        /* get OPTION_ENABLE in Monitor section of xorg.conf */
        if( !xf86GetOptValBool(lcd_options, OPTION_ENABLE, &lcd_status)) {
            lcd_status = 1;
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "OPTION_ENABLE not define\n");
        } else {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "OPTION_ENABLE in config file = %d.\n", lcd_status);
        }

        /* get OPTION_NoDDCValue in Monitor section of xorg.conf */
        if( !xf86GetOptValBool(lcd_options, OPTION_NoDDCValue, &noddc)) {
            noddc = 0;
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "OPTION_NoDDCValue not define\n");
        }
        xfree(lcd_options);
 
    } else {
        monptr = NULL;
        lcd_status = 1;
        noddc = 0;
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "output->conf_monitor is NULL.\n");
    }

    /*
     * If xorg.conf specifies monitor-lvds or monitor-vga in device section.
     * We treat is as enable/disable monitor keyword.
     */
    mon_lvds  = xf86FindOptionValue(fPtr->pEnt->device->options, "Monitor-lvds");
    mon_vga   = xf86FindOptionValue(fPtr->pEnt->device->options, "Monitor-VGA");

    if (mon_lvds || mon_vga) {
        if ((0 == (output->possible_crtcs >> 1)) && !mon_lvds)
            lcd_status = 0;
    
        if ((1 == (output->possible_crtcs >> 1)) && !mon_vga)
            lcd_status = 0;
    }
    
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "In output %d, has %s, has %s in device section in xorg.conf.\n",
        (int)(output->possible_crtcs >> 1),
        (mon_lvds ? "monitor-lvds" : "no monitor-lvds"),
        (mon_vga ? "monitor-VGA" : "no monitor-VGA")
        );

    if (!((mon_lvds != 0) ^ (mon_vga != 0)) &&
        !pDev->EnableDualDisplay && 2 <= pDev->crtc_num) {
        /*
         * Special feature to disable dual display, we always enable only one
         * display at a time unless no monitor is detected.
         */
        int lcd[2];
        struct _sEdidInfo       edid_info[2];

        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "*** dual display mode is disabled.\n");
        lcd[0] = pDev->gfx_fd[0];
        lcd[1] = pDev->gfx_fd[1];

        ioctl(lcd[0], DOVEFB_IOCTL_GET_EDID_INFO, &edid_info[0]);
        ioctl(lcd[1], DOVEFB_IOCTL_GET_EDID_INFO, &edid_info[1]);
         
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "*#** (*pConnectStatus[0])=%d\n", (*pConnectStatus[0]));
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "*#** (*pConnectStatus[1])=%d\n", (*pConnectStatus[1]));

        if ((1 == (*pConnectStatus[0]) || 3 == (*pConnectStatus[0])) &&
            (1 == (*pConnectStatus[1]) || 3 == (*pConnectStatus[1]))) {
            /* if there are two monitor connected, we disable VGA. */
            if (0 == (output->possible_crtcs >> 1)) {
                pOutputPriv->edid_valid = 1;
                return XF86OutputStatusConnected;
            } else
                return XF86OutputStatusDisconnected;
        } else if ((0 == (*pConnectStatus[0]) || 2 == (*pConnectStatus[0])) &&
                   (1 == (*pConnectStatus[1]) || 3 == (*pConnectStatus[1]))) {
            /* if lcd0 detect fail, we enable VGA only. */
            if (0 == (output->possible_crtcs >> 1))
                return XF86OutputStatusDisconnected;
            else {
                pOutputPriv->edid_valid = 1;
                return XF86OutputStatusConnected;
            }
        } else if ((1 == (*pConnectStatus[0]) || 3 == (*pConnectStatus[0])) &&
                   (0 == (*pConnectStatus[1]) || 2 == (*pConnectStatus[1]))) {
            /* if lcd0 detect fail, we enable VGA only. */
            if (0 == (output->possible_crtcs >> 1)) {
                pOutputPriv->edid_valid = 1;
                return XF86OutputStatusConnected;
            } else
                return XF86OutputStatusDisconnected;
        } else {
            /* else we do nothing. */
            ;
        }
    }

    /*
     * Check whether EDID conflicts with xorg.conf settings.
     * For example, enable LVDS but EDID is only available from VGA.
     */
    if ((1 == (*pConnectStatus[output->possible_crtcs >> 1])) || lcd_status) {
        lcd_status = 1;
        if (!(1 == (*pConnectStatus[output->possible_crtcs >> 1])))
            *pCurConnectStatus = 2;
    }

    lcd = pDev->gfx_fd[output->possible_crtcs >> 1];

    if (lcd < 0) {
        goto dummy_check;
    }

    ioctl(lcd, DOVEFB_IOCTL_GET_EDID_INFO, &edid_info);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "pCurConnectStatus=%d\n", *pCurConnectStatus);
    if(*pCurConnectStatus)
    {
        if(edid_info.extension > MRVL_MAX_EDID_EXT_NUM)
        {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "EDID extension number (%d) exceeds MRVL limitation (%d)\n", edid_info.extension, MRVL_MAX_EDID_EXT_NUM);
            edid_info.extension = MRVL_MAX_EDID_EXT_NUM;
        }

        memset(pOutputPriv->edid_raw_data, 0, EDID_LENGTH * (edid_info.extension + 1));

        ioctl(lcd, DOVEFB_IOCTL_GET_EDID_DATA, pOutputPriv->edid_raw_data);

        if (mrvl_edid_is_valid((struct edid *)pOutputPriv->edid_raw_data))
        {
            pOutputPriv->edid_valid = 1;
        }

        if (mrvl_detect_hdmi_monitor((struct edid *)pOutputPriv->edid_raw_data))
        {
            pOutputPriv->edid_is_hdmi = 1;
        }

        if (pOutputPriv->edid_is_hdmi)
        {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Detect HDMI monitor connected on output%d!\n", (output->possible_crtcs == 1) ? 0 : 1);
        }
        else
        {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Detect monitor connected on output%d!\n", (output->possible_crtcs == 1) ? 0 : 1);
        }

        ioctl(lcd, DOVEFB_IOCTL_SET_EDID_INTERVAL, 5);

        if (output->crtc == NULL)
            output->crtc = pDev->pCrtc[output->possible_crtcs];

        pOutputPriv->edid_dummy     = 0;
        if (noddc || 2 == *pCurConnectStatus || 3 == *pCurConnectStatus) {
            /* setup ignore edid data to force driver using built-in modes. */
            pOutputPriv->edid_valid = 0;
        }

        if (lcd_status) {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Enable Output %d.\n", (int)(output->possible_crtcs >> 1));
            return XF86OutputStatusConnected;
        }

        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "config file set output%d to \"Enable\"=\"false\".\n",
            (int)(output->possible_crtcs >> 1));
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Disable Output %d.\n", (int)(output->possible_crtcs >> 1));
        return XF86OutputStatusDisconnected;
    }

dummy_check:

    for (i = 0; i < pDev->crtc_num; i++)
    {
        if (pDev->controller[i].output_connected != 0)
            break;
    }

    // If no monitors is connected for all crtcs, just set a dummy output for crtc 0.
    if (i >= pDev->crtc_num && output->possible_crtcs == 1)
    {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "No monitors found for output [%p], use dummy output\n", output);

        pOutputPriv->edid_dummy     = 1;

        return XF86OutputStatusConnected;
    }

    return XF86OutputStatusDisconnected;
}

extern xf86MonPtr
xf86InterpretEDID(int scrnIndex, Uchar *block);

#if 0 /* code sample */
static const char *digital_interfaces[] = {
    "undefined",
    "DVI",
    "HDMI-a",
    "HDMI-b",
    "MDDI",
    "DisplayPort",
    "unknown"
};

static void 
print_input_features(int scrnIndex, struct disp_features *c,
		     struct edid_version *v)
{
    if (DIGITAL(c->input_type)) {
	xf86DrvMsg(scrnIndex, X_INFO, "Digital Display Input\n");
	if (v->revision == 2 || v->revision == 3) {
	    if (DFP1(c->input_dfp))
		xf86DrvMsg(scrnIndex, X_INFO, "DFP 1.x compatible TMDS\n");
	} else if (v->revision >= 4) {
	    int interface = c->input_interface;
	    int bpc = c->input_bpc;
	    if (interface > 6)
		interface = 6; /* unknown */
	    if (bpc == 0 || bpc == 7)
		xf86DrvMsg(scrnIndex, X_INFO, "Undefined color depth\n");
	    else
		xf86DrvMsg(scrnIndex, X_INFO, "%d bits per channel\n",
			   bpc * 2 + 4);
	    xf86DrvMsg(scrnIndex, X_INFO, "Digital interface is %s\n",
		       digital_interfaces[interface]);
	}
    } else {
	xf86DrvMsg(scrnIndex,X_INFO,"Analog Display Input,  ");
	xf86ErrorF("Input Voltage Level: ");
	switch (c->input_voltage){
	case V070:
	    xf86ErrorF("0.700/0.300 V\n");
	    break;
	case V071:
	    xf86ErrorF("0.714/0.286 V\n");
	    break;
	case V100:
	    xf86ErrorF("1.000/0.400 V\n");
	    break;
	case V007:
            xf86ErrorF("0.700/0.700 V\n");
	    break;
	default:
	    xf86ErrorF("undefined\n");
	}
	if (SIG_SETUP(c->input_setup))
	    xf86DrvMsg(scrnIndex,X_INFO,"Signal levels configurable\n");
	xf86DrvMsg(scrnIndex,X_INFO,"Sync:");
	if (SEP_SYNC(c->input_sync))
	    xf86ErrorF("  Separate");
	if (COMP_SYNC(c->input_sync))
	    xf86ErrorF("  Composite");
	if (SYNC_O_GREEN(c->input_sync))
	    xf86ErrorF("  SyncOnGreen");
	if (SYNC_SERR(c->input_sync)) 
	    xf86ErrorF("Serration on. "
		       "V.Sync Pulse req. if CompSync or SyncOnGreen\n");
	else xf86ErrorF("\n");
    }
}
 

static void print_display(int scrnIndex, struct disp_features *disp,
              struct edid_version *v)
{
	print_input_features(scrnIndex, disp, v);
}
#endif

static unsigned int is_digital_monitor(xf86MonPtr mon)
{
    int scrnIndex = mon->scrnIndex;
    struct disp_features *c = &mon->features;

    if (DIGITAL(c->input_type)) {
	xf86DrvMsg(scrnIndex, X_INFO, "Digital Display Input.\n");
	return 1;
    } else {
	xf86DrvMsg(scrnIndex, X_INFO, "Analog Display Input.\n");
	return 0;
    }

    return 0;
}

static DisplayModePtr mrvl_additional_quirk(ScrnInfoPtr pScrn,
	DisplayModePtr          modes,
	struct edid             *edid,
	xf86MonPtr              mon)
{
    unsigned int product_id = 0;
    DisplayModePtr m = modes, m_ptr, m_head, m_last, m_last2;
    char edid_vendor[3];
    struct monitor_ranges   *ranges = &mon->det_mon[1].section.ranges;

    /* Get product id. */
    product_id = ((edid)->prod_code[0] | ((edid)->prod_code[1] << 8));

    /* Get vendor id. */
    edid_vendor[0] = ((edid->mfg_id[0] & 0x7c) >> 2) + '@';
    edid_vendor[1] = (((edid->mfg_id[0] & 0x3) << 3) |
                     ((edid->mfg_id[1] & 0xe0) >> 5)) + '@';
    edid_vendor[2] = (edid->mfg_id[1] & 0x1f) + '@';

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "%s: vendor = %c%c%c\n", __func__,
		edid_vendor[0],
		edid_vendor[1],
		edid_vendor[2]);

    if ((0 == is_digital_monitor(mon)) &&            /* Analog Input */
        (0 == strncmp(edid_vendor, "ACR", 3)) &&     /* Acer Monitor */
        (0x114 == product_id)) {                     /* Product id */

        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "===> Addtional quirk matched.\n");
        m_head = m;
	m_last2 = m;
	m_last = m;

	for (m_ptr = m_head; m_ptr != NULL; m_ptr = m_ptr->next) {
		m_last2 = m_last;
		m_last = m_ptr;
	}

        /* Prepare new list. */
	m_last2->next = NULL; //m_head;
	m_last->next = m_head->next;
	m_head->next = NULL;
	xfree(m_head);
	modes = m_last;

        /* refine the criteria for xserver. */
        ranges->max_clock = 200;
    }

    return modes;
}

static DisplayModePtr
mrvl_get_modes_with_edid(xf86OutputPtr output)
{
    ScrnInfoPtr             pScrn = output->scrn;
    MRVLOutputPrivatePtr    pOutputPriv = (MRVLOutputPrivatePtr)output->driver_private;
    xf86MonPtr              ddc_mon = NULL, mon;
    DisplayModePtr          modes = NULL;
    struct edid             *edid = (struct edid *)pOutputPriv->edid_raw_data;

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvl_get_modes_with_edid!\n");

    if (output->status != XF86OutputStatusConnected)
    {
        return NULL;
    }

    if (pOutputPriv->edid_valid)
    {
        ddc_mon = xf86InterpretEDID(output->scrn->scrnIndex, pOutputPriv->edid_raw_data);

        if (ddc_mon == NULL)
        {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Invalid edid data for output [%p]\n", output);
            return NULL;
        }

        xf86OutputSetEDID(output, ddc_mon);
	mon = ddc_mon;
        modes = xf86DDCGetModes(output->scrn->scrnIndex, ddc_mon);

	/* fix up xorg's quirk. */
        modes = mrvl_additional_quirk(pScrn, modes, edid, mon);

        if (edid->extensions)
        {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Parsing extended edid data for output [%p]\n", output);
            modes = mrvl_add_extended_edid_modes(edid, modes);
        }
    }

    // If can not get modes from EDID, just report some common modes.
    if (modes == NULL)
    {
        modes = mrvl_get_common_modes(output, modes);

        if (modes == NULL)
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Can not get modes for output [%p]\n", output);
        else
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Use built-in common modes for output [%p]\n", output);
    }
    else
    {
        DisplayModePtr m = modes;

        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Use EDID modes for output [%p], printing all modes:\n", output);

        while(m)
        {
            xf86PrintModeline(pScrn->scrnIndex, m);
            m = m->next;
        }
    }

    return modes;
}

#else

static DisplayModePtr
mrvl_get_modes(xf86OutputPtr output)
{
    ScrnInfoPtr             pScrn = output->scrn;
    DisplayModePtr modes = NULL;

//    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "enter into get LCD mode\n");
    
    if (output->status != XF86OutputStatusConnected)
    {
        return NULL;
    }
    
    if (output->MonInfo)
    {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "**** find MonInfo\n");
        modes = xf86OutputGetEDIDModes(output);
    } else
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "**** no MonInfo\n");

    if (modes == NULL)
    {
        
        modes = mrvl_get_common_modes(output, modes);
	
        if (modes == NULL)
        {
            //modes = mrvl_get_screen_modes();
        }
    } else {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "output get modes != NULL\n");
    }

    return modes;
}

static xf86OutputStatus
mrvl_detect(xf86OutputPtr output)
{
    ScrnInfoPtr             pScrn = output->scrn;
    FBDevRec*        pDev;

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "enter mrvl_detect, output %p\n", output);
    pDev = FBDEVPTR(pScrn);

    if (pDev && output->crtc == pDev->pCrtc[0]) {
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvl_detect: disable crtc[0].\n");

        return XF86OutputStatusDisconnected;
    }

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvl_detec: enable crtc[1].\n");
    
    return XF86OutputStatusConnected;
}
#endif

static void mrvl_output_disable(char *iobase)
{
    volatile unsigned int *ptr;

    ptr = (unsigned int*)(iobase+0x1B8);
    *ptr &= ~(0x1);
}

static void mrvl_output_enable(char *iobase)
{
    volatile unsigned int *ptr;

    ptr = (unsigned int*)(iobase+0x1B8);
    *ptr |= 0x1;
}

#if 0
static int mrvl_output_get_id(xf86OutputPtr output)
{
    FBDevRec* pDev;
    ScrnInfoPtr pScrn;

    pScrn = output->scrn;
    pDev = FBDEVPTR(pScrn);

    if (pDev && output->crtc == pDev->pCrtc[0]) {
	return 0;
    } else {
	return 1;
    }
}
#endif

static int mrvl_check_current_pos(xf86OutputPtr output, DisplayModePtr mode)
{
    FBDevRec* pDev;
    ScrnInfoPtr pScrn;
    int fd;
    int total_v, total_h;
    struct fb_var_screeninfo var;
    char *iobase = 0;
    MRVLOutputPrivatePtr private_data;
    MRVLCrtcPrivatePtr pCrtcPriv = (MRVLCrtcPrivatePtr)output->crtc->driver_private;

    pScrn = output->scrn;
    pDev = FBDEVPTR(pScrn);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvl_output.c: mrvl_check_current_pos()\n");

    fd = mrvl_output_get_fb_info(output, 0, &var, &iobase);

    if(fd < 0) 
    {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Fail to get info via mrvl_output_get_fb_info()\n");
        return FALSE;
    }

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Expecting pScrn BPP=%d & Depth=%d\n",
		pScrn->bitsPerPixel, pScrn->depth);
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "current output BPP=%d & Depth=%d\n",
		var.bits_per_pixel, var.red.length+var.green.length+var.blue.length+var.transp.length);

    /*
     * Var correction.
     */
    var.bits_per_pixel = pScrn->bitsPerPixel;

    switch (pScrn->depth) {
    case 16:
        var.red.offset      = 11;
        var.red.length      = 5;
        var.green.offset    = 5;
        var.green.length    = 6;
        var.blue.offset     = 0;
        var.blue.length     = 5;
        var.transp.offset   = 0;
        var.transp.length   = 0;
        break;
    case 24:
        var.red.offset      = 16;
        var.red.length      = 8;
        var.green.offset    = 8;
        var.green.length    = 8;
        var.blue.offset     = 0;
        var.blue.length     = 8;
        var.transp.offset   = 0;
        var.transp.length   = 0;
        break;
    case 32:
        var.red.offset      = 16;
        var.red.length      = 8;
        var.green.offset    = 8;
        var.green.length    = 8;
        var.blue.offset     = 0;
        var.blue.length     = 8;
        var.transp.offset   = 24;
        var.transp.length   = 8;
        break;
 
    default:
        break;
    }

    var.xoffset = output->crtc->x;
    
    if (output->crtc->rotation == RR_Rotate_0)
        var.yoffset = output->crtc->y;
    else {

        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvl_output.c: mrvl_check_current_pos(): crtc %d, var virtual x %d, y %d, scrn virtual x %d, y %d, config virtual x %d, y %d\n", pCrtcPriv->crtc_id, var.xres_virtual, var.yres_virtual, pScrn->virtualX, pScrn->virtualY, pCrtcPriv->configVirtualX, pCrtcPriv->configVirtualY);

        var.yres_virtual = pCrtcPriv->configVirtualY * (pCrtcPriv->crtc_num + 1);
        var.xoffset = 0;
        var.yoffset = pCrtcPriv->configVirtualY * (pCrtcPriv->crtc_id + 1);
    }

    if (mode) {
        /* Get resolution. */
        var.xres = mode->HDisplay;
        var.yres = mode->VDisplay;

        /* Get horizontal timings */
        var.right_margin = mode->HSyncStart - mode->HDisplay;
        var.hsync_len = mode->HSyncEnd - mode->HSyncStart;
        var.left_margin = mode->HTotal - mode->HSyncEnd;

        /* Get vertical timings */
        var.lower_margin = mode->VSyncStart - mode->VDisplay;
        var.vsync_len = mode->VSyncEnd - mode->VSyncStart;
        var.upper_margin = mode->VTotal - mode->VSyncEnd;
    }

    total_h = (var.xres+var.left_margin+var.right_margin+var.hsync_len);
    total_v = (var.yres+var.upper_margin+var.lower_margin+var.vsync_len);
    var.pixclock = 1000000*1000 / (mode->Clock);
    var.activate = FB_ACTIVATE_NOW;

    /*
     * Before we apply new timings settings into output interface,
     * we should turn off dumb ctrl first. Or sometimes it might 
     * cause panel detect wrong timing.
     */
   /* disable dumb interface. */
    mrvl_output_disable(iobase);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "New output setting BPP=%d & Depth=%d "
        "rgba: %d/%d, %d/%d, %d/%d, %d/%d\n",
	var.bits_per_pixel,
        var.red.length+var.green.length+var.blue.length+var.transp.length,
        var.red.length,
        var.red.offset,
        var.green.length,
        var.green.offset,
        var.blue.length,
        var.blue.offset,
        var.transp.length,
        var.transp.offset
	);

    if (mode->Flags & V_INTERLACE)
        var.vmode |= FB_VMODE_INTERLACED;
    else if (mode->Flags & V_DBLSCAN)
        var.vmode |= FB_VMODE_DOUBLE;
    else
        var.vmode = FB_VMODE_NONINTERLACED;

    // Add +/- hsync and +/- vsync
    var.sync = 0;

    if (mode->Flags & V_PHSYNC)
        var.sync |= FB_SYNC_HOR_HIGH_ACT;
    else
        var.sync &= ~FB_SYNC_HOR_HIGH_ACT;

    if (mode->Flags & V_PVSYNC)
        var.sync |= FB_SYNC_VERT_HIGH_ACT;
    else
        var.sync &= ~FB_SYNC_VERT_HIGH_ACT;

    /* apply current setting */
    mrvl_output_config(output, &var);

    /* enable dumb interface.  */
    mrvl_output_enable(iobase);

    /* save new setting. */
    private_data = (MRVLOutputPrivatePtr)output->driver_private;
    if (private_data->cur_mode == 0) {
        private_data->cur_mode = (unsigned int)malloc(sizeof(struct fb_var_screeninfo));
    }
    *((struct fb_var_screeninfo*)private_data->cur_mode) = var;

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "New setting has been applied.\n");
    return TRUE; 
}
/*
# define M_T_BUILTIN 0x01        built-in mode 
# define M_T_CLOCK_C (0x02 | M_T_BUILTIN)  built-in mode - configure clock 
# define M_T_CRTC_C  (0x04 | M_T_BUILTIN)  built-in mode - configure CRTC  
# define M_T_CLOCK_CRTC_C  (M_T_CLOCK_C | M_T_CRTC_C)
                                built-in mode - configure CRTC and clock 
# define M_T_PREFERRED 0x08      preferred mode within a set 
# define M_T_DEFAULT 0x10        (VESA) default modes 
# define M_T_USERDEF 0x20        One of the modes from the config file 
# define M_T_DRIVER  0x40        Supplied by the driver (EDID, etc) 
# define M_T_USERPREF 0x80       mode preferred by the user config
 */

#if MRVL_RANDR_EDID_MODES
static int 
mrvl_mode_valid_with_edid(xf86OutputPtr output, DisplayModePtr mode)
{
    /* Default modes are harmful here. */
    if (mode->type & M_T_DEFAULT)
		return MODE_BAD;

	return MODE_OK;
}
#else
static int 
mrvl_mode_valid(xf86OutputPtr output, DisplayModePtr pMode)
{
    FBDevRec* pDev;
    ScrnInfoPtr pScrn;
    //int fd;
    //struct fb_fix_screeninfo fix;

    pScrn = output->scrn;
    pDev = FBDEVPTR(pScrn);

    if (pDev->UseDriverBuiltInMode) {
        if ((pMode->type != 0x0) && (pMode->type != M_T_USERDEF) &&
            (pMode->type != M_T_DRIVER))
            return MODE_CLOCK_RANGE;
    } else {
        if ((pMode->type != 0x0) && (pMode->type != M_T_USERDEF))
	    return MODE_CLOCK_RANGE;
    }
    /* xf86DrvMsg(pScrn->scrnIndex, X_INFO, "(%dx%d) mode type = 0x%x\n", pMode->HDisplay,
		pMode->VDisplay, pMode->type);
    */

    return MODE_OK;
}
#endif



static void 
mrvl_create_resource(xf86OutputPtr output)
{
    ScrnInfoPtr             pScrn = output->scrn;
    //xf86CrtcConfigPtr       xf86_config = XF86_CRTC_CONFIG_PTR(pScrn);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_create_resource\n");
    /* check position */

}

static void
mrvl_dpms(xf86OutputPtr output, int mode)
{
    ScrnInfoPtr             pScrn = output->scrn;
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_dpms\n");
}

static void 
mrvl_save(xf86OutputPtr output)
{
    ScrnInfoPtr             pScrn = output->scrn;
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_save\n");
}

static void 
mrvl_restore(xf86OutputPtr output)
{
    xf86DrvMsg(output->scrn->scrnIndex, X_INFO, "entering into mrvl_restore\n");
}

static Bool
mrvl_mode_fixup(xf86OutputPtr output, DisplayModePtr mode, DisplayModePtr adjusted_mode)
{
    xf86DrvMsg(output->scrn->scrnIndex, X_INFO, "entering into mrvl_mode_fixup\n");
    /* check position */

    return TRUE;
}

static void 
mrvl_mode_prepare(xf86OutputPtr output)
{
    xf86DrvMsg(output->scrn->scrnIndex, X_INFO, "entering into mrvl_mode_prepare\n");
}

static char *iobase0 = 0;

static void
mrvl_mode_set(xf86OutputPtr output, DisplayModePtr mode, DisplayModePtr adjusted_mode)
{
    ScrnInfoPtr      pScrn = output->scrn;
    FBDevRec*        pDev;
    struct fb_var_screeninfo var;

    pDev = FBDEVPTR(pScrn);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "entering into mrvl_mode_set, width %d height %d ajust width %d height %d\n",
        mode->HDisplay,
        mode->VDisplay,
        adjusted_mode->HDisplay,
        adjusted_mode->VDisplay);    

    /* check position */
    mrvl_check_current_pos(output, mode);

    if (pDev && output->crtc == pDev->pCrtc[0]) {    
        xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "LCD0 probed mode = <%dx%d>, <%dx%d>\n",
            output->probed_modes->HDisplay,
            output->probed_modes->VDisplay,
            output->initial_x,
            output->initial_y);

        mrvl_output_get_fb_info(output, 0, &var, &iobase0);
    } else {
        char *iobase;
        xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "LCD1 probed mode = <%dx%d>, <%dx%d>\n",
            output->probed_modes->HDisplay,
            output->probed_modes->VDisplay,
            output->initial_x,
            output->initial_y);
        mrvl_output_get_fb_info(output, 0, &var, &iobase);
#if 0
        /*
         * If 
         * a) two displays show the same thing
         * b) LCD0 is under 888 dumb mode
         * we do
         * 1) disable LCD1 DMA.
         * 2) set portB output LCD0 signal.
         */
        if((pDev->pCrtc[0]->x == pDev->pCrtc[1]->x) &&
           (pDev->pCrtc[0]->y == pDev->pCrtc[1]->y) &&
           (pDev->pCrtc[0]->mode.HDisplay == pDev->pCrtc[1]->mode.HDisplay) &&
           (pDev->pCrtc[0]->mode.VDisplay == pDev->pCrtc[1]->mode.VDisplay)) {
            volatile unsigned int *ptr;

            if (iobase0) {
                ptr = (unsigned int*)(iobase0+0x1B8);
                if ( 0x60000000 == (*ptr & 0xf0000000)) {
                    /* 1) disable LCD1 DMA. */
                    if (iobase) {
                        ptr = (unsigned int*)(iobase+0x190);
                        *ptr &= ~(0x101);
                    }

                    /* 2) set portB output LCD0 signal */
                    system("echo 1 > /sys/devices/platform/dovedcon/pb_mode");
                    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mirror mode detected. Only output from LCD0.\n");
                    return;
                } else {
                    system("echo 0 > /sys/devices/platform/dovedcon/pb_mode");
                    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mirror mode detected. But LCD0 is not 888 mode.\n");
                    return;
                }
            }
        }

        system("echo 0 > /sys/devices/platform/dovedcon/pb_mode");
        xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Not under mirror mode. Make sure portb output LCD1 signal.\n");
#endif
    }
} 

static void
mrvl_mode_commit(xf86OutputPtr output)
{
    ScrnInfoPtr             pScrn = output->scrn;
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_mode_commit\n");
    /* check position */

}

static Bool
mrvl_set_property(xf86OutputPtr output, Atom property, RRPropertyValuePtr value)
{
    ScrnInfoPtr             pScrn = output->scrn;
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_set_property\n");
    
    return TRUE;
}


static void
mrvl_destroy(xf86OutputPtr output)
{
    ScrnInfoPtr             pScrn = output->scrn;
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_destroy\n");
    
    if (output->driver_private)
    {
        //xfree(output->driver_private);
    }
}

static Bool
mrvl_get_property(xf86OutputPtr output, Atom property)
{
    xf86DrvMsg(output->scrn->scrnIndex, X_INFO, "entering into mrvl_get_property\n");
    
    return TRUE;
}

static xf86CrtcPtr
mrvl_get_crtc(xf86OutputPtr output)
{
    ScrnInfoPtr             pScrn = output->scrn;
    xf86CrtcPtr         crtc;
    FBDevRec* pDev = FBDEVPTR(output->scrn);
    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "entering into mrvl_get_crtc\n");

    crtc = pDev->pCrtc[output->possible_crtcs];
    return output->crtc;
}

static const xf86OutputFuncsRec mrvl_output_funcs = {
    .create_resources = mrvl_create_resource,
    .dpms = mrvl_dpms,
    .save = mrvl_save,
    .restore = mrvl_restore,
#if MRVL_RANDR_EDID_MODES
    .mode_valid = mrvl_mode_valid_with_edid,
#else
    .mode_valid = mrvl_mode_valid,
#endif
    .mode_fixup = mrvl_mode_fixup,
    .prepare = mrvl_mode_prepare,
    .mode_set = mrvl_mode_set,
    .commit = mrvl_mode_commit,
#if MRVL_RANDR_EDID_MODES
    .detect = mrvl_detect_with_edid,
    .get_modes = mrvl_get_modes_with_edid,
#else
    .detect = mrvl_detect,
    .get_modes = mrvl_get_modes,
#endif
#if RANDR_12_INTERFACE
    .set_property = mrvl_set_property,
#endif
#if RANDR_13_INTERFACE
    .get_property = mrvl_get_property,
#endif
#if RANDR_GET_CRTC_INTERFACE
    .get_crtc = mrvl_get_crtc,
#endif
    .destroy = mrvl_destroy
};

Bool 
mrvlOutputInit(ScrnInfoPtr pScrn)
{
    FBDevRec* pDev = FBDEVPTR(pScrn);
    int i, fd;
    struct fb_fix_screeninfo fix;

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvlOutputInit: create output...\n");
    /* Look up output type. */
    for( i=0; i < MRVL_MAX_CRTC_COUNT; i++) {
        fd = pDev->gfx_fd[i];
        pDev->pOutput[i] = NULL;

        if (fd < 0) break;

        if (ioctl(fd, FBIOGET_FSCREENINFO, &fix)) {
            return -1;
        }
#if MRVL_PLATFORM_INFO==MRVL_DOVE
        if (strstr(fix.id, GFX_DEV0_ID)) {
            /* found lvds output */
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvlOutputInit: create output%d at lvds...\n", i);
            pDev->pOutput[i] = xf86OutputCreate(pScrn, &mrvl_output_funcs, LVDS_OUTPUT_NAME);
        } else if (strstr(fix.id, GFX_DEV1_ID)) {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvlOutputInit: create output%d at VGA...\n", i);
            pDev->pOutput[i] = xf86OutputCreate(pScrn, &mrvl_output_funcs, VGA_OUTPUT_NAME);
        }
#elif MRVL_PLATFORM_INFO==MRVL_MMP2
        if (strstr(fix.id, MMP2_GFX_ID)) {
            /* found lvds output */
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvlOutputInit: MMP2 create output%d at lvds...\n", i);
            pDev->pOutput[i] = xf86OutputCreate(pScrn, &mrvl_output_funcs, LVDS_OUTPUT_NAME);
        } else if (strstr(fix.id, MMP2_TV_GFX_ID)) {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvlOutputInit: MMP2 create output%d at HDMI...\n", i);
            pDev->pOutput[i] = xf86OutputCreate(pScrn, &mrvl_output_funcs, HDMI_OUTPUT_NAME);
        }
#endif
    }

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvlOutputInit: Init output...\n");
    /* Init output info. */
    for( i=0; i < MRVL_MAX_CRTC_COUNT; i++) {
        mrvlOutputPrivate[i].cur_mode = 0;
        mrvlOutputPrivate[i].dummy = 0;

        if (pDev->pOutput[i]) { 
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "mrvlOutputInit: Init output%d.\n", i);
            pDev->pOutput[i]->driver_private = &mrvlOutputPrivate[i];
            pDev->pOutput[i]->probed_modes = xf86CVTMode( 1536, 1024, 60.0, FALSE, FALSE);
            pDev->pOutput[i]->probed_modes->type = M_T_DRIVER;
            pDev->pOutput[i]->possible_crtcs = 1 << i;
            pDev->pOutput[i]->possible_clones = 0;
            pDev->pOutput[i]->crtc = pDev->pCrtc[i];
        }
    }

    return TRUE;
}
