/******************************************************************************
*(C) Copyright 2007 Marvell International Ltd.
* All Rights Reserved 
******************************************************************************/

#include <EGL/egl.h>
#include <VG/openvg.h>
#include <VG/vgu.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <math.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>

#define WINDOW_WIDTH        240
#define WINDOW_HEIGHT       320

// Typedef for native window

// Typedef for native window
Window    			window;
Display				*display;
XSetWindowAttributes	winattrs;
int					winmask;
int					screen; 
int					i;
XVisualInfo			visualTemplate;
XVisualInfo			*vinfo;

EGLDisplay      eglDisplay;
EGLConfig       eglConfig;
EGLContext      eglContext;
EGLSurface      eglWindowSurface;

static VGPath   vgStarPath;
static VGPaint  vgStarPaint;
static float    rotateAngle;
static float    scale;

unsigned int win_w,win_h;

//*****************************************************************************
// Name:            createStarPath
// Description:     Create a star path
//*****************************************************************************
static void createStarPath (VGPath path)
{
    VGfloat pPolygon[] =
    {
        0, -40.0f, 25.0f, 40.0f, -40.0f, -10.0f, 40.0f, -10.0f, -25.0f, 40.0f
    };   
    
    vguPolygon(path, pPolygon, 5, VG_TRUE);
}


//*****************************************************************************
// Name:            EGLInit
// Description:     EGL initialization 
//*****************************************************************************
bool EGLInit()
{
    EGLint      numConfigs;
    EGLint      majorVersion;
    EGLint      minorVersion;
    EGLConfig   config;
    
    // The attibutes required to match by the configurations
    EGLint      attrib_list[] = {EGL_RED_SIZE,          8,
                                 EGL_GREEN_SIZE,        8,
                                 EGL_BLUE_SIZE,         8,
                                 EGL_SURFACE_TYPE,      EGL_WINDOW_BIT,
                                 EGL_NONE
                                };

    display = XOpenDisplay(getenv("DISPLAY"));
    
    if(!display)
    {
        printf("Can not open Display, please run export DISPLAY=:0 or other \n");
      
        exit(1);
    }

    screen = DefaultScreen(display);

    vinfo = XGetVisualInfo(display, VisualScreenMask, &visualTemplate, &i);

    winattrs.event_mask = ExposureMask | StructureNotifyMask | ButtonPressMask | ButtonReleaseMask
					| PointerMotionMask | VisibilityChangeMask;
    winattrs.border_pixel = 0;
    winattrs.background_pixel = 0;
    winattrs.colormap = XCreateColormap(display, RootWindow(display, screen), vinfo->visual, AllocNone);

    winmask = CWBackPixel | CWBorderPixel | CWColormap | CWEventMask;

    window = XCreateWindow(display, RootWindow(display, screen), 0, 0, WINDOW_WIDTH, 
					WINDOW_HEIGHT, 0, vinfo->depth, InputOutput, vinfo->visual, winmask, &winattrs);

                                
    // Init EGL API type
    eglBindAPI(EGL_OPENVG_API);
                                 
    // Get EGL display
    eglDisplay = eglGetDisplay(display);
    if(eglDisplay == EGL_NO_DISPLAY || eglGetError() != EGL_SUCCESS)
    {
        return false;
    }

    // Initialize EGL
    eglInitialize(eglDisplay, &majorVersion, &minorVersion);
    if(eglGetError() != EGL_SUCCESS)
    {
        return false;
    }

    // Choose EGL config
    if(!eglChooseConfig(eglDisplay, attrib_list, &config, 1, &numConfigs))
    {
        return false;
    }

    // Create EGL rendering context
    eglContext = eglCreateContext(eglDisplay, config, NULL, NULL);
    if(eglContext == EGL_NO_CONTEXT || eglGetError() != EGL_SUCCESS)
    {
        return false;
    }

    XMapWindow(display, window);
	
    // Create EGL window surface
    eglWindowSurface = eglCreateWindowSurface(eglDisplay, config, window, NULL);
    if(eglWindowSurface == EGL_NO_SURFACE || eglGetError() != EGL_SUCCESS)
    {
        return false;
    }

    // Attach the EGL rendering context to EGL surfaces
    eglMakeCurrent(eglDisplay, eglWindowSurface, eglWindowSurface, eglContext);
    if(eglGetError() != EGL_SUCCESS)
    {
        return false;
    }

    // Check vendor, renderer and version
    printf("Vendor   : %s\n", vgGetString(VG_VENDOR));
    printf("Renderer : %s\n", vgGetString(VG_RENDERER));
    printf("Version  : %s\n", vgGetString(VG_VERSION));
/*
	Window root_window;
	int win_x,win_y;
	unsigned int border_w,bpp;
*/
	/* Query window parameters. */
/*	if(0 == XGetGeometry(display,
		    window,
		    &root_window,
		    &win_x, 
		    &win_y, 
		    &win_w,
		    &win_h,
		    &border_w,
		    &bpp) )
	{
	    printf("%s : can't get window info.\n", __func__);
		return false;
	}
*/	
	// Resize window to appropriate size
	eglResizeWindowSurface();

    return true;
}



//*****************************************************************************
// Name:            EGLDeInit
// Description:     EGL release
//*****************************************************************************
void EGLDeInit( void )
{
    // Destroy all EGL resources 
    eglMakeCurrent(eglDisplay, NULL, NULL, NULL);
    eglDestroyContext(eglDisplay, eglContext);
    eglDestroySurface(eglDisplay, eglWindowSurface);
    eglTerminate(eglDisplay);

    XDestroyWindow(display, window);
    XCloseDisplay(display);
}



//*****************************************************************************
// Name:            AppInit
// Description:     Application initialization 
//*****************************************************************************
void AppInit( void )
{
    VGfloat starGradient[5] =
    {
        0, 0, 0, 0, 30
    };
    VGfloat starRamp[15] =
    {
            0, 0, 0, 0, 0.5f,
            0.5f, 1.f, 0, 0, 0.5f,
            1, 1.0f, 1.0f, 0, 0.5f
    };

    // Create the path
    vgStarPath = vgCreatePath(VG_PATH_FORMAT_STANDARD, VG_PATH_DATATYPE_F,
                              1.0f, 0.0f, 0, 0, VG_PATH_CAPABILITY_ALL);
    vgClearPath(vgStarPath, VG_PATH_CAPABILITY_ALL);
    createStarPath(vgStarPath);
    
    // Create the paint
    vgStarPaint = vgCreatePaint();
    vgSetParameteri(vgStarPaint, VG_PAINT_TYPE, VG_PAINT_TYPE_RADIAL_GRADIENT);
    vgSetParameterfv(vgStarPaint, VG_PAINT_RADIAL_GRADIENT, 5, starGradient);
    vgSetParameteri(vgStarPaint, VG_PAINT_COLOR_RAMP_SPREAD_MODE, VG_COLOR_RAMP_SPREAD_PAD);
    vgSetParameterfv(vgStarPaint, VG_PAINT_COLOR_RAMP_STOPS, 15, starRamp);
  
    // Set blend mode
    vgSeti(VG_BLEND_MODE, VG_BLEND_SRC_OVER);

    rotateAngle = 0.0f;
    scale = 0.1f;
}



//*****************************************************************************
// Name:            AppDeInit
// Description:     Application release 
//*****************************************************************************
void AppDeInit( void )
{
    // Destroy OpenVG resources
    vgDestroyPaint(vgStarPaint);
    vgDestroyPath(vgStarPath);
}



//*****************************************************************************
// Name:            AppUpdate
// Description:     Application update 
//*****************************************************************************
void AppUpdate( void )
{    
    rotateAngle += 30.0f;
    scale += 0.1f;
}



//*****************************************************************************
// Name:            AppRender
// Description:    Application rendering. 
//*****************************************************************************
void AppRender( void )
{
    VGfloat clearColor[4] =
    {
        0.0f, 1.0f, 0.0f, 1.0f
    };

    // Clear the background with green
    vgSetfv(VG_CLEAR_COLOR, 4, clearColor);
    vgClear(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
    //vgClear(0, 0, win_w, win_h);

    // Set the user to surface matrix
    vgSeti(VG_MATRIX_MODE, VG_MATRIX_PATH_USER_TO_SURFACE);
    vgLoadIdentity();
    vgTranslate(WINDOW_WIDTH/2, WINDOW_HEIGHT/2);
    //vgTranslate(win_w/2, win_h/2);
    vgScale(scale, scale);
    vgRotate(rotateAngle);

    // Set the paint to user matrix
    vgSeti(VG_MATRIX_MODE, VG_MATRIX_FILL_PAINT_TO_USER);
    vgLoadIdentity();
    
    // Fill the path
    vgSetPaint(vgStarPaint, VG_FILL_PATH);
    vgDrawPath(vgStarPath, VG_FILL_PATH);

    eglSwapBuffers( eglDisplay, eglWindowSurface );
}



//*****************************************************************************
// Name:            main
// Description:     Application entry 
//*****************************************************************************
int main()
{
    // EGL initialization
    if( !EGLInit())
    {
        return false;
    }
    
    // Application initialization
    AppInit();

    // Render 100 frames
    for( int i=0; i < 100; i++ )
    {
            // Application update
            AppUpdate();

            // Application render
            AppRender();
    }    

    // Application release
    AppDeInit();

    // EGL release    
    EGLDeInit();
    
    return 0;
}

// EOF




