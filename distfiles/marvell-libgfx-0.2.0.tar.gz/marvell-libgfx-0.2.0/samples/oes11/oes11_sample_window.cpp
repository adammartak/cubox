/******************************************************************************
*(C) Copyright 2007 Marvell International Ltd.
* All Rights Reserved 
******************************************************************************/

#include <EGL/egl.h>
#include <GLES/gl.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <math.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>

//#include <gc_egl.h>

#define WINDOW_WIDTH        240
#define WINDOW_HEIGHT       320

// Typedef for native window
    Window    				window;
    Display				*display;
    XSetWindowAttributes	winattrs;
    int					winmask;
    int					screen; 
    int					i;
    XVisualInfo				visualTemplate;
    XVisualInfo				*vinfo;
// Global Variables
EGLDisplay          			eglDisplay;
EGLConfig           			eglConfig;
EGLContext          			eglContext;
EGLSurface          			eglWindowSurface;

// GL content
GLfloat s_cubeVertices[] =
{
    /* FRONT */
    -10,   -10,    10,
    10,    -10,    10,
    -10,   10,     10,
    10,    10,     10,

    /* BACK */
    -10,   -10,    -10,
    -10,   10,     -10,
    10,    -10,    -10,
    10,    10,     -10,

    /* LEFT */
    -10,   -10,    10,
    -10,   10,     10,
    -10,   -10,    -10,
    -10,   10,     -10,

    /* RIGHT */
    10,    -10,    -10,
    10,    10,     -10,
    10,    -10,    10,
    10,    10,     10,

    /* TOP */
    -10,   10,     10,
    10,    10,     10,
    -10,   10,     -10,
    10,    10,     -10,

    /* BOTTOM */
    -10,   -10,    10,
    -10,   -10,    -10,
    10,    -10,    10,
    10,    -10,    -10,
};

/* Normals */
GLfloat s_cubeNormals[] =
{
    0,  0,  1,
    0,  0,  1,
    0,  0,  1,
    0,  0,  1,

    0,  0,  -1,
    0,  0,  -1,
    0,  0,  -1,
    0,  0,  -1,

    -1,  0,  0,
    -1,  0,  0,
    -1,  0,  0,
    -1,  0,  0,

    1,  0,  0,
    1,  0,  0,
    1,  0,  0,
    1,  0,  0,

    0,  1,  0,
    0,  1,  0,
    0,  1,  0,
    0,  1,  0,

    0,  -1,  0,
    0,  -1,  0,
    0,  -1,  0,
    0,  -1,  0,
};


GLfloat s_cubeColors[] =
{
    /* FRONT */
    0.0f,   0.0f,    1.0f,    1.0f,
    1.0f,   0.0f,    1.0f,    1.0f,
    0.0f,   1.0f,    1.0f,    1.0f,
    1.0f,   1.0f,    1.0f,    1.0f,

    /* BACK */
    0.0f,   0.0f,    0.0f,    1.0f,
    0.0f,   1.0f,    0.0f,    1.0f,
    1.0f,   0.0f,    0.0f,    1.0f,
    1.0f,   1.0f,    0.0f,    1.0f,

    /* LEFT */
    0.0f,   0.0f,    1.0f,    1.0f,
    0.0f,   1.0f,    1.0f,    1.0f,
    0.0f,   0.0f,    0.0f,    1.0f,
    0.0f,   1.0f,    0.0f,    1.0f,

    /* RIGHT */
    1.0f,    0.0f,    0.0f,    1.0f,
    1.0f,    1.0f,    0.0f,    1.0f,
    1.0f,    0.0f,    1.0f,    1.0f,
    1.0f,    1.0f,    1.0f,    1.0f,

    /* TOP */
    0.0f,   1.0f,     1.0f,    1.0f,
    1.0f,   1.0f,     1.0f,    1.0f,
    0.0f,   1.0f,     0.0f,    1.0f,
    1.0f,   1.0f,     0.0f,    1.0f,

    /* BOTTOM */
    0.0f,   0.0f,    1.0f,    1.0f,
    0.0f,   0.0f,    0.0f,    1.0f,
    1.0f,   0.0f,    1.0f,    1.0f,
    1.0f,   0.0f,    0.0f,    1.0f,
};

// Animation parameter
GLfloat           cubeRotate;


//*****************************************************************************
// Name:            AppInit
// Description:     Application initialization 
//*****************************************************************************
bool AppInit()
{
    EGLint      numConfigs;
    EGLint      majorVersion;
    EGLint      minorVersion;
    EGLConfig   config;
    EGLint      attrib_list[] = {   EGL_RED_SIZE,           5,
                                    EGL_GREEN_SIZE,         6,
                                    EGL_BLUE_SIZE,          5,
                                    EGL_DEPTH_SIZE,         16,
                                    EGL_RENDERABLE_TYPE,    EGL_OPENGL_ES_BIT,
                                    EGL_SURFACE_TYPE,       EGL_WINDOW_BIT,
                                    EGL_NONE,
                                };
   

    display = XOpenDisplay(getenv("DISPLAY"));
    
    if(!display)
    {
    	printf("Can not open Display, please run export DISPLAY=:0 or other \n");
      
	exit(1);
    }

    screen = DefaultScreen(display);

    vinfo = XGetVisualInfo(display, VisualScreenMask, &visualTemplate, &i);

    winattrs.event_mask = ExposureMask | StructureNotifyMask | ButtonPressMask | ButtonReleaseMask
					| PointerMotionMask | VisibilityChangeMask;
    winattrs.border_pixel = 0;
    winattrs.background_pixel = 0;
    winattrs.colormap = XCreateColormap(display, RootWindow(display, screen), vinfo->visual, AllocNone);

    winmask = CWBackPixel | CWBorderPixel | CWColormap | CWEventMask;

    window = XCreateWindow(display, RootWindow(display, screen), 0, 0, WINDOW_WIDTH, 
					WINDOW_HEIGHT, 0, vinfo->depth, InputOutput, vinfo->visual, winmask, &winattrs);
                                
    // Init matrix states  
    GLfloat fovy, aspect, xmin, xmax, ymin, ymax, zmin, zmax;
   
	// Init lighting  states
    const GLfloat light_position[]	    = {-50.0f,  50.0f,  50.0f,    0.0f };
    const GLfloat light_ambient[]	    = {0.125f,  0.125f, 0.125f,  1.0f };
    const GLfloat light_diffuse[]	    = {1.0f,    1.0f,   1.0f,    1.0f };
    const GLfloat material_diffuse[]	= {0.6f,    1.0f,   0.6f,    1.0f };

    // Get EGL display
    eglDisplay = eglGetDisplay(display);
    if(eglDisplay == EGL_NO_DISPLAY || eglGetError() != EGL_SUCCESS)
    {
        return false;
    }

    // Initialize EGL
    eglInitialize(eglDisplay, &majorVersion, &minorVersion);
    if(eglGetError() != EGL_SUCCESS)
    {
        return false;
    }

    // Choose EGL config
    if(!eglChooseConfig(eglDisplay, attrib_list, &config, 1, &numConfigs))
    {
        return false;
    }

    // Create EGL rendering context
    eglContext = eglCreateContext(eglDisplay, config, NULL, NULL);
    if(eglContext == EGL_NO_CONTEXT || eglGetError() != EGL_SUCCESS)
    {
        return false;
    }

    XMapWindow(display, window);

    // Create EGL window surface
    eglWindowSurface = eglCreateWindowSurface(eglDisplay, config, window, NULL);
    if(eglWindowSurface == EGL_NO_SURFACE || eglGetError() != EGL_SUCCESS)
    {
        return false;
    }
	
	// Attach the EGL rendering context to EGL surfaces
    eglMakeCurrent(eglDisplay, eglWindowSurface, eglWindowSurface, eglContext);
    if(eglGetError() != EGL_SUCCESS)
    {
        return false;
    }       
    
    // Check vendor, renderer and version
    printf("Vendor   : %s\n", glGetString(GL_VENDOR));
    printf("Renderer : %s\n", glGetString(GL_RENDERER));
    printf("Version  : %s\n", glGetString(GL_VERSION));	

	Window root_window;
	int win_x,win_y;
	unsigned int win_w,win_h,border_w,bpp;

	/* Query window parameters. */
	if(0 == XGetGeometry(display,
		    window,
		    &root_window,
		    &win_x, 
		    &win_y, 
		    &win_w,
		    &win_h,
		    &border_w,
		    &bpp) )
	{
	    printf("%s : can't get window info.\n", __func__);
		return false;
	}

      // Set initialize state
    //glViewport(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
    glViewport(win_x, win_y, win_w, win_h);
	   
    // Init states
    fovy    = 80.0f;
    //aspect  = WINDOW_WIDTH * 1.0f / WINDOW_HEIGHT;
    aspect  = win_w * 1.0f / win_h;
    zmin    = 0.1f;
    zmax    = 100.0f;
    ymax    = zmin * (GLfloat)tan(fovy * 3.1415962f / 360.0);
    ymin    = -ymax;
    xmin    = ymin * aspect;
    xmax    = ymax * aspect;

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();     
    glFrustumf(xmin, xmax, ymin, ymax, zmin, zmax);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();    

    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, material_diffuse);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    // Init other GL states
    glClearColor(0.5f, 0.2f, 0.4f, 1.0f);
    glEnable(GL_CULL_FACE);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
    glShadeModel(GL_SMOOTH);

    glEnable(GL_COLOR_MATERIAL);

    // Init animation parameter
    cubeRotate   = 0.0f;

    return true;
}



//*****************************************************************************
// Name:            AppDeInit
// Description:     Application release 
//*****************************************************************************
void AppDeInit( void )
{
    // Destroy all EGL resources    
    eglMakeCurrent(eglDisplay, NULL, NULL, NULL);
    eglDestroyContext(eglDisplay, eglContext);
    eglDestroySurface(eglDisplay, eglWindowSurface);
    eglTerminate(eglDisplay);
    
/*    if(nativeWin)
    {
        fbDestroyWindow(nativeWin);
    }*/
    XDestroyWindow(display, window);
    XCloseDisplay(display);

    return;
}



//*****************************************************************************
// Name:            AppUpdate
// Description:     Application update 
//*****************************************************************************
void AppUpdate( void )
{
    // animate cube
    cubeRotate += 5.0f;

    return;
}



//*****************************************************************************
// Name:            AppRender
// Description:    Application rendering. Three triangles will be rendered abreast and their color 
//                        change according to different blending function setting.  
//*****************************************************************************
void AppRender( void )
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glTranslatef(0.0f, 0.0f, -50.f);
    glScalef(1.3f, 1.3f, 1.3f);
    glRotatef(cubeRotate, 1.0f,  0.0f, 0.0f);
    glRotatef(cubeRotate, 0.0f,  1.0f, 0.0f);    

    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0, s_cubeVertices);

    glEnableClientState(GL_NORMAL_ARRAY);
    glNormalPointer(GL_FLOAT, 0, s_cubeNormals);


    glEnableClientState(GL_COLOR_ARRAY);
    glColorPointer(4, GL_FLOAT, 0, s_cubeColors);

    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    glDrawArrays(GL_TRIANGLE_STRIP, 4, 4);
    glDrawArrays(GL_TRIANGLE_STRIP, 8, 4);
    glDrawArrays(GL_TRIANGLE_STRIP, 12, 4);
    glDrawArrays(GL_TRIANGLE_STRIP, 16, 4);
    glDrawArrays(GL_TRIANGLE_STRIP, 20, 4);

    // Swap the color buffer to window surface 
    eglSwapBuffers (eglDisplay, eglWindowSurface);

    // Sleep for 100 ms
    usleep(1);
    return;
}



//*****************************************************************************
// Name:            main
// Description:     Application entry 
//*****************************************************************************
int main()
{
    // Application initialization
    if( !AppInit() )
    {
        return -1;
    }

    // Render 100 frames
    for( int i=0; i < 100; i++ )
    {
        // Application update
        AppUpdate();

        // Application render
        AppRender();
    }    

    // Application release
    AppDeInit();

    return 0;
}

// EOF







