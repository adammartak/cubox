/******************************************************************************
*(C) Copyright 2007 Marvell International Ltd.
* All Rights Reserved 
******************************************************************************/

#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <math.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>

#define WINDOW_WIDTH        240
#define WINDOW_HEIGHT       320

// Typedef for native window
Window    				window;
Display				*display;
XSetWindowAttributes	winattrs;
int					winmask;
int					screen; 
int					i;
XVisualInfo				visualTemplate;
XVisualInfo				*vinfo;

EGLDisplay          eglDisplay;
EGLConfig           eglConfig;
EGLContext          eglContext;
EGLSurface          eglWindowSurface;

// GL content
#define VERTEX_INDEX	0
#define COLOR_INDEX		1

// shader handels 
GLuint programObj;
GLuint fragShader;
GLuint vertShader;

// Global data
char *vertSource = "attribute vec4 position;        \n\
                    attribute vec4 color;           \n\
                    varying vec4 outcolor;          \n\
                    void main(void)                 \n\
                    {                               \n\
                        gl_Position = position;     \n\
                        outcolor = color;           \n\
                    }";


char *fragSource = "varying vec4 outcolor;          \n\
                    void main(void)                 \n\
                    {                               \n\
                        gl_FragColor = outcolor;    \n\
                    }";


typedef enum {
	GL_SHADER_SOURCE_VERTEX = 0,
	GL_SHADER_SOURCE_FRAGEMENT
}SHADER_SOURCE_TYPE;


// triangle data
static const float g_vertexPositions[] = {
   -0.7f, -0.7f,  1.0f,  1.0f,
    0.7f, -0.7f,  1.0f,  1.0f,
   -0.7f,  0.7f,   1.0f, 1.0f,
    0.7f,  0.7f,   1.0f, 1.0f,
};
static const float g_vertexColors[] = {
   1.0f, 1.0f, 0.0f, 1.0f,
   1.0f, 1.0f, 1.0f, 1.0f,
   1.0f, 0.0f, 0.0f, 1.0f,
   1.0f, 0.0f, 1.0f, 1.0f,
};
static const unsigned short g_indices[] = {
   0, 1, 2, 3,
};


//*****************************************************************************
// Name:            AppInit
// Description:     Application initialization 
//*****************************************************************************
bool AppInit()
{
    EGLint      numConfigs;
    EGLint      majorVersion;
    EGLint      minorVersion;
    EGLConfig   config;
    EGLint      attrib_list[] = {   EGL_RED_SIZE,           5,
                                    EGL_GREEN_SIZE,         6,
                                    EGL_BLUE_SIZE,          5,
                                    EGL_DEPTH_SIZE,         16,
                                    EGL_RENDERABLE_TYPE,    EGL_OPENGL_ES2_BIT,
                                    EGL_SURFACE_TYPE,       EGL_WINDOW_BIT,
                                    EGL_NONE,
                                };

    EGLint      ctxAttribList[] = { EGL_CONTEXT_CLIENT_VERSION, 2, 
                                    EGL_NONE,
                                  };
                                  
    GLint       bShaderCompiled = 0;
    GLint       bLinked = 0;     

#if 0
	volatile int app_loop = 1;

	while(app_loop);
#endif

    display = XOpenDisplay(getenv("DISPLAY"));
    
    if(!display)
    {
        printf("Can not open Display, please run export DISPLAY=:0 or other \n");
      
        exit(1);
    }

    screen = DefaultScreen(display);

    vinfo = XGetVisualInfo(display, VisualScreenMask, &visualTemplate, &i);

    winattrs.event_mask = ExposureMask | StructureNotifyMask | ButtonPressMask | ButtonReleaseMask
					| PointerMotionMask | VisibilityChangeMask;
    winattrs.border_pixel = 0;
    winattrs.background_pixel = 0;
    winattrs.colormap = XCreateColormap(display, RootWindow(display, screen), vinfo->visual, AllocNone);

    winmask = CWBackPixel | CWBorderPixel | CWColormap | CWEventMask;

    window = XCreateWindow(display, RootWindow(display, screen), 0, 0, WINDOW_WIDTH, 
					WINDOW_HEIGHT, 0, vinfo->depth, InputOutput, vinfo->visual, winmask, &winattrs);
                                  
    // Get EGL display
    eglDisplay = eglGetDisplay(display);
    if(eglDisplay == EGL_NO_DISPLAY || eglGetError() != EGL_SUCCESS)
    {
        return false;
    }

    // Initialize EGL
    eglInitialize(eglDisplay, &majorVersion, &minorVersion);
    if(eglGetError() != EGL_SUCCESS)
    {
        return false;
    }

    // Choose EGL config
    if(!eglChooseConfig(eglDisplay, attrib_list, &config, 1, &numConfigs))
    {
        return false;
    }

    // Create EGL rendering context
    eglContext = eglCreateContext(eglDisplay, config, NULL, ctxAttribList);
    if(eglContext == EGL_NO_CONTEXT || eglGetError() != EGL_SUCCESS)
    {
        return false;
    }

    XMapWindow(display, window);

    // Create EGL window surface
    eglWindowSurface = eglCreateWindowSurface(eglDisplay, config, window, NULL);
    if(eglWindowSurface == EGL_NO_SURFACE || eglGetError() != EGL_SUCCESS)
    {
        return false;
    }
	
	// Attach the EGL rendering context to EGL surfaces
    eglMakeCurrent(eglDisplay, eglWindowSurface, eglWindowSurface, eglContext);
    if(eglGetError() != EGL_SUCCESS)
    {
        return false;
    }       

    // Check vendor, renderer and version
    printf("Vendor   : %s\n", glGetString(GL_VENDOR));
    printf("Renderer : %s\n", glGetString(GL_RENDERER));
    printf("Version  : %s\n", glGetString(GL_VERSION));

	// Create the shader program
    programObj = glCreateProgram();

	// Create and load the vertex shader
	vertShader = glCreateShader(GL_VERTEX_SHADER); 
	glShaderSource(vertShader, 1, (const char**)(&vertSource), NULL);
    glCompileShader(vertShader);
    glGetShaderiv(vertShader, GL_COMPILE_STATUS, &bShaderCompiled);
    if(!bShaderCompiled)
    {
        return false;
    }

    // Create and load the fragment shader
    fragShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragShader, 1, (const char**)(&fragSource), NULL);
    glCompileShader(fragShader);
    glGetShaderiv(fragShader, GL_COMPILE_STATUS, &bShaderCompiled);
    if(!bShaderCompiled)
    {
        return false;
    }

    // Attach the vertex and fragment shader to the program
    glAttachShader(programObj, fragShader);
    glAttachShader(programObj, vertShader);


    // Bind attributes
    glBindAttribLocation(programObj, VERTEX_INDEX, "position");
    glBindAttribLocation(programObj, COLOR_INDEX, "color");

    // Link shader
    glLinkProgram(programObj);
    glGetProgramiv(programObj, GL_LINK_STATUS, &bLinked);
    if(!bLinked)
    {
        // Handle link error here
        return false;
    }

	Window root_window;
	int win_x,win_y;
	unsigned int win_w,win_h,border_w,bpp;

	/* Query window parameters. */
	if(0 == XGetGeometry(display,
		    window,
		    &root_window,
		    &win_x, 
		    &win_y, 
		    &win_w,
		    &win_h,
		    &border_w,
		    &bpp) )
	{
	    printf("%s : can't get window info.\n", __func__);
		return false;
	}

      // Set initialize state
    //glViewport(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
    glViewport(win_x, win_y, win_w, win_h);

    return true;
}



//*****************************************************************************
// Name:            AppDeInit
// Description:     Application release 
//*****************************************************************************
void AppDeInit( void )
{
    // Destroy all EGL resources    
    eglMakeCurrent(eglDisplay, NULL, NULL, NULL);
    eglDestroyContext(eglDisplay, eglContext);
    eglDestroySurface(eglDisplay, eglWindowSurface);
    eglTerminate(eglDisplay);

    XDestroyWindow(display, window);
    XCloseDisplay(display);
}



//*****************************************************************************
// Name:            AppUpdate
// Description:     Application update 
//*****************************************************************************
void AppUpdate( void )
{

}



//*****************************************************************************
// Name:            AppRender
// Description:    Application rendering. Three triangles will be rendered abreast and their color 
//                        change according to different blending function setting.  
//*****************************************************************************
void AppRender( void )
{
	// clear screen
	glClearColor(0.3f, 0.3f, 0.7f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // use this program
    glUseProgram(programObj);

	// use uniforms

    // use attributes
    glEnableVertexAttribArray( VERTEX_INDEX );
    glVertexAttribPointer( VERTEX_INDEX, 4, GL_FLOAT, 0, 0, g_vertexPositions );

    glEnableVertexAttribArray( COLOR_INDEX );
	glVertexAttribPointer( COLOR_INDEX, 4, GL_FLOAT, 0, 0, g_vertexColors );

    // draw with client side arrays (in real applications you should use cached VBOs which is much better for performance)
	glDrawElements( GL_TRIANGLE_STRIP, 3, GL_UNSIGNED_SHORT, g_indices );

	eglSwapBuffers( eglDisplay, eglWindowSurface );

    // Sleep for 100 ms
    usleep(1);
}



//*****************************************************************************
// Name:            main
// Description:     Application entry 
//*****************************************************************************
int main()
{
    // Application initialization
    if( !AppInit() )
    {
        return -1;
    }

    // Render 100 frames
    for( int i=0; i < 100; i++ )
    {
        // Application update
        AppUpdate();

        // Application render
        AppRender();
    }    

    // Application release
    AppDeInit();

    return 0;
}

// EOF








